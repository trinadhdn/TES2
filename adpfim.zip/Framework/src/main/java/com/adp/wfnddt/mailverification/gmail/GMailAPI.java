package com.adp.wfnddt.mailverification.gmail;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.core.Response;

import org.apache.cxf.jaxrs.client.WebClient;
import org.apache.cxf.transport.http.HTTPConduit;

import com.google.api.client.auth.oauth2.BearerToken;
import com.google.api.client.auth.oauth2.Credential;
import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.services.gmail.Gmail;
import com.google.api.services.gmail.model.Message;
import com.google.api.services.gmail.model.MessagePart;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;

public class GMailAPI {

	private final String GMAIL_USER = "automail.1234567890@gmail.com";
	private final String APPLICATION_NAME = "WFN Automation";

	// Proxy host/port and authentication
	private final String proxy_host = "11.164.4.21";
	private final int proxy_port = 8080;
	private final String proxy_user = "autoxpert";
	private final String proxy_password = "adpadp";

	//Disabled
	private final String CLIENT_ID = "";//"665170609729-lq42p75j9nh6k6q8gt9sse6hfo6mg3g5.apps.googleusercontent.com";
	private final String CLIENT_SECRET = "";//"iUD8Ma6215GkGdBxDPY3mTgw";
	private  final String REFRESH_TOKEN = "";//"1//04s_B7HZJLjzvCgYIARAAGAQSNwF-L9IrhxnstrTNZboP1_vNazRDkNxSTetmAKiz3A_a_7ZMftFc0kBBjtT2xXhAV62b-5Pt0qo";
	private final String AUTH_URL = "https://www.googleapis.com/oauth2/v4/token";
	
	public static enum ContentType {
			PLAIN,
			HTML,
			ATTACHMENTS
	};

	private String getOAuth2AccessToken() {
		// Get access token
		WebClient client = WebClient.create(AUTH_URL);

		HTTPConduit conduit = WebClient.getConfig(client).getHttpConduit();
		conduit.getClient().setProxyServer(proxy_host);
		conduit.getClient().setProxyServerPort(proxy_port);
		conduit.getProxyAuthorization().setUserName(proxy_user);
		conduit.getProxyAuthorization().setPassword(proxy_password);

		client.header("Content-Type", "application/x-www-form-urlencoded");
		client.query("grant_type", "refresh_token");
		client.query("client_id", CLIENT_ID);
		client.query("client_secret", CLIENT_SECRET);
		client.query("refresh_token", REFRESH_TOKEN);

		Response responseJSON = client.post(new String(""));
		String response = responseJSON.readEntity(String.class);
		client.close();

		JsonElement responseJson = new JsonParser().parse(response);
		String accessToken = responseJson.getAsJsonObject().get("access_token").getAsString();
		return accessToken;
	}

	private void setProxyHttpTransport() {
		System.setProperty("http.proxyHost", proxy_host);
		System.setProperty("http.proxyPort", String.valueOf(proxy_port));
		System.setProperty("https.proxyHost", proxy_host);
		System.setProperty("https.proxyPort", String.valueOf(proxy_port));

		System.setProperty("http.proxyUser", proxy_user);
		System.setProperty("http.proxyPassword", proxy_password);
		System.setProperty("https.proxyUser", proxy_user);
		System.setProperty("https.proxyPassword", proxy_password);
	}

	public List<GmailMessage> getMailsAPI(String query, ContentType contentType) throws IOException, GeneralSecurityException {
		List<GmailMessage> gmailMessages = new ArrayList<>();

		// Get the access token
		String accessToken = getOAuth2AccessToken();
		Credential credential = new Credential(BearerToken.authorizationHeaderAccessMethod()).setAccessToken(accessToken);

		// Set the proxy
		setProxyHttpTransport();

		// Build a new authorized API client service.
		final NetHttpTransport HTTP_TRANSPORT = GoogleNetHttpTransport.newTrustedTransport();
		Gmail service = new Gmail.Builder(HTTP_TRANSPORT, JacksonFactory.getDefaultInstance(), credential).setApplicationName(APPLICATION_NAME).build();

		// Filter the messages and add the object
		List<Message> messages = service.users().messages().list(GMAIL_USER).setQ(query).execute().getMessages();
		for (Message message : messages) {
			Message messageInfo = service.users().messages().get(GMAIL_USER, message.getId()).execute();
			for (MessagePart messagePart : messageInfo.getPayload().getParts()) {
				System.out.println(messagePart.getMimeType());
				if (messagePart.getMimeType().startsWith("multipart/")) {
					for (MessagePart msgPart : messagePart.getParts()) {
						GmailMessage gmailMessage = new GmailMessage();
						gmailMessage.setMessageBody(new String(msgPart.getBody().decodeData()));
						gmailMessages.add(gmailMessage);

					break;
					}
					break;
				} else if(contentType == ContentType.HTML && messagePart.getMimeType().startsWith("text/html")){
					GmailMessage gmailMessage = new GmailMessage();
					gmailMessage.setMessageBody(new String(messagePart.getBody().decodeData()));
					gmailMessages.add(gmailMessage);

					break;
				} else if(contentType == ContentType.PLAIN && messagePart.getMimeType().startsWith("text/plain")){
					GmailMessage gmailMessage = new GmailMessage();
					gmailMessage.setMessageBody(new String(messagePart.getBody().decodeData()));
					gmailMessages.add(gmailMessage);

					break;
				}
			}
		}

		return gmailMessages;
	}

	/*
	public static void main(String[] args) throws IOException, GeneralSecurityException {

		String query = "From:HanumanthaRao.Ubbarapu@adp.com";
		// String query = "label:unread To:automail.1234.567890@gmail.com"
		GMailAPI gMailAPI = new GMailAPI();
		List<GmailMessage> gmailMessages = gMailAPI.getMailsAPI(query, ContentType.HTML);
		for (GmailMessage gmailMessage : gmailMessages) {
			System.out.println("******************************************************************************************************");
			String htmlBody = gmailMessage.getMessageBody();
			Document doc = Jsoup.parse(htmlBody);
			Elements elems = doc.getElementsByClass("MsoNormal");
			for(Element elem : elems){
				System.out.println(elem.text());
			}
			
			System.out.println("******************************************************************************************************");
		}
	}
	*/

}

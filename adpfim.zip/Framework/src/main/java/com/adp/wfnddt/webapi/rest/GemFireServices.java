/**
 * 
 */
package com.adp.wfnddt.webapi.rest;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.cxf.jaxrs.client.WebClient;
import org.apache.log4j.Logger;

import com.adp.wfnddt.core.DDTController;
import com.adp.wfnddt.core.DDTFrameworkException;
import com.adp.wfnddt.core.DDTLoggerManager;
import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;

/**
 * @author Wiermanp
 *
 */
public class GemFireServices {
	private static Logger m_logger = DDTLoggerManager.getLogger(GemFireServices.class);
	private Gson m_gson = new Gson();				
	
	public class GemFireFeatures implements Serializable {

		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		private String clientId;
		private String idBar = "DISABLED";
		private String enterpriseSearch = "DISABLED";
		private String personalProfile = "DISABLED";
		private String googleAnalytics = "DISABLED";
		
		public String getClientId() { return clientId; }
		public void setClientId(String p_clientId) { clientId = p_clientId; return; }
		
		public String getIdBar() { return idBar; }
		public void setIdBar(String p_idBar) { idBar = p_idBar; return; }
		
		public String getEnterpriseSearch() { return enterpriseSearch; }
		public void setEnterpriseSearch(String p_enterpriseSearch) { enterpriseSearch = p_enterpriseSearch; return; }
		
		public String getPersonalProfile() { return personalProfile; }
		public void setPersonalProfile(String p_personalProfile) { personalProfile = p_personalProfile; return; }
		
		public String getGoogleAnalytics() { return googleAnalytics; }
		public void setGoogleAnalytics(String p_googleAnalytics) { googleAnalytics = p_googleAnalytics; return; }
	}
	
	public class GemFireUpdateFeaturesParms implements Serializable {

		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		private List<GemFireFeatures> features = null;
		
		public List<GemFireFeatures> getFeatures() { return features; }
		public void setFeatures(List<GemFireFeatures> p_features) { features = p_features; return; }
		
		public String getClientId() {
			if(features == null) {
				return null;
			}
			
			return features.get(0).getClientId();
		}
		
		public void setClientId(String p_clientId) {
			if(features == null) {
				features = new ArrayList<GemFireFeatures>(1);
				features.add(new GemFireFeatures());
			}
			
			features.get(0).setClientId(p_clientId);
			return;
		}
		
		public String getIdBar() {
			if(features == null) {
				return null;
			}
			
			return features.get(0).getIdBar();
		}
		
		public void setIdBar(String p_idBar) {
			if(features == null) {
				features = new ArrayList<GemFireFeatures>(1);
				features.add(new GemFireFeatures());
			}
			
			features.get(0).setIdBar(p_idBar);
			return;
		}
		
		public String getEnterpriseSearch() {
			if(features == null) {
				return null;
			}
			
			return features.get(0).getEnterpriseSearch();
		}
		
		public void setEnterpriseSearch(String p_enterpriseSearch) {
			if(features == null) {
				features = new ArrayList<GemFireFeatures>(1);
				features.add(new GemFireFeatures());
			}
			
			features.get(0).setEnterpriseSearch(p_enterpriseSearch);
			return;
		}
		
		public String getPersonalProfile() {
			if(features == null) {
				return null;
			}
			
			return features.get(0).getPersonalProfile();
		}
		
		public void setPersonalProfile(String p_personalProfile) {
			if(features == null) {
				features = new ArrayList<GemFireFeatures>(1);
				features.add(new GemFireFeatures());
			}
			
			if(features == null) {
				features = new ArrayList<GemFireFeatures>(1);
			}
			
			features.get(0).setPersonalProfile(p_personalProfile);
			return;
		}
		
		public String getGoogleAnalytics() {
			if(features == null) {
				return null;
			}
			
			return features.get(0).getGoogleAnalytics();
		}
		
		public void setGoogleAnalytics(String p_googleAnalytics) {
			if(features == null) {
				features = new ArrayList<GemFireFeatures>(1);
				features.add(new GemFireFeatures());
			}
			
			features.get(0).setGoogleAnalytics(p_googleAnalytics);
			return;
		}
		
	}
	
	public class GemFireUpdateFeaturesResponse implements Serializable {
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		private String status;
		private String errorMessage;
		private Object data;
		private String requestResponseId;
		private String sessionId;
		private int serverTimeTaken;
		
		public String getStatus() { return status; }
		public String getErrorMessage() { return errorMessage; }
		public Object getData() { return data; }
		public String getRequestResponseId() { return requestResponseId; }
		public String getSessionId() { return sessionId; }
		public int getServerTimeTaken() { return serverTimeTaken; }
	}
	
	public GemFireUpdateFeaturesResponse updateFeatures(GemFireUpdateFeaturesParms p_gfUpdFeaturesParms) throws DDTFrameworkException {
		String gemFireIPAddr = null;
		GemFireUpdateFeaturesResponse gfUpdFeatResp = null;
		
		switch(DDTController.getWfnEnvironment()) {
		case "AUTO1":
			//gemFireIPAddr = "51.19.181.184:81";
			gemFireIPAddr = "51.19.181.144:80";
			break;
		case "AUTO2":
			//gemFireIPAddr = "51.19.181.154:113";
			gemFireIPAddr = "51.19.247.76";
			break;
		case "IPEFULL":
		case "IPESLIM":
			//gemFireIPAddr = "51.19.247.76:10335";
			gemFireIPAddr = "51.19.247.76";
			break;
		default:
			//gfUpdFeatResp = new GemFireUpdateFeaturesResponse();
			//gfUpdFeatResp.status = "FAILED";
			//return gfUpdFeatResp;
			return null;
		}
		
		StringBuilder serviceURI = new StringBuilder("http://");
		serviceURI.append(gemFireIPAddr);
		serviceURI.append("/myportal/cache/metaservices/features/updateFeatures");
		String jsonData = m_gson.toJson(p_gfUpdFeaturesParms);
		String response = postRestAPI(serviceURI.toString(), jsonData);
		m_logger.debug("Response: " + response);
		
		if (response.equals("FAILED")) {
			m_logger.error("Call to GemFire service is not accessible.");
			return null;
		}
		
		try {
			gfUpdFeatResp = m_gson.fromJson(response, GemFireUpdateFeaturesResponse.class);
			return gfUpdFeatResp;
		} catch(JsonSyntaxException jsEx) {
			throw new DDTFrameworkException(GemFireServices.class, "Failed to parse GemFire response: ", jsEx);
		}
	}

	public String postRestAPI(String p_uri, String p_jsonData) throws DDTFrameworkException {
		Response clientPostResponse = null;

		try {
			WebClient webClient = WebClient.create(p_uri);

			// Post API
			m_logger.debug("postRestAPI Send Post");
			clientPostResponse = webClient
				.type(MediaType.APPLICATION_JSON_TYPE)
				.accept(MediaType.APPLICATION_JSON_TYPE)
				.post(p_jsonData);
			
			String retValue = clientPostResponse.readEntity(String.class);
			webClient.close();
			
			return retValue;
		} catch (Exception ex) {
			return "FAILED";
		}
	}
}

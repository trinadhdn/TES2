package com.adp.wfnddt.objectmanager.mobile;

import java.io.IOException;

import javax.xml.datatype.DatatypeConfigurationException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.adp.wfnddt.aspects.Step;
import com.adp.wfnddt.core.DDTController;
import com.adp.wfnddt.core.DDTFrameworkException;
import com.adp.wfnddt.objectmanager.DefaultMethod;
import com.adp.wfnddt.objectmanager.WebComboBox;
import com.adp.wfnddt.objectmanager.DefaultMethod.TypeOfMethod;

import io.appium.java_client.AppiumDriver;

public class AppListBox extends WebComboBox {
	
	private AppiumDriver<WebElement> m_AppDriver = DDTController.getMobileDriver();
	private WebDriverWait m_AppDriverWait = DDTController.getMobileDriverWait();

	public AppListBox(String p_selector) {
		super(p_selector);
	}

	public AppListBox(WebElement p_object) {
		super(p_object);
	}

	@Step(Params = { "Value" })
	@DefaultMethod(MethodType = TypeOfMethod.Action)
	public void select(String p_value) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		if (p_value.trim().contentEquals(""))
			return;
		findObject();
		waitForVisibility();
		
		// Click on the listbox
		getObject().click();

		// Wait for the options to appear and click on the option
		m_AppDriverWait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//android.widget.ListView/android.widget.CheckedTextView")));
		m_AppDriver.findElement(By.xpath("//android.widget.ListView/android.widget.CheckedTextView[@text='" + p_value + "']")).click();
		
	}
}

package com.adp.wfnddt.mailverification;

/**
 * @author UbbaraHa
 */

public class EmailConfig {

	private String host;
	private String port;
	private String protocol ;
	private String userId;
	private String password;
	
	/**
	 * Constructor that defaults the protocol to "imap"
	 */
	public EmailConfig(){
		this.protocol = "imap"; // set to default
	}
	
	/**
	 * Constructor that takes HOST,PORT,USERID,PASSWORD and defaults PROTPCOL to 'imap'.
	 * 
	 * @param _host
	 * @param _port
	 * @param _userId
	 * @param _password
	 */
	public EmailConfig(String _host,String _port,String _userId,String _password){
		this.protocol = "imap"; // set to default
		this.host = _host;
		this.port = _port;
		this.userId = _userId;
		this.password = _password;
		
	}
	
	/**
	 * Constructor that takes PROTOCOL, HOST,PORT,USERID,PASSWORD.
	 * 
	 * @param _protocol
	 * @param _host
	 * @param _port
	 * @param _userId
	 * @param _password
	 */
	public EmailConfig(String _protocol,String _host,String _port,String _userId,String _password){
		this.protocol = _protocol;
		this.host = _host;
		this.port = _port;
		this.userId = _userId;
		this.password = _password;
	}

	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public String getPort() {
		return port;
	}

	public void setPort(String port) {
		this.port = port;
	}

	public String getProtocol() {
		return protocol;
	}

	public void setProtocol(String protocol) {
		this.protocol = protocol;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
}

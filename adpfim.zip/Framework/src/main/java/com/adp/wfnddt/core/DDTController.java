/**
 * 
 */
package com.adp.wfnddt.core;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.security.AccessController;
import java.security.PrivilegedAction;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.adp.wfnddt.mailverification.EmailConfig;
import com.adp.wfnddt.results.DDTResultsReporter;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import io.appium.java_client.AppiumDriver;
import net.lightbody.bmp.BrowserMobProxy;
import net.lightbody.bmp.core.har.Har;

/**
 * @author autoxpert
 *
 */
public class DDTController {
	public enum BrowserType {
		InternetExplorer32, InternetExplorer64, Firefox32, Firefox64, Chrome32, Chrome64, Edge, Safari
	};

	public enum E_OSs {
		Windows, Linux, MacOSX, Unknown_OS
	}

	public enum TestDeviceType {
		Desktop, Mobile, Tablet
	}

	public enum Mobile_AccessType {
		ADPMobileApp, Browser
	}

	public enum Mobile_OSName {
		Android, iOS
	}

	public enum Mobile_BrowserType {
		Chrome, Firefox, Safari
	}

	private static Logger m_logger = null;
	private static boolean m_bCLIBrowser = false;
	private static boolean m_bCLIRunName = false;
	private static boolean m_bCLIRunID = false;
	private static boolean m_bCLIWfnEnv = false;
	private static WebDriver m_webDriver = null;
	private static WebDriverWait m_wait = null;
	private static DDTResultsReporter m_ddtResultsReporter = null;
	private static E_OSs m_eOS;
	private static String m_userHome = null;

	// Runtime DDT execution controls
	private static BrowserType m_browserType = BrowserType.InternetExplorer32;
	private static String m_wfnEnv = "AUTO1"; // DIT1, DIT2, FIT1, FIT2, AUTO1,
												// AUTO2, IPEFULL, IPESLIM
	private static String m_profResource = "!none";
	private static LoginProfile m_loginProfile = null;
	private static String m_runName = "DDT_Run_Local";
	private static int m_runID = -1;
	private static String m_ALMDomain = "";
	private static String m_ALMProject = "";
	private static String m_Custom = "";
	private static String m_getResultReportStore = null;
	private static String m_strScreenshotPath = null;
	private static String m_strScreenshotURL = null;
	private static final String m_oracleScriptServiceHost = /* "localhost:45669"; */ "cdlautowfnag01/WFNAutoOracleScriptServices";
	private static final String m_clientDBDMLServiceHost = /* "localhost:45669/OracleScriptWebServices"; */ "cdlautowfnag01/WFNAutoOracleScriptServices";
	private static final String m_ScreenshotBasePathALMRun = "\\\\cdlisilon01-cifs.cdl.rose.us.adp\\wfn\\DDT_Snapshots\\";
	private static final String m_strResultProcessorHostname = "10.0.2.140:9080";
	private static final String m_ScreenshotURLBase = "http://cdlautowfnrpt/ScreenshotDDT/";
	private static final long m_lMaxWait = 90;

	private static boolean m_stopExecutionOnException = true;
	private static boolean m_stopExecution = false;

	// Mobile controls
	private static AppiumDriver<WebElement> m_mobileDriver = null;
	private static WebDriverWait m_mobileWait = null; // ?

	private static TestDeviceType m_TestDeviceType = TestDeviceType.Desktop;
	private static Mobile_AccessType m_MobileAccessType = Mobile_AccessType.Browser;
	private static Mobile_OSName m_MobileOSName = Mobile_OSName.Android;
	private static Mobile_BrowserType m_MobileBrowserType = Mobile_BrowserType.Chrome;
	private static String m_MobileDeviceConfig = "";
	private static String m_RemoteBrowserConfig = "";
	private static boolean m_UseAppDriver = false;

	// Remote Servers
	private static String m_AppiumRemoteURL = "";
	private static String m_SeleniumRemoteURL = "";
	private static boolean m_isMobileRemoteServer = false;
	private static boolean m_isDesktopRemoteServer = false;

	// Performance
	private static boolean m_capturePerfMetrics = false;
	private static BrowserMobProxy m_bmpServer = null;
	private static final String m_harFileLocation = "\\\\cdlisilon01-cifs.cdl.rose.us.adp\\wfn\\Automation\\Performance\\har files";

	// Splunk
	private static boolean m_captureSplunkMetrics = true;
	private static boolean m_isExperitest = false;
	private static boolean m_isPerfecto = false;
	private static boolean m_captureConsoleLogs = false;
	
	//Screenshots
	private static HashMap<String,File> m_screenshotMap = new HashMap<>();
	
	//Email Verification
	public static enum MailBox {
		ADP_MAIL, POCROOT_MAIL
	};

	private static final EmailConfig MAIL_CONFIG_POCROOT = new EmailConfig("imap", "webmail1.espoc.pocroot.com", "993", "espoc\\CDLVDIMailbox", "ADPadp11");
	private static final EmailConfig MAIL_CONFIG_ADP = new EmailConfig("imap", "webmail1.es.ad.adp.com", "993", "es\\autoxpert", "adpadp");

	static {
		String strOS = DDTController.getSysProperty("os.name");

		if (strOS != null) {
			try {
				if (strOS.startsWith("Windows")) {
					strOS = "Windows";
				} else if (strOS.equals("Mac OS X")) {
					strOS = "MacOSX";
				}

				m_eOS = Enum.valueOf(E_OSs.class, strOS);

				switch (m_eOS) {
				case Windows:
					m_userHome = System.getenv("HOMEDRIVE") + System.getenv("HOMEPATH");
					break;
				case MacOSX:
				case Linux:
					m_userHome = System.getenv("HOME");
					break;
				default:
					m_logger.error("DDT execution is not supported on OS: " + strOS);
					m_eOS = E_OSs.Unknown_OS;
					break;
				}
			} catch (IllegalArgumentException iaEx) {
				m_logger.error("Error getting enum value for OS: " + strOS, iaEx);
				m_eOS = E_OSs.Unknown_OS;
			}
		} else {
			m_logger.error("Error getting value of os.name system property.");
			m_eOS = E_OSs.Unknown_OS;
		}
	}

	public static E_OSs getOS() {
		return m_eOS;
	}

	public static String getUserHome() {
		return m_userHome;
	}

	/*
	 * Must be called first when running from command line;
	 */
	public static String[] processDDTArguments(String[] p_args) throws DDTFrameworkException {
		String[] cukeArgs = null;
		List<String> adjArgs = new ArrayList<String>(p_args.length);
		int iPos = 0;
		String invalidBrowserType = null;

		for (int iIdx = 0; iIdx < p_args.length; iIdx++) {
			if (p_args[iIdx].equals("-browserType")) {
				iIdx++;
				switch (p_args[iIdx]) {
				case "IE32":
					m_browserType = BrowserType.InternetExplorer32;
					m_bCLIBrowser = true;
					break;
				case "IE64":
					m_browserType = BrowserType.InternetExplorer64;
					m_bCLIBrowser = true;
					break;
				case "Firefox32":
					m_browserType = BrowserType.Firefox32;
					m_bCLIBrowser = true;
					break;
				case "Firefox64":
					m_browserType = BrowserType.Firefox64;
					m_bCLIBrowser = true;
					break;
				case "Chrome32":
					m_browserType = BrowserType.Chrome32;
					m_bCLIBrowser = true;
					break;
				case "Chrome64":
					m_browserType = BrowserType.Chrome64;
					m_bCLIBrowser = true;
					break;
				case "Edge":
					m_browserType = BrowserType.Edge;
					m_bCLIBrowser = true;
					break;
				default:
					invalidBrowserType = p_args[iIdx];
					break;
				}
			} else if (p_args[iIdx].equals("-runName")) {
				iIdx++;
				m_runName = p_args[iIdx];
				m_bCLIRunName = true;
			} else if (p_args[iIdx].equals("-runID")) {
				iIdx++;

				try {
					m_runID = Integer.decode(p_args[iIdx]);
					m_bCLIRunID = true;
				} catch (NumberFormatException nfEx) {
					throw new DDTFrameworkException(DDTController.class, "Invalid runID - not numeric", nfEx);
				}
				// } else if (p_args[iIdx].equals("-loginProfile")) {
				// iIdx++;
				// loadLoginProfiles(p_args[iIdx]);
			} else if (p_args[iIdx].equals("-wfnEnv")) {
				iIdx++;
				m_wfnEnv = p_args[iIdx].toUpperCase();
				m_bCLIWfnEnv = true;
			} else if (p_args[iIdx].equals("-ALMDomain")) {
				iIdx++;
				m_ALMDomain = p_args[iIdx];
			} else if (p_args[iIdx].equals("-Custom")) {
				iIdx++;
				m_Custom = p_args[iIdx];
			} else if (p_args[iIdx].equals("-ALMProject")) {
				iIdx++;
				m_ALMProject = p_args[iIdx];
			} else {
				adjArgs.add(p_args[iIdx]);
				iPos++;
			}
		}

		// If report.path is provided and logfile.path is not, default
		// logfile.path
		// to report.Path.
		m_getResultReportStore = getSysProperty("report.path");

		if (m_getResultReportStore != null && getSysProperty("logfile.path") == null) {
			setSysProperty("logfile.path", m_getResultReportStore);
		}

		m_logger = DDTLoggerManager.getLogger(DDTController.class);

		if (invalidBrowserType != null) {
			m_logger.error("Invalid value for -browserType argument: " + invalidBrowserType);
		}

		if (m_runName == null) {
			throw new DDTFrameworkException(DDTLoggerManager.class, "Missing -runName argument: ");
		}

		cukeArgs = new String[iPos + 2];

		for (int iIdx2 = 0; iIdx2 < iPos; iIdx2++) {
			String cukeArg = adjArgs.get(iIdx2);

			if (cukeArg.startsWith("classpath:")) {
				cukeArgs[iIdx2++] = "--glue";
				cukeArgs[iIdx2++] = "com.adp.wfnddt.cukeextensions";
			}

			cukeArgs[iIdx2] = cukeArg;
		}

		return cukeArgs;
	}

	public static String getRunName() {
		return m_runName;
	}

	public static String getCustom() {
		return m_Custom;
	}

	public static void setCustom(String p_Custom) {
		m_Custom = p_Custom;
	}

	public static void setConsoleLogs(boolean p_Set) {
		m_captureConsoleLogs = p_Set;
	}

	public static boolean getConsoleLogs() {
		return m_captureConsoleLogs;
	}

	private static void setReportStore() throws DDTFrameworkException {
		// If report.path is provided and logfile.path is not, default
		// logfile.path
		// to report.Path.
		m_getResultReportStore = getSysProperty("report.path");

		if (m_getResultReportStore != null && getSysProperty("logfile.path") == null) {
			setSysProperty("logfile.path", m_getResultReportStore);
		}

		return;
	}

	/*
	 * Must be called first after setting system properties when running from JUnit/CukesRunner;
	 */
	public static void setRunName(String p_runName) throws DDTFrameworkException {
		if (!m_bCLIRunName) {
			m_runName = p_runName;
			setReportStore();

			if (m_logger == null) {
				m_logger = DDTLoggerManager.getLogger(DDTController.class);
			}
		}

		return;
	}

	public static int getRunID() {
		return m_runID;
	}

	public static void setRunID(int p_runID) {
		if (!m_bCLIRunID) {
			m_runID = p_runID;

			if (m_logger == null) {
				m_logger = DDTLoggerManager.getLogger(DDTController.class);
			}
		}

		return;
	}

	public static String getALMDomain() {
		return m_ALMDomain;
	}

	public static String getALMProject() {
		return m_ALMProject;
	}

	public static String getResultReportStore() {
		return m_getResultReportStore;
	}

	public static BrowserType getBrowserType() {
		return m_browserType;
	}

	public static void setBrowserType(BrowserType p_value) {
		if (!m_bCLIBrowser) {
			m_browserType = p_value;
		}

		return;
	}

	/*
	 * This mutator is only to be used by the WFN login process when it recognizes one of the special PlannedHostnames for regression runs.
	 */
	public static void setBrowserTypeBasedOnPlannedHostname(BrowserType p_value) {
		m_browserType = p_value;
		return;
	}

	public static String getWfnEnvironment() {
		return m_wfnEnv;
	}

	public static void setWfnEnvironment(String p_wfnEnv) {
		if (!m_bCLIWfnEnv) {
			m_wfnEnv = p_wfnEnv;
		}

		return;
	}

	public static String getOracleScriptServiceHost() {
		return m_oracleScriptServiceHost;
	}

	public static String getClientDBDMLServiceHost() {
		return m_clientDBDMLServiceHost;
	}

	public static String getResultProcessorHostname() {
		return m_strResultProcessorHostname;
	}

	/*
	 * This function is used only by CukesRunner classes.
	 */
	public static void createResultsReporter() throws DDTFrameworkException {
		if (m_getResultReportStore != null) {
			String resultsFileNoExt = m_getResultReportStore + "/" + m_runName;
			m_strScreenshotPath = m_getResultReportStore;
			m_ddtResultsReporter = new DDTResultsReporter(resultsFileNoExt, m_strScreenshotPath, null);
		} else {
			throw new DDTFrameworkException(DDTController.class, "The run name has not been set yet.");
		}

		return;
	}

	/*
	 * This function is used only by the CucumberRunDDTTest class.
	 */
	public static void createResultsReporterCLI() throws DDTFrameworkException {
		// Set m_getResultReportStore
		setReportStore();

		if (m_getResultReportStore != null) {
			String resultsFileNoExt = m_getResultReportStore + "/" + m_runName;
			m_strScreenshotPath = (m_runID > 0) ? establishScreenshotFolder() // Run
																				// from
																				// ALM
					: m_getResultReportStore; // Stand-alone CLI Run

			m_ddtResultsReporter = new DDTResultsReporter(resultsFileNoExt, m_strScreenshotPath, m_strScreenshotURL);
		} else {
			throw new DDTFrameworkException(DDTController.class, "The run name has not been set yet.");
		}

		return;
	}

	public static String getScreenshotPath() {
		return m_strScreenshotPath;
	}

	public static WebDriver getWebDriver() {
		return m_webDriver;
	}

	public static void setWebDriver(WebDriver p_webDriver, long p_lMaxWait) {
		m_webDriver = p_webDriver;
		m_wait = (p_webDriver != null) ? new WebDriverWait(m_webDriver, p_lMaxWait) : null;
		return;
	}

	public static WebDriverWait getWebDriverWait() {
		return m_wait;
	}

	public static DDTResultsReporter getResultsReporter() {
		return m_ddtResultsReporter;
	}

	public static String getSysProperty(String p_propName) {
		return System.getProperty(p_propName);
	}

	public static String setSysProperty(String p_propName, String p_propValue) throws DDTFrameworkException {
		String strSysPropValue = null;

		try {
			strSysPropValue = AccessController.doPrivileged(new PrivilegedAction<String>() {
				public String run() {
					return System.setProperty(p_propName, p_propValue);
				}
			});
		} catch (NullPointerException npEx) {
			throw new DDTFrameworkException(DDTController.class, "Unable to set system property.");
		}

		return strSysPropValue;
	}

	public static LoginProfile getLoginProfile(String p_profResource) throws DDTFrameworkException {
		JsonObject jsonObjects;
		BufferedReader buffRdr;
		LoginProfile loginProf = null;

		// if (m_wfnEnv.startsWith("DIT") || m_wfnEnv.startsWith("FIT")) {
		if (m_profResource != p_profResource) {
			try {
				InputStream in = DDTController.class.getResourceAsStream("/LoginProfiles/" + p_profResource + ".json");
				buffRdr = new BufferedReader(new InputStreamReader(in));
				JsonParser parser = new JsonParser();
				jsonObjects = parser.parse(buffRdr).getAsJsonObject();
				JsonElement jsonElem = jsonObjects.get("LoginProfiles");
				JsonArray jsonArray = jsonElem.getAsJsonArray();
				int iProfileCnt = jsonArray.size();

				for (int iIdx = 0; iIdx < iProfileCnt; iIdx++) {
					JsonElement jsonElem2 = jsonArray.get(iIdx);
					JsonObject jsonObj2 = jsonElem2.getAsJsonObject();

					JsonElement jsonElem3 = jsonObj2.get("Env");

					if (jsonElem3 != null && jsonElem3.getAsString().equals(m_wfnEnv)) {
						loginProf = new LoginProfile();

						JsonElement jsonElem4 = jsonObj2.get("URL");
						if (jsonElem4 != null) {
							loginProf.setURL(jsonElem4.getAsString());
						}

						jsonElem4 = jsonObj2.get("ClientId");
						if (jsonElem4 != null) {
							loginProf.setClientID(jsonElem4.getAsString());
						}

						jsonElem4 = jsonObj2.get("SellingRegion");
						if (jsonElem4 != null) {
							loginProf.setSellingRegion(jsonElem4.getAsString());
						}

						jsonElem4 = jsonObj2.get("VPDKey");
						if (jsonElem4 != null) {
							loginProf.setVPDKey(jsonElem4.getAsString());
						}

						jsonElem4 = jsonObj2.get("PractUser");
						if (jsonElem4 != null) {
							loginProf.setPractUserCredentials(buildUserCredential(jsonElem4, loginProf));
						}

						jsonElem4 = jsonObj2.get("EEUser");
						if (jsonElem4 != null) {
							loginProf.setEEUserCredentials(buildUserCredential(jsonElem4, loginProf));
						}

						jsonElem4 = jsonObj2.get("MgrUser");
						if (jsonElem4 != null) {
							loginProf.setMgrUserCredentials(buildUserCredential(jsonElem4, loginProf));
						}

						jsonElem4 = jsonObj2.get("UAUser");
						if (jsonElem4 != null) {
							loginProf.setUAUserCredentials(buildUserCredential(jsonElem4, loginProf));
						}

						break;
					}
				}

				m_loginProfile = loginProf;
				m_profResource = p_profResource;
			} catch (DDTFrameworkException dfEx) {
				throw dfEx;
			} catch (Exception e) {
				throw new DDTFrameworkException(DDTController.class, String.format("Unable to parse JSON object file: %1$s", p_profResource), e);
			}
		}
		// }

		return m_loginProfile;
	}

	private static LoginProfile.UserCredential buildUserCredential(JsonElement p_jsonElement, LoginProfile p_loginProf) throws DDTFrameworkException {
		LoginProfile.UserCredential userCred = null;

		try {
			JsonObject jsonObj41 = p_jsonElement.getAsJsonObject();

			JsonElement jsonElem41 = jsonObj41.get("UserID");
			JsonElement jsonElem42 = jsonObj41.get("Passwd");

			if (jsonElem41 != null && jsonElem42 != null) {
				userCred = p_loginProf.new UserCredential(jsonElem41.getAsString(), jsonElem42.getAsString());
			}
		} catch (Exception isEx) {
			throw new DDTFrameworkException(DDTController.class, "Unexpected error while parsing login profile file: ", isEx);
		}

		return userCred;
	}

	private static String establishScreenshotFolder() throws DDTFrameworkException {
		// Generate folder name from current system date (e.g., SEPT2017_DDT).
		Date dtNow = new Date();
		String strMonthYear = String.format("%1$tb%1$tY", dtNow);
		StringBuilder sbScreenshotFolder = new StringBuilder(m_ScreenshotBasePathALMRun);
		sbScreenshotFolder.append(strMonthYear.toUpperCase());
		sbScreenshotFolder.append("_DDT");
		String strScreenshotPathALMRun = sbScreenshotFolder.toString();

		sbScreenshotFolder.setLength(0);
		sbScreenshotFolder.append(m_ScreenshotURLBase);
		sbScreenshotFolder.append(strMonthYear.toUpperCase());
		sbScreenshotFolder.append("_DDT");
		m_strScreenshotURL = sbScreenshotFolder.toString();

		// Create folder if it does not exist.
		File ssFolder = new File(strScreenshotPathALMRun);

		if (!ssFolder.exists()) {
			if (!ssFolder.mkdir()) {
				throw new DDTFrameworkException(DDTController.class, "Unable to create snapshot folder.");
			}
		}

		return strScreenshotPathALMRun;
	}

	public static long getMaxWaitTime() {
		return m_lMaxWait;
	}

	public static boolean stopExecutionOnException() {
		return m_stopExecutionOnException;
	}

	public static void setStopExecutionOnException(boolean m_stopExecutionOnException) {
		DDTController.m_stopExecutionOnException = m_stopExecutionOnException;
	}

	public static boolean stopExecution() {
		return m_stopExecution;
	}

	public static void setStopExecution(boolean m_stopExecution) {
		DDTController.m_stopExecution = m_stopExecution;
	}

	// Selenium Grid
	public static String getSeleniumGridURL() {
		return m_SeleniumRemoteURL;
	}

	public static void setSeleniumGridURL(String m_SeleniumRemoteURL) {
		DDTController.m_SeleniumRemoteURL = m_SeleniumRemoteURL;
	}

	// Mobile controls
	public static AppiumDriver<WebElement> getMobileDriver() {
		return m_mobileDriver;
	}

	public static void setMobileDriver(AppiumDriver<WebElement> p_MobileDriver, long p_lMaxWait) {
		m_mobileDriver = p_MobileDriver;
		m_mobileWait = (p_MobileDriver != null) ? new WebDriverWait(m_mobileDriver, p_lMaxWait) : null;

		return;
	}

	public static WebDriverWait getMobileDriverWait() {
		return m_mobileWait;
	}

	public static TestDeviceType getTestDeviceType() {
		return m_TestDeviceType;
	}

	public static void setTestDeviceType(TestDeviceType m_TestDeviceType) {
		DDTController.m_TestDeviceType = m_TestDeviceType;
	}

	public static Mobile_AccessType getMobileAccessType() {
		return m_MobileAccessType;
	}

	public static void setMobileAccessType(Mobile_AccessType m_MobileAccessType) {
		DDTController.m_MobileAccessType = m_MobileAccessType;
	}

	public static Mobile_OSName getMobileOSName() {
		return m_MobileOSName;
	}

	public static void setMobileOSName(Mobile_OSName m_MobileOSName) {
		DDTController.m_MobileOSName = m_MobileOSName;
	}

	public static Mobile_BrowserType getMobileBrowserType() {
		return m_MobileBrowserType;
	}

	public static void setMobileBrowserType(Mobile_BrowserType m_MobileBrowserType) {
		DDTController.m_MobileBrowserType = m_MobileBrowserType;
	}

	public static String getMobileDeviceConfig() {
		return m_MobileDeviceConfig;
	}

	public static void setMobileDeviceConfig(String m_MobileDeviceConfig) {
		DDTController.m_MobileDeviceConfig = m_MobileDeviceConfig;
	}

	// Remote Servers
	public static String getAppiumRemoteURL() {
		return m_AppiumRemoteURL;
	}

	public static void setAppiumRemoteURL(String m_AppiumRemoteURL) {
		DDTController.m_AppiumRemoteURL = m_AppiumRemoteURL;
		if (!m_AppiumRemoteURL.contentEquals(""))
			m_isMobileRemoteServer = true;
		
		if (m_AppiumRemoteURL.contains("experitest") || m_AppiumRemoteURL.contains("10.223.21.246"))
			m_isExperitest = true;
		
		if (m_AppiumRemoteURL.contains("perfecto"))
			m_isPerfecto = true;
	}

	public static String getSeleniumRemoteURL() {
		return m_SeleniumRemoteURL;
	}

	public static void setSeleniumRemoteURL(String m_SeleniumRemoteURL) {
		DDTController.m_SeleniumRemoteURL = m_SeleniumRemoteURL;
		if (!m_SeleniumRemoteURL.contentEquals(""))
			m_isDesktopRemoteServer = true;
		
		if (m_SeleniumRemoteURL.contains("experitest") || m_SeleniumRemoteURL.contains("10.223.21.246"))
			m_isExperitest = true;
		
		if (m_SeleniumRemoteURL.contains("perfecto"))
			m_isPerfecto = true;
	}

	public static boolean isMobileRemoteServer() {
		return m_isMobileRemoteServer;
	}

	public static void setMobileRemoteServer(boolean isMobileRemoteServer) {
		DDTController.m_isMobileRemoteServer = isMobileRemoteServer;
	}

	public static boolean isDesktopRemoteServer() {
		return m_isDesktopRemoteServer;
	}

	public static void setDesktopRemoteServer(boolean isDesktopRemoteServer) {
		DDTController.m_isDesktopRemoteServer = isDesktopRemoteServer;
	}

	public static boolean isMobile() {
		return DDTController.getTestDeviceType().equals(TestDeviceType.Mobile);
	}

	public static boolean isTablet() {
		return DDTController.getTestDeviceType().equals(TestDeviceType.Tablet);
	}

	public static boolean isUseAppDriver() {
		return m_UseAppDriver;
	}

	public static void setUseAppDriver(boolean m_UseAppDriver) {
		DDTController.m_UseAppDriver = m_UseAppDriver;
	}

	// Performance
	public static boolean isCapturePerfMetrics() {
		return m_capturePerfMetrics;
	}

	public static void setCapturePerfMetrics(boolean capturePerfMetrics) {
		DDTController.m_capturePerfMetrics = capturePerfMetrics;
	}

	public static void setBMPServer(BrowserMobProxy bmpServer) {
		DDTController.m_bmpServer = bmpServer;
	}

	public static BrowserMobProxy getBMPServer() {
		return m_bmpServer;
	}

	public static String getHarfilelocation() {
		return m_harFileLocation;
	}

	public static void generateHAR() throws IOException {
		if (isCapturePerfMetrics() && m_bmpServer != null) {
			Har har = m_bmpServer.getHar();
			har.getLog().setComment(GlobalVariables.getVariable("FEATURE FILE"));

			String harFileFolder = (m_runID > 0) ? m_harFileLocation : DDTController.getSysProperty("report.path");
			String harName = (m_runID > 0) ? m_ALMProject + "-" + m_runID + "-" + m_runName + "-" + m_wfnEnv + "-" + m_browserType + ".har" : "Local-" + m_runName + ".har";
			File harFile = new File(harFileFolder + "\\" + harName);
			har.writeTo(harFile);

			m_bmpServer.stop();
		}
	}

	public static void setCaptureSplunkMetrics(boolean captureSplunkMetrics) {
		DDTController.m_captureSplunkMetrics = captureSplunkMetrics;
	}

	public static boolean isCaptureSplunkMetrics() {
		//if (m_runID <= 0) return false;
			
		return m_captureSplunkMetrics;
	}

	public static EmailConfig getMailConfigPocroot() {
		return MAIL_CONFIG_POCROOT;
	}

	public static EmailConfig getMailConfigAdp() {
		return MAIL_CONFIG_ADP;
	}
	
	public static boolean isExperitest(){
		return m_isExperitest;
	}
	
	public static boolean isPerfecto(){
		return m_isPerfecto;
	}
	
	public static HashMap<String, File> getScreenshotMap() {
		return m_screenshotMap;
	}

	public static void addToScreenshotMap(String p_screenshotPath, File p_screenshotFile) {
		m_screenshotMap.put(p_screenshotPath, p_screenshotFile);
	}

	public static String getRemoteBrowserConfig() {
		return m_RemoteBrowserConfig;
	}

	public static void setRemoteBrowserConfig(String m_RemoteBrowserConfig) {
		DDTController.m_RemoteBrowserConfig = m_RemoteBrowserConfig;
	}
}

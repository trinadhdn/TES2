package com.adp.wfnddt.commonmethods;

import static com.adp.wfnddt.commonmethods.General.sleep;
import static com.adp.wfnddt.commonmethods.General.waitForGridSpinnerToComplete;

import java.io.IOException;
import java.util.List;

import javax.xml.datatype.DatatypeConfigurationException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.adp.wfnddt.core.DDTController;
import com.adp.wfnddt.core.DDTController.BrowserType;
import com.adp.wfnddt.core.DDTFrameworkException;
import com.adp.wfnddt.objectmanager.WebLink;
import com.adp.wfnddt.objectmanager.WebObject;

//import com.adp.wfnddt.objectmanager.WebObject;
public class Navigation {

	public void navigateToPage(String p_megaMenu, String p_link) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		if (DDTController.getWebDriver().findElements(By.xpath("//div[@id='wfn_nav_top']")).size() > 0) { // If New Shell exists
			navigateToNewShellPage(p_megaMenu, p_link);
			return;
		}
		if (p_megaMenu == "Setup")
			p_megaMenu = "prac" + p_megaMenu;

		String expandedMegaMenuXpath = String.join("", "//*[@id='", p_megaMenu, "_ttd']//div[text()='SWITCH TO EXPANDED MENU']");
		String subMenuLink = "XPATH://div[@class='expandedMenuDiv']//div[contains(@id,'" + p_megaMenu + "_ttd_')]/span[text()='" + p_link + "']";

		// Click the Mega Menu
		WebLink megaMenu = new WebLink(String.join("", "CSS:span[id='", p_megaMenu, "_navItem_label']"));
		if (DDTController.getBrowserType() == BrowserType.InternetExplorer32 || DDTController.getBrowserType() == BrowserType.InternetExplorer64) {
			megaMenu.robotClick(0, 75);
		} else {
			megaMenu.click();
		}

		sleep(2);
		if (DDTController.getWebDriver().findElements(By.xpath(expandedMegaMenuXpath)).size() != 0) {
			DDTController.getWebDriver().findElement(By.xpath(expandedMegaMenuXpath)).click();
		}

		// Click the Sub Menu link
		WebLink subMenu = new WebLink(subMenuLink);
		subMenu.click();
		waitForGridSpinnerToComplete();
		sleep(2); // added to let the page settle first after spinner disappears
		
		//workaround for validation table tech refresh that expand all menu
		if (p_link.equalsIgnoreCase("VALIDATION TABLES")){
			if (DDTController.getWebDriver().findElements(By.xpath("//span[text()='Collapse All']/..")).size() != 0) {
				DDTController.getWebDriver().findElement(By.xpath("//span[text()='Collapse All']/..")).click();
				sleep (2);
			}
		}
		return;
	}

	public void navigateToPageUA(String p_megaMenu, String p_link) throws IOException, DatatypeConfigurationException, DDTFrameworkException {

		String expandedMegaMenuXpath = String.join("", "//div[text()='SWITCH TO EXPANDED MENU']");
		String subMenuLink = "XPATH://div[@class='expandedMenuDiv']//div[@class='dijit dijitReset revitMegaItem']//span[text()='" + p_link + "']";

		// Expanding Menu by clicking on Client
		// DDTController.getWebDriver().findElement(By.xpath("//span[@class='dijit dijitReset dijitInline revitNavItemClickable revitNavItem']")).click();

		// Click the Mega Menu
		WebLink megaMenu = new WebLink(String.join("", "XPATH://span[contains(@id,'", p_megaMenu, "_navItem_label')]"));
		if (DDTController.getBrowserType() == BrowserType.InternetExplorer32 || DDTController.getBrowserType() == BrowserType.InternetExplorer64) {
			megaMenu.robotClick(0, 75);
		} else {
			megaMenu.click();
		}

		sleep(2);
		if (DDTController.getWebDriver().findElements(By.xpath(expandedMegaMenuXpath)).size() != 0) {
			DDTController.getWebDriver().findElement(By.xpath(expandedMegaMenuXpath)).click();
		}

		// Click the Sub Menu link
		WebLink subMenu = new WebLink(subMenuLink);
		subMenu.click();
		waitForGridSpinnerToComplete();
		sleep(2); // added to let the page settle first after spinner disappears
		return;
	}

	public void navigateToNewShellPage(String p_megaMenu, String p_link) throws IOException, DatatypeConfigurationException, DDTFrameworkException {

		new WebObject("XPATH://*[@id='wfn_main']").exists(180);
		sleep(1);

		String expandedMegaMenuXpath = String.join("", "//div[text()='EXPAND MENU']");
		String subMenuLink = "XPATH://div[contains(@id,'wfnnav_top_item_') and contains(translate(@id,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'" + p_megaMenu.toLowerCase() + "')]//div[@class='wfnnav-sub-item']/div[@class='wfnnav-ter-item']/button[contains(@class,'wfnnav-ter-item--button') and translate(text(),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')='" + p_link.toLowerCase() + "']";

		// Click the Mega Menu
		WebLink megaMenu = new WebLink(String.join("", "XPATH://div[contains(@id,'wfnnav_top_item_') and contains(translate(@id,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'", p_megaMenu.toLowerCase(), "')]"));
		megaMenu.waitForClickable();
		// sleep(20);
		// if (DDTController.getBrowserType() == BrowserType.InternetExplorer32 || DDTController.getBrowserType() == BrowserType.InternetExplorer64) {
		// megaMenu.robotClick(0, 75);
		// } else {
		megaMenu.click();
		// }

		sleep(2);
		// Expanding Menu by clicking on Client
		if (DDTController.getWebDriver().findElements(By.xpath("//div[@class='wfnnav-sub-expand--title' and text()='EXPAND MENU']")).size() > 0) {
			for (WebElement webTemp : DDTController.getWebDriver().findElements(By.xpath("//div[@class='wfnnav-sub-expand--title' and text()='EXPAND MENU']"))) {
				if (webTemp.isDisplayed()) {
					webTemp.click();
				}
			}
		}

		List<WebElement> expandMenu = DDTController.getWebDriver().findElements(By.xpath(expandedMegaMenuXpath));
		if (expandMenu.size() != 0 && expandMenu.get(0).isDisplayed()) {
			DDTController.getWebDriver().findElement(By.xpath(expandedMegaMenuXpath)).click();
		}

		if (p_link.contains("|")) {
			String p_pageSectionHeader = p_link.split("\\|")[0];
			String p_pagelink = p_link.split("\\|")[1];
			subMenuLink = "XPATH://div[@id='wfnnav_sub_expanded_" + p_megaMenu + "']//div[text()='" + p_pageSectionHeader + "']/..//div[@class='wfnnav-ter-item']//*[text()='" + p_pagelink + "']";
		}

		// Click the Sub Menu link
		WebLink subMenu = new WebLink(subMenuLink);
		subMenu.waitForClickable();
		new WebObject("XPATH://*[@id='homePageWrapper']").waitForClickable();
		subMenu.click();
		waitForGridSpinnerToComplete();
		sleep(5); // added to let the page settle first after spinner disappears
		
		//workaround for validation table tech refresh that expand all menu
				if (p_link.equalsIgnoreCase("VALIDATION TABLES")){
					if (DDTController.getWebDriver().findElements(By.xpath("//span[text()='Collapse All']/..")).size() != 0) {
						new WebObject("XPATH://span[text()='Collapse All']/..").scrollIntoViewClick();
						//DDTController.getWebDriver().findElement(By.xpath("//span[text()='Collapse All']"))..click();
						sleep (2);
					}
				}
		return;
	}
}

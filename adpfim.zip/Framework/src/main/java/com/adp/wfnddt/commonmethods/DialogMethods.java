package com.adp.wfnddt.commonmethods;

import static org.assertj.core.api.Assertions.*;

import java.io.IOException;
import com.adp.wfnddt.core.DDTFrameworkException;

public class DialogMethods {
	public static void downloadFile(String p_filePath) throws IOException, DDTFrameworkException, InterruptedException {
		Process autoItReturnVal = Runtime.getRuntime().exec(new String[] { "\\SeleniumDrivers\\DownloadFile.exe", p_filePath });
		autoItReturnVal.waitFor();
		if (autoItReturnVal.exitValue() == 2) {
			fail("Unable to download the file !!");
		}
	}

	public static void uploadFile(String p_filePath) throws IOException, DDTFrameworkException, InterruptedException {
		Process autoItReturnVal = Runtime.getRuntime().exec(new String[] { "\\SeleniumDrivers\\UploadFile.exe", p_filePath });
		autoItReturnVal.waitFor();
		if (autoItReturnVal.exitValue() == 2) {
			fail("Unable to upload the file !!");
		}
	}

	public static void ieSaveAs() throws IOException, DDTFrameworkException, InterruptedException {
		Process autoItReturnVal = Runtime.getRuntime().exec(new String[] { "\\SeleniumDrivers\\IESaveAs.exe"});
		autoItReturnVal.waitFor();
		if (autoItReturnVal.exitValue() == 2) {
			fail("Unable to open IE Save As !!");
		}
	}
}

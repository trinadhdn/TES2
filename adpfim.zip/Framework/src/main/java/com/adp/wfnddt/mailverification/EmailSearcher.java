package com.adp.wfnddt.mailverification;

import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

import javax.mail.Flags;
import javax.mail.Message;
import javax.mail.Message.RecipientType;
import javax.mail.MessagingException;
import javax.mail.search.BodyTerm;
import javax.mail.search.ComparisonTerm;
import javax.mail.search.FlagTerm;
import javax.mail.search.FromStringTerm;
import javax.mail.search.ReceivedDateTerm;
import javax.mail.search.RecipientStringTerm;
import javax.mail.search.SearchTerm;
import javax.mail.search.SentDateTerm;
import javax.mail.search.SubjectTerm;

import org.apache.log4j.Level;

import com.adp.wfnddt.core.DDTController;
import com.adp.wfnddt.core.DDTController.MailBox;
import com.adp.wfnddt.parammanager.ParamManager;

public class EmailSearcher {

	private EmailUtil emailUtil = new EmailUtil();
	private String m_dateFormat = "MM/dd/yyyy";

	public Message[] searchMailBox(MailBox mailBox, String folderToLookup, SearchTerm[] searchTerms) throws MessagingException, IOException {

		emailUtil.enableLog(Level.DEBUG);

		switch (mailBox) {
		case ADP_MAIL:
			emailUtil.setConfig(DDTController.getMailConfigAdp());
			break;

		case POCROOT_MAIL:
			emailUtil.setConfig(DDTController.getMailConfigPocroot());
			break;
		}

		// Set folder to be Searched
		emailUtil.setMailBoxFolder(folderToLookup);

		// Connect and search
		emailUtil.connectToMailBox();

		// Add conditions to Filter & search email
		emailUtil.addSeachCondition(searchTerms);
		Message[] messages = emailUtil.searchMails();

		// for Debugging only
		// emailUtil.displayEmailMessagesNewestOnTop(messages);

		return messages;
	}

	public Message[] searchMailBox(EmailConfig emailConfig, String folderToLookup, SearchTerm[] searchTerms) throws MessagingException, IOException {

		emailUtil.enableLog(Level.DEBUG);

		emailUtil.setConfig(emailConfig);

		// Set folder to be Searched
		emailUtil.setMailBoxFolder(folderToLookup);

		// Connect and search
		emailUtil.connectToMailBox();

		// Add conditions to Filter & search email
		emailUtil.addSeachCondition(searchTerms);
		Message[] messages = emailUtil.searchMails();

		// for Debugging only
		// emailUtil.displayEmailMessagesNewestOnTop(messages);

		return messages;
	}

	
	public void disconectMailBox() throws MessagingException {
		emailUtil.disconnectMailBox();
	}

	public Message[] filterEmails(Message[] messages, SearchTerm[] filterSearchTerms) throws MessagingException {
		if (filterSearchTerms != null) {
			ArrayList<Message> filteredMessages = new ArrayList<Message>();
			for (Message msg : messages) {
				boolean bMatchedAllTerms = true;
				for (SearchTerm term : filterSearchTerms) {
					bMatchedAllTerms = bMatchedAllTerms && msg.match(term);
				}

				if (bMatchedAllTerms)
					filteredMessages.add(msg);
			}
			return filteredMessages.toArray(new Message[0]);
		}
		return null;

	}

	public SearchTerm[] prepareSearchTermArray(ParamManager pm, String prefix) throws ParseException {
		HashMap<String, String> mapSearchTerms = groupSearchTermStrings(pm, prefix);
		return prepareSearchTermArray(mapSearchTerms);
	}

	public SearchTerm[] prepareSearchTermArray(HashMap<String, String> p_mapSearchTerms) throws ParseException {
		SearchTerm[] arrSearchTerms = prepareSearchTermList(p_mapSearchTerms).toArray(new SearchTerm[0]);
		return arrSearchTerms;
	}

	private HashMap<String, String> groupSearchTermStrings(ParamManager pm, String prefix) throws ParseException {
		HashMap<String, String> mapSearchTerms = new LinkedHashMap<>();
		for (String param : pm.getParamMap().keySet()) {
			if (param.trim().toUpperCase().startsWith(prefix) && !pm.getParamMap().get(param).trim().contentEquals("")) {
				String fieldName = param.trim().substring(prefix.length()).toUpperCase();
				mapSearchTerms.put(fieldName, pm.getParamMap().get(param));
			}
		}
		return mapSearchTerms;
	}

	private List<SearchTerm> prepareSearchTermList(HashMap<String, String> p_mapSearchTerms) throws ParseException {
		List<SearchTerm> searchList = new ArrayList<SearchTerm>();
		String subject = p_mapSearchTerms.get("SUBJECT");
		String body = p_mapSearchTerms.get("BODY");
		String from = p_mapSearchTerms.get("FROM");
		String recipient = p_mapSearchTerms.get("RECIPIENT");
		String recipientType = p_mapSearchTerms.get("RECIPIENT_TYPE");
		String receivedDate = p_mapSearchTerms.get("RECEIVED_DATE");
		String sentDate = p_mapSearchTerms.get("SENT_DATE");
		String unseen = p_mapSearchTerms.get("UNSEEN");

		if (null == subject) {
		} else {
			searchList.add(new SubjectTerm(subject));
		}

		if (null == body) {
		} else {
			searchList.add(new BodyTerm(body));
		}

		if (null == from) {
		} else {
			searchList.add(new FromStringTerm(from));
		}

		if (null == recipient) {
		} else {
			RecipientType _recipientType = null;
			if (null == recipientType) {
			} else if (recipientType.toUpperCase().equals("TO")) {
				_recipientType = (RecipientType) RecipientType.TO;
			} else if (recipientType.toUpperCase().equals("CC")) {
				_recipientType = (RecipientType) RecipientType.CC;
			} else if (recipientType.toUpperCase().equals("BCC")) {
				_recipientType = (RecipientType) RecipientType.BCC;
			}
			searchList.add(new RecipientStringTerm(_recipientType, recipient));
		}

		DateFormat dateFormat = new SimpleDateFormat(m_dateFormat);
		
		if (null == receivedDate) {
		} else {
			searchList.add(new ReceivedDateTerm(ComparisonTerm.EQ, dateFormat.parse(receivedDate)));
		}
		if (null == sentDate) {
		} else {
			searchList.add(new SentDateTerm(ComparisonTerm.EQ, dateFormat.parse(receivedDate)));
		}

		if (null == unseen) {
		} else if (unseen.equalsIgnoreCase("UNSEEN") || unseen.equalsIgnoreCase("true")) {
			searchList.add(new FlagTerm(new Flags(Flags.Flag.SEEN), false));
		} else if ( unseen.equalsIgnoreCase("false")) {
			searchList.add(new FlagTerm(new Flags(Flags.Flag.SEEN), true));
		} 
		    
		return searchList;
	}

	public String getdateFormat() {
		return m_dateFormat;
	}

	public void setdateFormat(String m_dateFormat) {
		this.m_dateFormat = m_dateFormat;
	}

}

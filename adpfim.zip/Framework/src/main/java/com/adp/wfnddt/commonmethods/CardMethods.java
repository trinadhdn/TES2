package com.adp.wfnddt.commonmethods;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.adp.wfnddt.core.DDTController;
import com.adp.wfnddt.core.DDTController.BrowserType;
import com.adp.wfnddt.core.DDTFrameworkException;
import com.adp.wfnddt.core.DDTLoggerManager;
import com.adp.wfnddt.objectmanager.BaseObject;
import com.adp.wfnddt.objectmanager.ObjectMap;
import com.adp.wfnddt.parammanager.ParamManager;
import static com.adp.wfnddt.commonmethods.General.convertToUTF8;

public class CardMethods extends BaseObject {

	protected static WebDriver m_webDriver = DDTController.getWebDriver();
	protected static WebDriverWait m_webDriverWait = DDTController.getWebDriverWait();
	private Logger m_logger = DDTLoggerManager.getLogger(CardMethods.class);

	// ****************************** Retrieve Methods
	// *************************************
	// Retrieve the card to find from param manager
	public HashMap<String, String> retrieveCardToFind(ParamManager pm) {
		HashMap<String, String> cardToFind = new LinkedHashMap<>();

		for (String param : pm.getParamMap().keySet()) {

			if (param.trim().toUpperCase().startsWith("CARDTOFIND_") && !pm.getParamMap().get(param).trim().contentEquals("")) {
				String fieldName = param.trim().substring(11).toUpperCase();
				cardToFind.put(fieldName, pm.getParamMap().get(param));
			} else if ((param.trim().toUpperCase().startsWith("ROWTOFIND_")) && !pm.getParamMap().get(param).trim().contentEquals("")) {
				String fieldName = param.trim().substring(10).toUpperCase();
				cardToFind.put(fieldName, pm.getParamMap().get(param));
			}
		}
		return cardToFind;
	}

	// Retrieve the Card Instance
	public int retrieveCardInstance(ParamManager pm) {
		int cardInstance = 1;

		for (String param : pm.getParamMap().keySet()) {
			if ((param.trim().equalsIgnoreCase("CARD_INSTANCE") || param.trim().equalsIgnoreCase("NUMBER_OF_INSTANCES_TO_FIND") || param.trim().equalsIgnoreCase("ROW_INSTANCE")) && !pm.getParamMap().get(param).trim().contentEquals("")) {
				cardInstance = Integer.parseInt(pm.getParamMap().get(param).trim());
			}
		}
		return cardInstance;
	}

	// Retrieve Card Number
	public int retrieveCardNumber(ParamManager pm) {
		int cardNumber = -1;

		for (String param : pm.getParamMap().keySet()) {
			if ((param.trim().equalsIgnoreCase("CARD_NUMBER") || param.trim().equalsIgnoreCase("ROW_NUMBER")) && !pm.getParamMap().get(param).trim().contentEquals("")) {
				cardNumber = Integer.parseInt(pm.getParamMap().get(param).trim());
			}
		}
		return cardNumber;
	}

	// Retrieve the Button to Click
	public String retrieveButtonToClick(ParamManager pm) {
		String btnToClick = "";

		for (String param : pm.getParamMap().keySet()) {
			if ((param.trim().equalsIgnoreCase("BUTTON_TO_CLICK") || param.trim().equalsIgnoreCase("BUTTON TO CLICK")) && !pm.getParamMap().get(param).trim().contentEquals("")) {
				btnToClick = pm.getParamMap().get(param).trim().toUpperCase();
			}
		}
		return btnToClick;
	}

	// Retrieve the card data
	public HashMap<String, String> retrieveCardData(ParamManager pm) {
		HashMap<String, String> cardData = new LinkedHashMap<>();

		for (String param : pm.getParamMap().keySet()) {
			if (param.trim().toUpperCase().startsWith("CARDDATA_") && !pm.getParamMap().get(param).trim().contentEquals("")) {
				String fieldName = param.trim().substring(9).toUpperCase();
				cardData.put(fieldName, pm.getParamMap().get(param));
			} else if ((param.trim().toUpperCase().startsWith("ROWDATA_")) && !pm.getParamMap().get(param).trim().contentEquals("")) {
				String fieldName = param.trim().substring(8).toUpperCase();
				cardData.put(fieldName, pm.getParamMap().get(param));
			}
		}
		return cardData;
	}

	// Retrieve the card objects
	public HashMap<String, String> retrieveCardObjects(ParamManager pm) {
		HashMap<String, String> cardObjects = new LinkedHashMap<>();

		for (String param : pm.getParamMap().keySet()) {
			if (param.trim().toUpperCase().startsWith("CARDOBJECT_") && !pm.getParamMap().get(param).trim().contentEquals("")) {
				String fieldName = param.trim().substring(11).toUpperCase();
				cardObjects.put(fieldName, pm.getParamMap().get(param));
			} else if ((param.trim().toUpperCase().startsWith("ROWOBJECT_")) && !pm.getParamMap().get(param).trim().contentEquals("")) {
				String fieldName = param.trim().substring(10).toUpperCase();
				cardObjects.put(fieldName, pm.getParamMap().get(param));
			}
		}
		return cardObjects;
	}

	// Retrieve the type of the test to verify list box contents
	public String retrieveTestType(ParamManager pm) {
		String testType = "";

		for (String param : pm.getParamMap().keySet()) {
			if ((param.trim().equalsIgnoreCase("TYPEOFTEST") || param.trim().equalsIgnoreCase("TYPE_OF_TEST")) && !pm.getParamMap().get(param).trim().contentEquals("")) {
				testType = pm.getParamMap().get(param).trim();
			}
		}
		return testType;
	}

	// Retrieve the list box contents
	public String retrieveListBoxContents(ParamManager pm) {
		String listBoxContents = "";

		for (String param : pm.getParamMap().keySet()) {
			if (param.trim().equalsIgnoreCase("LB_CONTENTS") && !pm.getParamMap().get(param).trim().contentEquals("")) {
				listBoxContents = pm.getParamMap().get(param).trim();
			}
		}
		return listBoxContents;
	}

	// ************************************ Core Methods
	// *************************************************
	public WebElement findCardMatchCriteria(WebElement p_parent, String p_cardSelector, HashMap<String, String> p_cardToFind, int p_cardInstance, ObjectMap p_objectMap, int p_cardNumber) throws DDTFrameworkException {

		List<WebElement> arrCards = findAllCardsMatchCriteria(p_parent, p_cardSelector, p_cardToFind, p_cardInstance, p_objectMap, p_cardNumber);

		if (p_cardNumber < 0) {
			if (arrCards.size() > 0) {
				return arrCards.get(0);
			} else {
				return null;
			}
		} else {
			if (arrCards.size() > 0) {
				return arrCards.get(p_cardNumber - 1);
			} else {
				return null;
			}
		}

	}

	public List<WebElement> findAllCardsMatchCriteria(WebElement p_parent, String p_cardSelector, HashMap<String, String> p_cardToFind, int p_cardInstance, ObjectMap p_objectMap, int p_cardNumber) throws DDTFrameworkException {

		boolean bFoundMatchNode = false;
		int cardInstance = 0;

		List<WebElement> arrRtnCards = new ArrayList<WebElement>();
		List<WebElement> arrAllCards = getAllCards(p_parent, p_cardSelector);

		if (p_cardNumber > 0)
			return arrAllCards;

		for (WebElement eachCard : arrAllCards) {
			for (String fieldName : p_cardToFind.keySet()) {
				String expectedValue = p_cardToFind.get(fieldName);
				expectedValue = convertToUTF8(expectedValue);
				if (!expectedValue.trim().contentEquals("")) {

					if (!p_objectMap.getMap().containsKey(fieldName)) {
						m_logger.info("The field - [" + fieldName + "] doesn't have an object mapped to it!!");
					} else {
						BaseObject fieldObject = p_objectMap.getMap().get(fieldName);
						String actualValue = getFieldValueInCard(eachCard, fieldObject).trim();

						expectedValue = expectedValue.replace("[BLANK]", "");
						if (expectedValue.toUpperCase().contains("[REMOVESPACES]")) {
							expectedValue = expectedValue.replace("[REMOVESPACES]", "").replaceAll(" ", "").trim();
							actualValue = actualValue.replaceAll(" ", "").trim();
						}

						if (expectedValue.toUpperCase().contains("[PARTIAL]")) {
							expectedValue = expectedValue.replace("[PARTIAL]", "");
							if (actualValue.contains(expectedValue)) {
								bFoundMatchNode = true;
							} else {
								bFoundMatchNode = false;
								break;
							}
						} else {
							if (actualValue.equalsIgnoreCase(expectedValue)) {
								bFoundMatchNode = true;
							} else {
								bFoundMatchNode = false;
								break;
							}
						}
					}
				}
			}

			if (bFoundMatchNode) {
				if (p_cardInstance >= 0) {
					cardInstance = cardInstance + 1;
					if (p_cardInstance == cardInstance) {
						arrRtnCards.add(eachCard);
						return arrRtnCards;
					}
				} else {
					arrRtnCards.add(eachCard);
				}
			}
		}

		return arrRtnCards;
	}

	// Get all the cards with the given selection criteria
	public List<WebElement> getAllCards(WebElement p_parent, String p_cardSelector) {
		// Find the cards with the appropriate selector
		By by;
		if (p_cardSelector.toUpperCase().startsWith("CSS:")) {
			by = By.cssSelector(p_cardSelector.substring(4));
		} else if (p_cardSelector.toUpperCase().startsWith("XPATH:")) {
			by = By.xpath(p_cardSelector.substring(6));
		} else {
			by = By.xpath(p_cardSelector);
		}

		List<WebElement> arrCards = new ArrayList<WebElement>();
		for (WebElement card : p_parent.findElements(by)) {
			if (card.isDisplayed()) {
				arrCards.add(card);
			}
		}
		return arrCards;
	}

	// Get the value of a field in card
	public String getFieldValueInCard(WebElement p_card, BaseObject p_fieldObject) {
		String fieldValue = "";

		WebElement cardObject = getObjectInCard(p_card, p_fieldObject);

		if (cardObject != null) {
			fieldValue = cardObject.getText();
			if (fieldValue.contentEquals("")) {
				fieldValue = cardObject.getAttribute("textContent").trim();
			}

			if (fieldValue.equals("") && (cardObject.getTagName().equalsIgnoreCase("input") || cardObject.getTagName().equalsIgnoreCase("textarea"))) {
				if (!cardObject.getAttribute("value").equals("")) {
					fieldValue = cardObject.getAttribute("value");
				}
			}
		}
		fieldValue = fieldValue.replace("\n", " ");
		if (DDTController.getBrowserType().equals(BrowserType.Edge)) {
			fieldValue = fieldValue.replaceAll("\u00A0", " ").trim();
		}
		fieldValue = convertToUTF8(fieldValue);
		return fieldValue;
	}

	// Get the object in the card for the field
	public WebElement getObjectInCard(WebElement p_card, BaseObject p_fieldObject) {
		return getObjectInCard(p_card, p_fieldObject, 1);
	}

	// Get the object in the card for the field
	public WebElement getObjectInCard(WebElement p_card, BaseObject p_fieldObject, int p_objInstance) {
		if (!p_card.isDisplayed()) {
			return null;
		}

		// Find the object with the appropriate selector
		String nodeSelector = p_fieldObject.getSelector();
		By by;
		if (nodeSelector.toUpperCase().startsWith("CSS:")) {
			by = By.cssSelector(nodeSelector.substring(4));
		} else if (nodeSelector.toUpperCase().startsWith("XPATH:")) {
			by = By.xpath(nodeSelector.substring(6));
		} else {
			by = By.xpath(nodeSelector);
		}

		if (p_card.findElements(by).size() >= p_objInstance) {
			return p_card.findElements(by).get(p_objInstance - 1);
		} else {
			return null;
		}
	}
}

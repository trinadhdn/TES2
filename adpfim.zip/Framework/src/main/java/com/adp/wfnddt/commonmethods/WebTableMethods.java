package com.adp.wfnddt.commonmethods;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.adp.wfnddt.core.DDTLoggerManager;
import com.adp.wfnddt.objectmanager.WebTable;
import com.adp.wfnddt.parammanager.ParamManager;
import com.adp.wfnddt.core.DDTController;

public class WebTableMethods {
	protected static WebDriver m_webDriver = DDTController.getWebDriver();
	protected static WebDriverWait m_webDriverWait = DDTController.getWebDriverWait();
	
	Logger m_Logger = DDTLoggerManager.getLogger(WebTable.class);

	public int getRowCount(WebElement p_webTable) {
		return p_webTable.findElements(By.xpath(".//tbody/tr")).size();
	}
	public int getColumnCount(WebElement p_webTable) {
		return p_webTable.findElements(By.xpath(".//thead/tr/td")).size();
	}
	public String[] getColumnNames(WebElement p_webTable) {
		int colCount = this.getColumnCount(p_webTable);
		String[] ColNames = new String[colCount];
		for (int i=1; i<=colCount; i++)
		{
			ColNames[i-1] = p_webTable.findElement(By.xpath(".//thead/tr[2]/th[" + i + "]/div/span")).getText();
		}
		return ColNames;
	}
	public int getColumnIndex(WebElement p_webTable, String p_ColName) {
		int colCount = this.getColumnCount(p_webTable);
		String[] ColNames = this.getColumnNames(p_webTable);
		int colIndex = 0;
		for (int j=1; j<=colCount; j++)
		{
			if (p_ColName.toUpperCase().compareTo(ColNames[j-1].toUpperCase()) == 0 )
			{
				colIndex = j;
				break;
			}
		}
		return colIndex;
	}
	public String getCellData(WebElement p_webTable, int p_Row, int p_Col) {
		return p_webTable.findElement(By.xpath(".//tbody/tr[" + p_Row + "]/td[" + p_Col + "]")).getText();
	}
	public WebElement getLinkInCell(WebElement p_webTable, int p_Row, int p_Col) {
		return p_webTable.findElement(By.xpath(".//tbody/tr[" + p_Row + "]/td[" + p_Col + "]/a"));
	}
	public WebElement getActionLinkInCell(WebElement p_webTable, int p_Row, int p_Col) {
		return p_webTable.findElement(By.xpath(".//tbody/tr[" + p_Row + "]/td[" + p_Col + "]/span/div/span"));
	}
	public WebElement getTableCell(WebElement p_webTable, int p_Row, int p_Col) {
		return p_webTable.findElement(By.xpath(".//tbody/tr[" + p_Row + "]/td[" + p_Col + "]"));
	}
	public WebElement getChildItem(WebElement p_webTable, int p_Row, int p_Col, String p_attributeType, String p_attributeValue) {
		if (p_attributeType.equalsIgnoreCase("text")) {
			return p_webTable.findElements(By.xpath(".//tbody/tr[" + p_Row + "]/td[" + p_Col + "]//*[contains(" + p_attributeType + "(),'" + p_attributeValue +"')]")).get(0);
		} else if (p_attributeType.equalsIgnoreCase("tag")) {
			return p_webTable.findElements(By.xpath(".//tbody/tr[" + p_Row + "]/td[" + p_Col + "]//" + p_attributeValue)).get(0);
		} else if (p_attributeType.equalsIgnoreCase("xpath")) {
			return p_webTable.findElements(By.xpath(".//tbody/tr[" + p_Row + "]/td[" + p_Col + "]//" + p_attributeValue )).get(0);
		} else {
			return p_webTable.findElements(By.xpath(".//tbody/tr[" + p_Row + "]/td[" + p_Col + "]//*[contains(@" + p_attributeType + ",'" + p_attributeValue +"')]")).get(0);
		}
	}
	public int getChildItemCount(WebElement p_webTable, int p_Row, int p_Col, String p_attributeType, String p_attributeValue) {
		if (p_attributeType.equalsIgnoreCase("text")) {
			return p_webTable.findElements(By.xpath(".//tbody/tr[" + p_Row + "]/td[" + p_Col + "]//*[contains(" + p_attributeType + "(),'" + p_attributeValue +"')]")).size();
		} else if (p_attributeType.equalsIgnoreCase("tag")) {
			return p_webTable.findElements(By.xpath(".//tbody/tr[" + p_Row + "]/td[" + p_Col + "]//" + p_attributeValue)).size();
		} else if (p_attributeType.equalsIgnoreCase("xpath")) {
			return p_webTable.findElements(By.xpath(".//tbody/tr[" + p_Row + "]/td[" + p_Col + "]//" + p_attributeValue )).size();
		} else {
			return p_webTable.findElements(By.xpath(".//tbody/tr[" + p_Row + "]/td[" + p_Col + "]//*[contains(@" + p_attributeType + ",'" + p_attributeValue +"')]")).size();
		}		
	}

	public String[] findRowInTable(WebElement p_webTable, int p_rowCount, int p_colCount, String[] p_colNames, String[] p_SearchColumnNames, ParamManager p_pm) 
	{
		int instanceIn=0;
		boolean searchInstanceMatch = false;
		int rowFound=0;
		String[] returnValues = {"A","B","C"}; 
		
		for (int row=1; row<=p_rowCount; row++)
		{
			String expectedValue;
			String actualValue;
			boolean rowcompare = false;
			m_Logger.debug("row : " + row);
			for (int col=1; col<=p_colCount; col++)
			{
				boolean colFound = false;
				int searchIteration = 0;
				for (int i=1; i<=p_SearchColumnNames.length; i++)
				{
					if ( p_colNames[col-1].equalsIgnoreCase(p_SearchColumnNames[i-1]))
					{
						m_Logger.debug("Column : " + p_colNames[col-1]);
						if (p_pm.getParamMap().containsKey("RowToFind_" + p_SearchColumnNames[i-1]))
						{
							colFound = true;
						}
						searchIteration = i;
						break;
					}
				}
				if ( colFound==true )
				{
					expectedValue = p_pm.Parameter("RowToFind_" + p_SearchColumnNames[searchIteration-1]).trim();
					m_Logger.debug("expected: " + expectedValue);
					// if value is not passed by user, skip the comparison for column.
					if (! expectedValue.isEmpty())
					{
						actualValue = this.getCellData(p_webTable, row, col).trim();
						m_Logger.debug("actual : " + actualValue);
						
						if (expectedValue.equalsIgnoreCase("[BLANK]")) {
							expectedValue = "";
						}
						m_Logger.debug("expected: " + expectedValue);
						if ( actualValue.equals(expectedValue))
						{
							rowcompare = true;
							m_Logger.debug("rowcompare is " + rowcompare);
						} else
						{
							rowcompare = false;
							m_Logger.debug("rowcompare is " + rowcompare);
							break;
						}
					}
				}
			}
	
			if (rowcompare == true)
			{
				instanceIn++;
				if (instanceIn == Integer.parseInt(p_pm.Parameter("Row_Instance")))
				{
					searchInstanceMatch = true;
					rowFound = row;
					break;
				}
			}
			
		}
		returnValues[0]= Integer.toString(rowFound);
		returnValues[1]= String.valueOf(searchInstanceMatch);
		returnValues[2]= Integer.toString(instanceIn);
		return returnValues;
	}

	
}
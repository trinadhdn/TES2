package com.adp.wfnddt.core;

import java.io.Serializable;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import org.apache.cxf.jaxrs.client.WebClient;
import org.apache.cxf.transport.http.HTTPConduit;

import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;

import org.apache.log4j.Logger;

public class OracleScriptServicesProxy {
	private static Logger m_logger = DDTLoggerManager.getLogger(OracleScriptServicesProxy.class);
	private Gson m_gson = new Gson();				
	
	public class ClientSnapshotLoadParams implements Serializable {
		/**
		 *
		 */
		private static final long serialVersionUID = 1L;
		private String environmentID = null;
		private String companyCode = null;
		private int runID = -1;
		
		public String getEnvironmentID() { return environmentID; }
		public void setEnvironmentID(String p_environmentID) { environmentID = p_environmentID; return; }
		
		public String getCompanyCode() { return companyCode; }
		public void setCompanyCode(String p_companyCode) { companyCode = p_companyCode; return; }
		
		public int getRunID() { return runID; }
		public void setRunID(int p_runID) { runID = p_runID; return; }		
	}
	
	public class ClientSnapshotLoadResponse implements Serializable {

		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		private String status;
		private String VPDKey;
				
		public String getStatus() { return status; }
		public void setStatus(String p_status) { status = p_status; return; }
		
		public String getVPDKey() { return VPDKey; }
		public void setVPDKey(String p_VPDKey) { VPDKey = p_VPDKey; return; }
	}
	
	public enum E_Mode {Normal, Talent, EZLM};
	public class UserMappingBySSNParams implements Serializable {
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		private String environmentID = null;
		private String chrSecUserID; // Used to get VPD key.
		private String SSN;
		private E_Mode mode;
		
		public String getEnvironmentID() { return environmentID; }
		public void setEnvironmentID(String p_environmentID) { environmentID = p_environmentID; return; }
		
		public String getChrSecUserID() { return chrSecUserID; }
		public void setChrSecUserID(String p_chrSecUserID) { chrSecUserID = p_chrSecUserID; return; }
		
		public String getSSN() { return SSN; }
		public void setSSN(String p_SSN) { SSN = p_SSN; return; }
		
		public E_Mode getMode() { return mode; }
		public void setMode(E_Mode p_mode) { mode = p_mode; return; }
	}
	
	public class UserMappingByAssocIDParams implements Serializable {

		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		private String environmentID = null;
		private String chrSecUserID; // Used to get VPD key.
		private String associateID;
		
		public String getEnvironmentID() { return environmentID; }
		public void setEnvironmentID(String p_environmentID) { environmentID = p_environmentID; return; }
		
		public String getChrSecUserID() { return chrSecUserID; }
		public void setChrSecUserID(String p_chrSecUserID) { chrSecUserID = p_chrSecUserID; return; }
		
		public String getAssociateID() { return associateID; }
		public void setAssociateID(String p_associateID) { associateID = p_associateID; return; }
	}
	
	public ClientSnapshotLoadResponse loadClientSnapshot(ClientSnapshotLoadParams p_clientSSLoadParms) throws DDTFrameworkException {
		String jsonData = m_gson.toJson(p_clientSSLoadParms);
		String response = callWindowsOracleScriptService("loadClientSnapshot", jsonData, 3600L);
		ClientSnapshotLoadResponse clsResp;
		
		if(response.equals("FAILED")) {
			clsResp = new ClientSnapshotLoadResponse();
			clsResp.status = "FAILED";
		} else {
			try {
				clsResp = m_gson.fromJson(response, ClientSnapshotLoadResponse.class);
			} catch(JsonSyntaxException jsEx) {
				throw new DDTFrameworkException(OracleScriptServicesProxy.class, "Failed to parse ClientSnapshotLoad response: ", jsEx);
			}
		}
		
		return clsResp;
	}
	
	public String userMappingBySSN(UserMappingBySSNParams p_userMapBySSNParms) throws DDTFrameworkException {
		String jsonData = m_gson.toJson(p_userMapBySSNParms);
		String response = callWindowsOracleScriptService("userMappingBySSN", jsonData, 300L);
		response = response.replaceAll("^\"|\"$", "");
		return response;
	}
	
	public String userMappingByAssociateID(UserMappingByAssocIDParams p_userMapByAssocIDParms) throws DDTFrameworkException {
		String jsonData = m_gson.toJson(p_userMapByAssocIDParms);
		String response = callWindowsOracleScriptService("userMappingByAssociateID", jsonData, 300L);
		response = response.replaceAll("^\"|\"$", "");
		return response;
	}
	
	public String runScript(String p_scriptCmd) throws DDTFrameworkException {
		String jsonData = m_gson.toJson(p_scriptCmd);
		String response = callWindowsOracleScriptService("runScript", jsonData, 1800L);
		response = response.replaceAll("^\"|\"$", "");
		return response;
	}

	private String callWindowsOracleScriptService(String p_serviceName, String p_JsonData, long p_lTimeoutSecs) throws DDTFrameworkException {
		String retValue = "FAILED";
		WebClient webClient = null;
		Response clientPostResponse = null;
		
		/*
		 * http://cdlautowfnag0n/WFNAutoOracleScriptServices/OracleScriptService.svc
		 */
		
		try {
			StringBuilder sbURL = new StringBuilder("http://");
			sbURL.append(DDTController.getOracleScriptServiceHost());
			sbURL.append("/OracleScriptService.svc");
			webClient = WebClient.create(sbURL.toString());
			webClient.path(p_serviceName);
			HTTPConduit conduit = WebClient.getConfig(webClient).getHttpConduit();
			m_logger.debug(String.format("Connect Timeout=%1$d, ReceiveTimeout=%2$d", conduit.getClient().getConnectionTimeout(), conduit.getClient().getReceiveTimeout()));
			conduit.getClient().setReceiveTimeout(1000L * p_lTimeoutSecs);
			
			// Do OPTIONS (pre-flight check)
			m_logger.debug("callWindowsOracleScriptService-do pre-flight check;");
			Response clientOptsResponse = webClient
				.acceptEncoding("gzip", "deflate", "sdch")
				.acceptLanguage("en-US", "en;q=0.8")
				.header("Access-Control-Request-Headers", "accept", "content-type")
				.header("Access-Control-Request-Method", "POST")
				.accept(MediaType.MEDIA_TYPE_WILDCARD)
				.options();
			
			// If pre-flight check is OK then do POST (REST service call)
			if(clientOptsResponse.getStatus() == 200) {
				m_logger.debug("callWindowsOracleScriptService-do post");
				clientPostResponse = webClient
						.acceptLanguage("en-US, en;q=0.8")
						.acceptEncoding("gzip, deflate, sdch")
						.type(MediaType.APPLICATION_JSON_TYPE)
						.accept(MediaType.APPLICATION_JSON_TYPE)
						.post(p_JsonData, Response.class);
				
				if(clientPostResponse.getStatus() == 200) {
					m_logger.debug("callWindowsOracleScriptService-got good post response");
					if(clientPostResponse.hasEntity()) {
						retValue = clientPostResponse.readEntity(String.class);
					}
				} else {
					throw new DDTFrameworkException(OracleScriptServicesProxy.class,
									String.format("REST service POST call failed: %1$d - %2$s",
													clientPostResponse.getStatus(),
													clientPostResponse.getStatusInfo().getReasonPhrase()));
				}
			} else {
				throw new DDTFrameworkException(OracleScriptServicesProxy.class,
						String.format("REST service pre-flight check failed: %1$d - %2$s",
								clientOptsResponse.getStatus(),
								clientOptsResponse.getStatusInfo().getReasonPhrase()));				
			}
		} catch (DDTFrameworkException dfeEx) {
			throw dfeEx;
		} catch (Exception ex) {
			throw new DDTFrameworkException(OracleScriptServicesProxy.class, "An unexpected error ocurred while invoking REST service.", ex);
		} finally {
			if (webClient != null) {
				webClient.close();
			}		
		}
			
		return retValue;
	}	
}

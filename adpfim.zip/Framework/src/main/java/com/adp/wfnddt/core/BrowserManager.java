/**
 * 
 */
package com.adp.wfnddt.core;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.MalformedURLException;
import java.net.Proxy;
import java.net.URL;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSession;
import javax.ws.rs.core.MultivaluedHashMap;

import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.Platform;
import org.openqa.selenium.UnexpectedAlertBehaviour;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.openqa.selenium.logging.LogType;
import org.openqa.selenium.logging.LoggingPreferences;
import org.openqa.selenium.remote.BrowserType;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.CommandInfo;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.HttpCommandExecutor;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.http.HttpClient;
import org.openqa.selenium.remote.http.HttpClient.Factory;
import org.openqa.selenium.remote.internal.OkHttpClient;
import org.openqa.selenium.safari.SafariOptions;

import com.adp.wfnddt.core.DDTController.E_OSs;
import com.adp.wfnddt.webapi.rest.TestRestAPI;

import net.lightbody.bmp.BrowserMobProxy;
import net.lightbody.bmp.BrowserMobProxyServer;
import net.lightbody.bmp.client.ClientUtil;
import net.lightbody.bmp.proxy.CaptureType;
import net.lightbody.bmp.proxy.auth.AuthType;
import okhttp3.Authenticator;
import okhttp3.Credentials;
import okhttp3.OkHttpClient.Builder;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.Route;

/**
 * @author autoxpert
 *
 */
public class BrowserManager {
	private static Logger m_logger = DDTLoggerManager.getLogger(BrowserManager.class);
	private static final String[] m_ie32Drivers = { "/SeleniumDrivers/IEDriverServer.exe", "<Not Supported>", "<Not Supported>" };
	private static final String[] m_ie64Drivers = { "/SeleniumDrivers/IEDriverServer-x64.exe", "<Not Supported>", "<Not Supported>" };
	private static final String[] m_firefox32Drivers = { "/SeleniumDrivers/geckodriver.exe", "<Not Supported>", "<Not Supported>" };
	private static final String[] m_firefox64Drivers = { "<Not Supported>", DDTController.getUserHome() + "/SeleniumDrivers/geckodriver", DDTController.getUserHome() + "/SeleniumDrivers/geckodriver" };
	private static final String[] m_chrome32Drivers = { "/SeleniumDrivers/chromedriver.exe", "<Not Supported>", "<Not Supported>" };
	private static final String[] m_chrome64Drivers = { "<Not Supported>", DDTController.getUserHome() + "/SeleniumDrivers/chromedriver", DDTController.getUserHome() + "/SeleniumDrivers/chromedriver" };
	private static final String[] m_edgeDrivers = { "/SeleniumDrivers/MicrosoftWebDriver.exe", "<Not Supported>", "<Not Supported>" };
	private static String m_SelGridURL = DDTController.getSeleniumGridURL().trim();

	// Proxy host/port and authentication
	// private static final String proxy_host = "11.164.4.22";
	private static final String proxy_host = "11.164.4.21";
	private static final int proxy_port = 8080;
	private static final String proxy_user = "autoxpert";
	private static final String proxy_password = "adpadp";
	
	// Experitest Demo Cloud
	private static boolean isExperitest = DDTController.isExperitest();
	private static boolean isPerfecto = DDTController.isPerfecto();
	private static String Experitest_AccessKey = "eyJ4cC51Ijo2LCJ4cC5wIjoyLCJ4cC5tIjoiTVRVME56Y3dOekl4TlRnek53IiwiYWxnIjoiSFMyNTYifQ.eyJleHAiOjE4NjMwNjcyMTYsImlzcyI6ImNvbS5leHBlcml0ZXN0In0.TwAwE9IPg-PXy0fxyxGOzlpNuCN2JG3TYHWc5Cqks08";
	private static String Perfecto_SecurityToken = "eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICJQWURISDhDekZwQ2REWmVJWmlLeHVSMmQ4WGIzOXJQcC1ibzhSVVctSXVNIn0.eyJqdGkiOiJkNzZmZjUxNi1jODhhLTQ2YzctODAwMS0wM2EyYTIwNmU4ODMiLCJleHAiOjAsIm5iZiI6MCwiaWF0IjoxNTY5ODMxNDk4LCJpc3MiOiJodHRwczovL2F1dGgucGVyZmVjdG9tb2JpbGUuY29tL2F1dGgvcmVhbG1zL2FkcC1wZXJmZWN0b21vYmlsZS1jb20iLCJhdWQiOiJvZmZsaW5lLXRva2VuLWdlbmVyYXRvciIsInN1YiI6IjhiMGY3NDA1LWE1NGUtNGZmMy1hNGY3LTYyYjExNWU3YzljNiIsInR5cCI6Ik9mZmxpbmUiLCJhenAiOiJvZmZsaW5lLXRva2VuLWdlbmVyYXRvciIsIm5vbmNlIjoiZmFlZWNjNTYtMjc5MC00ZmU1LThiN2QtYjcxODBmNmFkN2M5IiwiYXV0aF90aW1lIjowLCJzZXNzaW9uX3N0YXRlIjoiOGM5ODQ5OGEtNTcxOC00NmQzLWJkN2ItOGViODMyNGJmYzA0IiwicmVhbG1fYWNjZXNzIjp7InJvbGVzIjpbIm9mZmxpbmVfYWNjZXNzIiwidW1hX2F1dGhvcml6YXRpb24iXX0sInJlc291cmNlX2FjY2VzcyI6eyJhY2NvdW50Ijp7InJvbGVzIjpbIm1hbmFnZS1hY2NvdW50IiwibWFuYWdlLWFjY291bnQtbGlua3MiLCJ2aWV3LXByb2ZpbGUiXX19fQ.H0tMocSZgfvMB7mEi8P_OxD4LrnQ46ZLsri8UcWMSbdEJOdGSDW7PzHJqAD2py_9Zx9sU1fRpn1hO12avk9HMzcmEiwc1koPg7HTPkeS-VMjr0bUF4wVWaxX9SM2LKHwqmheNZ4gHFLTN1MVBteOmOTvNPGYhGvW91i6rbix8rbAdtdHjrOcvOuoIQ_16j-ewkmFq82ZU15HhOKU8IvFzuFXIZ1roGAfKSIqugO84rgY1UqF_FhTiahIpIurZ627Z5kMFEewHdDREhT80dbAL5bXnMFS1od1Zr-8GXI4SZxs6wuolXnaw1Ge-dpGqFjSuoBky8mcMl2n_fa_nfEWig";

	public static WebDriver setupWebDriver() throws DDTFrameworkException, MalformedURLException {
		m_logger.debug("Enter setupWebDriver() for browser: " + DDTController.getBrowserType().name());
		WebDriver webDriver = null;
		long lMaxWait = DDTController.getMaxWaitTime();

		// Configure WebDriver for selected browser.
		switch (DDTController.getBrowserType()) {
		case InternetExplorer32: {
			// The IE driver Java implementation with this class has not been
			// released yet.
			InternetExplorerOptions options = new InternetExplorerOptions();
			options.introduceFlakinessByIgnoringSecurityDomains();
			options.setUnhandledPromptBehaviour(UnexpectedAlertBehaviour.IGNORE);
			// options.enableNativeEvents(); -- why deprecated?
			options.setCapability(InternetExplorerDriver.NATIVE_EVENTS, true);
			options.ignoreZoomSettings();
			options.enablePersistentHovering();
			options.requireWindowFocus();
			options.usePerProcessProxy();

			if (isExperitest) {
				switch (DDTController.getRemoteBrowserConfig()) {
				case "Experitest-IE_Win10":
					options.setCapability(CapabilityType.PLATFORM_NAME, Platform.WIN10);
					break;
				default:
					options.setCapability(CapabilityType.PLATFORM_NAME, Platform.WIN10);
					break;
				}

				options.setCapability(CapabilityType.BROWSER_NAME, BrowserType.FIREFOX);
				options.setCapability("accessKey", Experitest_AccessKey);
				options.setCapability("testName", "ADP WFN Test");

				webDriver = new RemoteWebDriver(getProxyHTTPExecutor(new URL(DDTController.getSeleniumRemoteURL()), false), options);

			} else {
				// Performance
				if (DDTController.isCapturePerfMetrics()) {
					BrowserMobProxy bmpServer = new BrowserMobProxyServer();
					bmpServer.setTrustAllServers(true);
					bmpServer.setChainedProxy(new InetSocketAddress(proxy_host, proxy_port));
					bmpServer.chainedProxyAuthorization(proxy_user, proxy_password, AuthType.BASIC);

					bmpServer.start();
					bmpServer.enableHarCaptureTypes(CaptureType.REQUEST_CONTENT, CaptureType.RESPONSE_CONTENT,CaptureType.RESPONSE_HEADERS);

					org.openqa.selenium.Proxy proxy = ClientUtil.createSeleniumProxy(bmpServer);
					options.setCapability(CapabilityType.PROXY, proxy);

					DDTController.setBMPServer(bmpServer);
					DDTController.getBMPServer().newHar(GlobalVariables.getVariable("FEATURE FILE"));
					DDTController.getBMPServer().newPage(GlobalVariables.getVariable("HAR PAGE"));
				}

				setPlatformWebDriver("webdriver.ie.driver", m_ie32Drivers);
				if (m_SelGridURL.contentEquals("")) {
					webDriver = new InternetExplorerDriver(options);
				} else {
					webDriver = new RemoteWebDriver(new URL(m_SelGridURL), options);
				}
			}
		}
			break;

		case InternetExplorer64: // SendKeys very slow and admin login click not
									// working.
		{
			InternetExplorerOptions options = new InternetExplorerOptions();
			options.introduceFlakinessByIgnoringSecurityDomains();
			options.setUnhandledPromptBehaviour(UnexpectedAlertBehaviour.IGNORE);
			// options.enableNativeEvents(); -- why deprecated?
			options.setCapability(InternetExplorerDriver.NATIVE_EVENTS, true);
			options.ignoreZoomSettings();
			options.enablePersistentHovering();
			options.requireWindowFocus();
			options.usePerProcessProxy();

			setPlatformWebDriver("webdriver.ie.driver", m_ie64Drivers);
			if (m_SelGridURL.contentEquals("")) {
				webDriver = new InternetExplorerDriver(options);
			} else {
				webDriver = new RemoteWebDriver(new URL(m_SelGridURL), options);
			}
		}
			break;

		case Firefox32: {
			FirefoxProfile firefoxProfile = new FirefoxProfile();
			firefoxProfile.setAcceptUntrustedCertificates(true);
			firefoxProfile.setAssumeUntrustedCertificateIssuer(false);
			firefoxProfile.setPreference("plugin.state.flash", 0);
			firefoxProfile.setPreference("dom.ipc.plugins.enabled.libflashplayer.so", "false");
			firefoxProfile.setPreference("network.proxy.type", 4);
		
			if (isExperitest) {
				DesiredCapabilities caps = new DesiredCapabilities();

				switch (DDTController.getRemoteBrowserConfig()) {
				case "Experitest-Firefox_Win10":
					caps.setCapability(CapabilityType.PLATFORM_NAME, Platform.WIN10);
					break;
				case "Experitest-Firefox_MacHS":
					caps.setCapability(CapabilityType.PLATFORM_NAME, Platform.MAC);
					break;
				default:
					caps.setCapability(CapabilityType.PLATFORM_NAME, Platform.WIN10);
					break;
				}

				caps.setAcceptInsecureCerts(true);
				caps.setCapability(CapabilityType.BROWSER_NAME, BrowserType.FIREFOX);
				caps.setCapability("accessKey", Experitest_AccessKey);
				caps.setCapability("testName", "ADP WFN Test");
				caps.setCapability(FirefoxDriver.PROFILE, firefoxProfile);

				webDriver = new RemoteWebDriver(getProxyHTTPExecutor(new URL(DDTController.getSeleniumRemoteURL()), false), caps);

			} else if (isPerfecto) {
				DesiredCapabilities caps = new DesiredCapabilities();
				
				switch(DDTController.getRemoteBrowserConfig()){
				case "Perfecto-Firefox_Win10":
					caps.setCapability("platformName", "Windows");
					caps.setCapability("platformVersion", "10");
					caps.setCapability("browserName", "Firefox");
					caps.setCapability("browserVersion", "68");
					caps.setCapability("location", "US East");
					caps.setCapability("resolution", "1024x768");

					break;
				case "Perfecto-Firefox_MacMojave":
					caps.setCapability("platformName", "Mac");
					caps.setCapability("platformVersion", "macOS Mojave");
					caps.setCapability("browserName", "Firefox");
					caps.setCapability("browserVersion", "69");
					caps.setCapability("location", "NA-US-BOS");
					caps.setCapability("resolution", "1280x720");
					
					break;
				default:
					caps.setCapability(CapabilityType.PLATFORM_NAME, Platform.WIN10);
					break;
				}	
				
				caps.setAcceptInsecureCerts(true);
				caps.setCapability(FirefoxDriver.PROFILE, firefoxProfile);
				caps.setCapability("securityToken", Perfecto_SecurityToken);
				
				webDriver = new RemoteWebDriver(getProxyHTTPExecutor(new URL(DDTController.getSeleniumRemoteURL()), true),caps);
			
			} else {
				FirefoxOptions firefoxOptions = new FirefoxOptions();
				firefoxOptions.setProfile(firefoxProfile);
				firefoxOptions.setAcceptInsecureCerts(true);
				
				setPlatformWebDriver("webdriver.gecko.driver", m_firefox32Drivers);

				// Performance
				if (DDTController.isCapturePerfMetrics()) {
					BrowserMobProxy bmpServer = new BrowserMobProxyServer();
					bmpServer.setTrustAllServers(true);
					bmpServer.setChainedProxy(new InetSocketAddress(proxy_host, proxy_port));
					bmpServer.chainedProxyAuthorization(proxy_user, proxy_password, AuthType.BASIC);

					bmpServer.start();
					bmpServer.enableHarCaptureTypes(CaptureType.REQUEST_CONTENT, CaptureType.RESPONSE_CONTENT,
							CaptureType.RESPONSE_HEADERS);

					org.openqa.selenium.Proxy proxy = ClientUtil.createSeleniumProxy(bmpServer);
					firefoxOptions.setCapability(CapabilityType.PROXY, proxy);

					DDTController.setBMPServer(bmpServer);
					DDTController.getBMPServer().newHar(GlobalVariables.getVariable("FEATURE FILE"));
					DDTController.getBMPServer().newPage(GlobalVariables.getVariable("HAR PAGE"));
				}

				if (m_SelGridURL.contentEquals("")) {
					webDriver = new FirefoxDriver(firefoxOptions);
				} else {
					webDriver = new RemoteWebDriver(new URL(m_SelGridURL), firefoxOptions);
				}
			}
		}
			break;

		case Firefox64: {
			FirefoxProfile firefoxProfile = new FirefoxProfile();
			firefoxProfile.setAcceptUntrustedCertificates(true);
			firefoxProfile.setAssumeUntrustedCertificateIssuer(false);
			firefoxProfile.setPreference("plugin.state.flash", 0);
			firefoxProfile.setPreference("dom.ipc.plugins.enabled.libflashplayer.so", "false");

			FirefoxOptions firefoxOptions = new FirefoxOptions();
			firefoxOptions.setProfile(firefoxProfile);

			if (DDTController.getOS() == E_OSs.Linux) {
				firefoxOptions.addPreference("network.proxy.type", 0);
			}

			setPlatformWebDriver("webdriver.gecko.driver", m_firefox64Drivers);
			if (m_SelGridURL.contentEquals("")) {
				webDriver = new FirefoxDriver(firefoxOptions);
			} else {
				webDriver = new RemoteWebDriver(new URL(m_SelGridURL), firefoxOptions);
			}
		}
			break;

		case Chrome32: {
			ChromeOptions chromeOptions = new ChromeOptions();
			chromeOptions.addArguments("--disable-popup-blocking", "--disable-translate", "--disable-gpu", "--ignore-certificate-errors");
			chromeOptions.addArguments("start-maximized");
			chromeOptions.addArguments("disable-infobars");

			// Always prompt for download dialog
			HashMap<String, Object> prefs = new HashMap<String, Object>();
			prefs.put("download.prompt_for_download", true);
			chromeOptions.setExperimentalOption("prefs", prefs);
			
			if (isExperitest) {
				DesiredCapabilities caps = new DesiredCapabilities();
				
				switch(DDTController.getRemoteBrowserConfig()){
				case "Experitest-Chrome_Win10":
					caps.setCapability(CapabilityType.PLATFORM_NAME, Platform.WIN10);
					break;
				case "Experitest-Chrome_MacHS":
					caps.setCapability(CapabilityType.PLATFORM_NAME, Platform.MAC);
					break;
				default:
					caps.setCapability(CapabilityType.PLATFORM_NAME, Platform.WIN10);
					break;
				}	
				
				caps.setCapability(CapabilityType.BROWSER_NAME, BrowserType.CHROME);
				caps.setCapability("accessKey", Experitest_AccessKey);
				caps.setCapability("testName", "ADP WFN Test");
				caps.setCapability(ChromeOptions.CAPABILITY, chromeOptions);
				if (DDTController.getConsoleLogs()) {
					 LoggingPreferences logPrefs = new LoggingPreferences();
				     logPrefs.enable(LogType.BROWSER, Level.ALL);
				     caps.setCapability(CapabilityType.LOGGING_PREFS, logPrefs);
				}
				
				webDriver = new RemoteWebDriver(getProxyHTTPExecutor(new URL(DDTController.getSeleniumRemoteURL()), false),caps);

			} else if (isPerfecto) {
				DesiredCapabilities caps = new DesiredCapabilities();
				
				switch(DDTController.getRemoteBrowserConfig()){
				case "Perfecto-Chrome_Win10":
					caps.setCapability("platformName", "Windows");
					caps.setCapability("platformVersion", "10");
					caps.setCapability("browserName", "Chrome");
					caps.setCapability("browserVersion", "75");
					caps.setCapability("location", "AP Sydney");
					caps.setCapability("resolution", "1024x768");

					break;
				case "Perfecto-Chrome_MacMojave":
					caps.setCapability("platformName", "Mac");
					caps.setCapability("platformVersion", "macOS Mojave");
					caps.setCapability("browserName", "Chrome");
					caps.setCapability("browserVersion", "76");
					caps.setCapability("location", "NA-US-BOS");
					caps.setCapability("resolution", "1280x720");
					
					break;
				default:
					caps.setCapability(CapabilityType.PLATFORM_NAME, Platform.WIN10);
					break;
				}	
				
				caps.setCapability("securityToken", Perfecto_SecurityToken);
				caps.setCapability(ChromeOptions.CAPABILITY, chromeOptions);
				
				webDriver = new RemoteWebDriver(getProxyHTTPExecutor(new URL(DDTController.getSeleniumRemoteURL()), true),caps);

			}  
			else {
				setPlatformWebDriver("webdriver.chrome.driver", m_chrome32Drivers);
				if (DDTController.isCapturePerfMetrics()) {
					BrowserMobProxy bmpServer = new BrowserMobProxyServer();
					bmpServer.setTrustAllServers(true);
					bmpServer.setChainedProxy(new InetSocketAddress(proxy_host, proxy_port));
					bmpServer.chainedProxyAuthorization(proxy_user, proxy_password, AuthType.BASIC);

					bmpServer.start();
					bmpServer.enableHarCaptureTypes(CaptureType.REQUEST_CONTENT, CaptureType.RESPONSE_CONTENT,
							CaptureType.RESPONSE_HEADERS);

					org.openqa.selenium.Proxy proxy = ClientUtil.createSeleniumProxy(bmpServer);
					chromeOptions.setCapability(CapabilityType.PROXY, proxy);
					chromeOptions.setAcceptInsecureCerts(true);

					DDTController.setBMPServer(bmpServer);
					DDTController.getBMPServer().newHar(GlobalVariables.getVariable("FEATURE FILE"));
					DDTController.getBMPServer().newPage(GlobalVariables.getVariable("HAR PAGE"));

				}
				if (m_SelGridURL.contentEquals("")) {
					webDriver = new ChromeDriver(chromeOptions);
				} else {
					webDriver = new RemoteWebDriver(new URL(m_SelGridURL), chromeOptions);
				}
			}
			
		}
			break;

		case Chrome64: {
			ChromeOptions chromeOptions = new ChromeOptions();

			if (DDTController.getOS() == E_OSs.Linux) {
				chromeOptions.addArguments("--disable-popup-blocking", "--disable-translate", "--disable-gpu", "--ignore-certificate-errors", "--no-proxy-server"); // Workaround
				chromeOptions.addArguments("start-maximized");
				chromeOptions.addArguments("disable-infobars");
			} else {
				chromeOptions.addArguments("--disable-popup-blocking", "--disable-translate", "--disable-gpu", "--ignore-certificate-errors");
				chromeOptions.addArguments("start-maximized");
				chromeOptions.addArguments("disable-infobars");
			}

			setPlatformWebDriver("webdriver.chrome.driver", m_chrome64Drivers);

			if (m_SelGridURL.contentEquals("")) {
				webDriver = new ChromeDriver(chromeOptions);
			} else {
				webDriver = new RemoteWebDriver(new URL(m_SelGridURL), chromeOptions);
			}
		}
			break;

		case Edge: {
			EdgeOptions edgeOptions = new EdgeOptions();
			if (isExperitest) {
				switch (DDTController.getRemoteBrowserConfig()) {
				case "Experitest-Edge_Win10":
					edgeOptions.setCapability(CapabilityType.PLATFORM_NAME, Platform.WIN10);
					break;
				default:
					edgeOptions.setCapability(CapabilityType.PLATFORM_NAME, Platform.WIN10);
					break;
				}

				edgeOptions.setCapability(CapabilityType.BROWSER_NAME, BrowserType.EDGE);
				edgeOptions.setCapability("accessKey", Experitest_AccessKey);
				edgeOptions.setCapability("testName", "ADP WFN Test");

				webDriver = new RemoteWebDriver(getProxyHTTPExecutor(new URL(DDTController.getSeleniumRemoteURL()), false), edgeOptions);

			} else {
				setPlatformWebDriver("webdriver.edge.driver", m_edgeDrivers);

				if (m_SelGridURL.contentEquals("")) {
					webDriver = new EdgeDriver(edgeOptions);
				} else {
					webDriver = new RemoteWebDriver(new URL(m_SelGridURL), edgeOptions);
				}
			}
		}
			break;
			
		case Safari: {
			SafariOptions safariOptions = new SafariOptions();
			safariOptions.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
			if (isExperitest) {
				switch (DDTController.getRemoteBrowserConfig()) {
				case "Experitest-Safari_MacHS":
					safariOptions.setCapability(CapabilityType.PLATFORM_NAME, Platform.MAC);
					break;
				default:
					safariOptions.setCapability(CapabilityType.PLATFORM_NAME, Platform.MAC);
					break;
				}

				safariOptions.setCapability(CapabilityType.BROWSER_NAME, BrowserType.SAFARI);
				safariOptions.setCapability("accessKey", Experitest_AccessKey);
				safariOptions.setCapability("testName", "ADP WFN Test");

				webDriver = new RemoteWebDriver(getProxyHTTPExecutor(new URL(DDTController.getSeleniumRemoteURL()), false), safariOptions);
			} else if (isPerfecto) {
				switch (DDTController.getRemoteBrowserConfig()) {
				case "Perfecto-Safari_MacMojave":
					safariOptions.setCapability("platformName", "Mac");
					safariOptions.setCapability("platformVersion", "macOS Mojave");
					safariOptions.setCapability("browserName", "Safari");
					safariOptions.setCapability("browserVersion", "12");
					safariOptions.setCapability("location", "NA-US-BOS");
					safariOptions.setCapability("resolution", "1024x768");
					break;
				default:
					safariOptions.setCapability(CapabilityType.PLATFORM_NAME, Platform.MAC);
					break;
				}

				safariOptions.setCapability("securityToken", Perfecto_SecurityToken);

				webDriver = new RemoteWebDriver(getProxyHTTPExecutor(new URL(DDTController.getSeleniumRemoteURL()), true), safariOptions);
			} 

		}
		break;
		
		default:
			throw new DDTFrameworkException(BrowserManager.class, "Invalid browser type specified.");
		}

		DDTController.setWebDriver(webDriver, lMaxWait);
		handBrowserInfoToReporter(webDriver);
		// JE - added to get SGrid Machine running on then post to Logger
		if (!m_SelGridURL.contentEquals("") && !isExperitest && !isPerfecto) {
			try {
				String sessionID = ((RemoteWebDriver) webDriver).getSessionId().toString();
				MultivaluedHashMap<String, String> headers = new MultivaluedHashMap<String, String>();
				headers.clear();
				headers.add("Content-Type", "application/json");
				TestRestAPI postCompAPI = new TestRestAPI("http://cdlautowfnag01:4444/grid/api/testsession?session=" + sessionID, headers, "", "");
				javax.ws.rs.core.Response response = postCompAPI.getRestAPIResponse();
				String results = response.readEntity(String.class);
				JSONObject jsonMIP = new JSONObject(results);
				m_logger.info("Selenium Grid Machine: " + jsonMIP.getString("proxyId"));
			} catch (Exception e) {
				m_logger.warn("BrowserManager: Could not get json response for SGrid");
			}
		}
		return webDriver;
	}

	private static void setPlatformWebDriver(String p_driverVarName, String[] pDriverList) throws DDTFrameworkException {
		if (DDTController.getOS() == E_OSs.Unknown_OS) {
			throw new DDTFrameworkException(BrowserManager.class, "The OS is unknown.");
		}

		String driverVarValue = pDriverList[DDTController.getOS().ordinal()];

		if (driverVarValue.equals("<Not Supported>")) {
			throw new DDTFrameworkException(BrowserManager.class, "The requested browser is not supported on this OS.");
		}

		DDTController.setSysProperty(p_driverVarName, driverVarValue);
		return;
	}

	public static void maximizeWindow() throws InterruptedException {
		DDTController.getWebDriver().manage().window().maximize();
		Thread.sleep(5000);

		return;
	}

	public static void closeBrowser() {
		m_logger.debug("Enter closeBrowser()");

		if (DDTController.getWebDriver() != null) {
			DDTController.getWebDriver().quit(); // Causes some older versions
													// of Firefox to crash
			DDTController.setWebDriver(null, 0);
		}

		if (DDTController.getMobileDriver() != null) {
			DDTController.getMobileDriver().quit();
			DDTController.setMobileDriver(null, 0);
		}

		return;
	}

	private static void handBrowserInfoToReporter(WebDriver p_webDriver) {
		if (p_webDriver != null) {
			Capabilities caps = ((RemoteWebDriver) p_webDriver).getCapabilities();
			String browserName = caps.getBrowserName();
			String browserVersion = caps.getVersion();
			m_logger.debug(browserName + " " + browserVersion);

			StringBuilder sbBrowserInfo = new StringBuilder(DDTController.getBrowserType().name());
			sbBrowserInfo.append(' ');
			sbBrowserInfo.append(browserVersion);
			DDTController.getResultsReporter().setBrowserInfo(sbBrowserInfo.toString());
		}

		return;
	}

	public static HttpCommandExecutor getProxyHTTPExecutor(URL url, boolean useProxy) {

		okhttp3.OkHttpClient.Builder builder = new Builder();
		if(useProxy){
			Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(proxy_host, proxy_port));
	
			Authenticator proxyAuthenticator = new Authenticator() {
				@Override
				public Request authenticate(Route route, Response response) throws IOException {
					String credential = Credentials.basic(proxy_user, proxy_password);
					return response.request().newBuilder().header("Proxy-Authorization", credential).build();
				}
			};
	
			builder.proxy(proxy);
			builder.proxyAuthenticator(proxyAuthenticator);
		}
		builder.connectTimeout(300, TimeUnit.SECONDS);
		builder.readTimeout(300, TimeUnit.SECONDS);
		builder.hostnameVerifier(new HostnameVerifier() {
	        @Override
	        public boolean verify(String hostname, SSLSession session) {
	            return true;
	        }
	    });

		Factory factory = new Factory() {
			@Override
			public HttpClient createClient(URL url) {
				
				return new OkHttpClient(builder.build(), url);
			}

			@Override
			public void cleanupIdleClients() {
				// TODO Auto-generated method stub
			}

			@Override
			public org.openqa.selenium.remote.http.HttpClient.Builder builder() {
				// TODO Auto-generated method stub
				return null;
			}
		};

		HttpCommandExecutor executor = new HttpCommandExecutor(new HashMap<String, CommandInfo>(), url, factory);
		return executor;
	}


}

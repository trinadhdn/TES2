package com.adp.wfnddt.pdfcomparison;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import com.adp.wfnddt.core.DDTLoggerManager;

public class ImageUtil {

	private static org.apache.log4j.Logger m_logger = DDTLoggerManager.getLogger(ImageUtil.class);

	public boolean compareAndHighlight(final BufferedImage img1, final BufferedImage img2, String fileName, boolean highlight, int colorCode) throws IOException {

		final int w = img1.getWidth();
		final int h = img1.getHeight();
		final int[] p1 = img1.getRGB(0, 0, w, h, null, 0, w);
		final int[] p2 = img2.getRGB(0, 0, w, h, null, 0, w);

		if (!(java.util.Arrays.equals(p1, p2))) {
			m_logger.warn("Image compared - does not match");
			if (highlight) {
				for (int i = 0; i < p1.length; i++) {
					if (p1[i] != p2[i]) {
						p1[i] = colorCode;
					}
				}
				final BufferedImage out = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
				out.setRGB(0, 0, w, h, p1, 0, w);
				saveImage(out, fileName);
			}
			return false;
		}
		return true;
	}

	public void saveImage(BufferedImage image, String file) throws IOException {
		File outputfile = new File(file);
		ImageIO.write(image, "png", outputfile);
	}

	public boolean compareAndHighlightSideBySide(final BufferedImage img1, final BufferedImage img2, String fileName, boolean highlight, int colorCode_Mismatch) throws IOException {

		final int w1 = img1.getWidth();
		final int h1 = img1.getHeight();
		final int[] rgbArr1 = img1.getRGB(0, 0, w1, h1, null, 0, w1);

		final int w2 = img2.getWidth();
		final int h2 = img2.getHeight();
		final int[] rgbArr2 = img2.getRGB(0, 0, w2, h2, null, 0, w2);

		if (!(java.util.Arrays.equals(rgbArr1, rgbArr2))) {
			m_logger.warn("Image compared - does not match");
			if (highlight) {
				for (int i = 0; i < rgbArr1.length; i++) {
					if (rgbArr1[i] != rgbArr2[i]) {
						// To highlight in GREEN in FILE 1, Ignore white pixel from FILE 1 & Ignore BLACK pixel from FILE 2
						int colorCode_Expected = new Color(0, 128, 0).getRGB();
						if (rgbArr1[i] != -1 && rgbArr2[i] == -1)
							rgbArr1[i] = colorCode_Expected;
						// To highlight in RED in FILE 2, Ignore white pixel from FILE 2 & Ignore BLACK pixel from FILE 1
						if (rgbArr1[i] == -1 && rgbArr2[i] != -1)
							rgbArr2[i] = colorCode_Mismatch;
					}
				}

				final BufferedImage part1 = new BufferedImage(w1, h1, BufferedImage.TYPE_INT_ARGB);
				part1.setRGB(0, 0, w1, h1, rgbArr1, 0, w1);

				final BufferedImage part2 = new BufferedImage(w2, h2, BufferedImage.TYPE_INT_ARGB);
				part2.setRGB(0, 0, w2, h2, rgbArr2, 0, w2);

				final BufferedImage finalImage = joinBufferedImage(part1, part2);
				saveImage(finalImage, fileName);
			}
			return false;
		}
		return true;
	}

	public BufferedImage joinBufferedImage(BufferedImage img1, BufferedImage img2) {

		int offset = 5;
		int wid = img1.getWidth() + img2.getWidth() + offset;
		int height = Math.max(img1.getHeight(), img2.getHeight()) + offset;
		// create a new buffer and draw two image into the new image
		BufferedImage newImage = new BufferedImage(wid, height, BufferedImage.TYPE_INT_ARGB);
		Graphics2D g2 = newImage.createGraphics();
		Color oldColor = g2.getColor();
		// fill background
		g2.setPaint(Color.WHITE);
		g2.fillRect(0, 0, wid, height);
		// draw image
		g2.setColor(oldColor);
		g2.drawImage(img1, null, 0, 0);
		g2.drawImage(img2, null, img1.getWidth() + offset, 0);
		g2.dispose();
		return newImage;
	}

}

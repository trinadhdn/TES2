package com.adp.wfnddt.filecomparison;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import com.adp.wfnddt.core.DDTLoggerManager;

public class FileCompareUtil {
    private String[]		    m_excludePattern;
    private int[]		    m_excludeLineNumbers;
    private List<FileCompareResult> m_fileCompareResultList;
    private boolean		    m_breakOnFirstMismatch;
    private String		    m_charSetName = "utf-8";
    private static Logger	    m_logger	  = DDTLoggerManager.getLogger(FileCompareUtil.class);

    public void enableLog() {
	m_logger.setLevel(Level.INFO);
    }

    public void enableLog(Level logLevel) {
	m_logger.setLevel(logLevel);
    }

    public void excludeTextContent(String... regexs) {
	this.m_excludePattern = regexs;
    }

    public void excludeLines(int... lineNumbers) {
	this.m_excludeLineNumbers = lineNumbers;
    }

    public boolean compareTwoFiles(String file1, String file2) {

	List<FileCompareResult> textCompareResultList = new ArrayList<FileCompareResult>();
	boolean bFileContentMatches = true;

	String file1Txt = null, file2Txt = null;
	try {
	    file1Txt = getFileContentAsString(file1); // FileUtils.readFileToString(
						      // new File(file1) );
	    file2Txt = getFileContentAsString(file2); // FileUtils.readFileToString(
						      // new File(file2) );
	} catch (IOException e) {
	    e.printStackTrace();
	}

	if (null != this.m_excludePattern && this.m_excludePattern.length > 0) {
	    for (int i = 0; i < this.m_excludePattern.length; i++) {
		file1Txt = file1Txt.replaceAll(this.m_excludePattern[i], "");
		file2Txt = file2Txt.replaceAll(this.m_excludePattern[i], "");
	    }
	}

	m_logger.debug("------------------- File 1 Txt -------------------\n" + file1Txt);
	m_logger.debug("------------------- File 2 Txt -------------------\n" + file2Txt);

	String file1Lines[] = file1Txt.split("\\r?\\n");
	String file2Lines[] = file2Txt.split("\\r?\\n");

	m_logger.debug("file1Lines.length: " + file1Lines.length);
	m_logger.debug("file2Lines.length: " + file2Lines.length);

	for (int iLineNum = 0; iLineNum < file1Lines.length; iLineNum++) {
	    boolean linesAreEqual = true;

	    String line_file_1 = file1Lines[iLineNum];
	    String line_file_2 = file2Lines[iLineNum];

	    if (line_file_1 == null || line_file_2 == null)
		linesAreEqual = false;
	    else if (!line_file_1.equalsIgnoreCase(line_file_2))
		linesAreEqual = false;

	    bFileContentMatches = bFileContentMatches && linesAreEqual;
	    String strTxtLocation = "LineNo:" + iLineNum;
	    FileCompareResult currentLineResult = new FileCompareResult();
	    currentLineResult.setLocationOfText(strTxtLocation);
	    currentLineResult.setExpectedText(line_file_1);
	    currentLineResult.setActualText(line_file_2);
	    currentLineResult.setCompareStatus(linesAreEqual);
	    textCompareResultList.add(currentLineResult);
	    setResultsTextCompare(textCompareResultList);

	    // for Logging only
	    if (!linesAreEqual) {
		m_logger.info("********** " + strTxtLocation + " **********");
		m_logger.info("Expected : [" + line_file_1 + "]");
		m_logger.info("Actual   : [" + line_file_2 + "]");
	    }

	}
	return bFileContentMatches;

    }

    public void setResultsTextCompare(List<FileCompareResult> resultTextCompare) {
	this.m_fileCompareResultList = resultTextCompare;
    }

    public static String identifyLineDelimiter(String str) {
	if (str.matches("(?s).*(\\r\\n).*")) { // Windows //$NON-NLS-1$
	    return "\r\n"; //$NON-NLS-1$
	} else if (str.matches("(?s).*(\\n).*")) { // Unix/Linux //$NON-NLS-1$
	    return "\n"; //$NON-NLS-1$
	} else if (str.matches("(?s).*(\\r).*")) { // Legacy mac //$NON-NLS-1$
						   // os 9. Newer OS X use \n
	    return "\r"; //$NON-NLS-1$
	} else {
	    return "\n"; // fallback onto '\n' if nothing matches. //$NON-NLS-1$
	}
    }

    public String getFileContentAsString(final String fileName) throws IOException {

	BufferedReader reader = new BufferedReader(new FileReader(fileName));
	StringBuilder stringBuilder = new StringBuilder();
	String line = null;
	String ls = System.getProperty("line.separator");
	while ((line = reader.readLine()) != null) {
	    stringBuilder.append(line);
	    stringBuilder.append(ls);
	}

	// delete the last new line separator
	stringBuilder.deleteCharAt(stringBuilder.length() - 1);
	reader.close();

	return stringBuilder.toString();
    }

}

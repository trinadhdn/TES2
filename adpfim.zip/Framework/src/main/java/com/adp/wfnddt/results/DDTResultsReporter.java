/**
 * 
 */
package com.adp.wfnddt.results;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Stack;
import java.util.stream.Collectors;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

import com.adp.wfnddt.core.DDTController;
import com.adp.wfnddt.core.DDTLoggerManager;
import com.adp.wfnddt.core.DDTUtilityFunctions;
import com.adp.wfnddt.core.GlobalVariables;
import com.adp.wfnddt.results.jaxb.Component;
import com.adp.wfnddt.results.jaxb.DDTResults;
import com.adp.wfnddt.results.jaxb.Flow;
import com.adp.wfnddt.results.jaxb.Group;
import com.adp.wfnddt.results.jaxb.ObjectFactory;
import com.adp.wfnddt.results.jaxb.Run;
import com.adp.wfnddt.results.jaxb.StatusType;
import com.adp.wfnddt.results.jaxb.Step;
import com.adp.wfnddt.results.jaxb.StepParam;
import com.adp.wfnddt.results.jaxb.StepParams;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.splunk.HttpService;
import com.splunk.Job;
import com.splunk.JobArgs;
import com.splunk.JobResultsArgs;
import com.splunk.SSLSecurityProtocol;
import com.splunk.Service;
import com.splunk.ServiceArgs;

import jcifs.smb.NtlmPasswordAuthentication;
import jcifs.smb.SmbFile;

/**
 * @author autoxpert
 *
 */
public class DDTResultsReporter {
	private String m_XMLfilename;
	private String m_HTMLfilename;
	private String m_ScreenshotPath;
	private String m_ScreenShotURL;
	private ObjectFactory m_ObjectFactory = new ObjectFactory();
	private DDTResults m_results;
	private Run m_run;
	private Flow m_flow;
	private Group m_group;
	private Component m_component;
	private Step m_step;
	private StepParams m_stepParams;
	private Stack<Step> m_stepStack = new Stack<Step>();
	private boolean m_bGroup = false;
	private StatusType m_runStatus = StatusType.PASSED;
	private StatusType m_verifyStatus = StatusType.PASSED;
	private boolean m_verificationLog = false;
	private long m_runStartTime = System.currentTimeMillis();
	private long m_runEndTime = System.currentTimeMillis();
	private JsonObject m_splunkResults = null;
	private Logger m_logger = DDTLoggerManager.getLogger(DDTResultsReporter.class);
	private String m_verfLogName = "";
	private String m_verfLogDesc = "";

	public DDTResultsReporter(String p_resultFileNoExt, String p_ScreenshotPath, String p_ScreenShotURL) {
		// p_resultsFile does not include the extension so the reporter must
		// append that according to the format it is using.
		m_XMLfilename = p_resultFileNoExt + ".xml";
		m_HTMLfilename = p_resultFileNoExt + ".html";
		m_ScreenshotPath = p_ScreenshotPath;
		// If p_ScreenShotURL is not null use as prefix for screenshot in XML
		// Step.URL attribute
		// and HTML report hyperlink else use p_ScreenshotPath.
		m_ScreenShotURL = p_ScreenShotURL;
		return;
	}

	public String getHTMLReportFilePath() {
		return m_HTMLfilename;
	}
	
	public Run getRun() {
		return m_run;
	}

	// Initialize the result
	public void startRun(int p_runID, String p_runName) throws DatatypeConfigurationException, UnknownHostException {

		// Set the DDT Results and run elements
		m_results = m_ObjectFactory.createDDTResults();
		m_run = m_ObjectFactory.createRun();

		// Run ID & Name
		m_run.setRunID(p_runID);
		m_run.setRunName(p_runName);

		// Current DateTime
		m_run.setStartTimestamp(getCurrentDateTime());

		// Add the current user
		m_run.setUserID(System.getProperty("user.name"));

		// Add the host name
		m_run.setHostname(InetAddress.getLocalHost().getHostName());

		// Add the OS name
		m_run.setOSName(System.getProperty("os.name"));

		// Add the browser
		m_run.setBrowser(DDTController.getBrowserType().name());

		// Set the build number to default
		m_run.setBuildNumber("NOT AVAILABLE");

		return;
	}

	public XMLGregorianCalendar getCurrentDateTime() throws DatatypeConfigurationException {
		GregorianCalendar gc = new GregorianCalendar();
		gc.setTime(new Date());
		XMLGregorianCalendar XMLGC = DatatypeFactory.newInstance().newXMLGregorianCalendar(gc);
		return XMLGC;
	}

	// Flows
	public void startFlow(String p_FlowName) throws DatatypeConfigurationException {
		m_flow = m_ObjectFactory.createFlow();
		m_flow.setName(p_FlowName);
		m_flow.setStartTimestamp(getCurrentDateTime());

		return;
	}

	public void endFlow(StatusType p_status) {
		if (m_flow.getStatus() == StatusType.FAILED){
			p_status = StatusType.FAILED;
		} else if (p_status != StatusType.FAILED && m_flow.getStatus() == StatusType.WARNING){
			p_status = StatusType.WARNING;
		} 

		m_flow.setStatus(p_status);
		m_run.getFlowOrGroup().add(m_flow);

		if (p_status == StatusType.FAILED)
			m_runStatus = p_status;
		return;
	}

	// Groups
	public void startGroup(String p_GroupName, int p_itrStart, int p_itrEnd) throws DatatypeConfigurationException {
		m_group = m_ObjectFactory.createGroup();
		m_group.setName(p_GroupName);
		m_group.setIterationStart(p_itrStart);
		m_group.setIterationEnd(p_itrEnd);
		m_group.setStartTimestamp(getCurrentDateTime());

		m_bGroup = true;

		return;
	}

	public void endGroup(StatusType p_status) {
		if (m_group.getStatus() == StatusType.FAILED){
			p_status = StatusType.FAILED;
		} else if (p_status != StatusType.FAILED && m_group.getStatus() == StatusType.WARNING){
			p_status = StatusType.WARNING;
		}

		m_group.setStatus(p_status);
		m_run.getFlowOrGroup().add(m_group);

		m_bGroup = false;

		if (p_status == StatusType.FAILED)
			m_runStatus = p_status;
		return;
	}

	// Components
	public void startComponent(String p_componentName, int p_iteration) throws DatatypeConfigurationException {
		m_component = m_ObjectFactory.createComponent();
		m_component.setName(p_componentName);
		m_component.setIteration(p_iteration);
		m_component.setStartTimestamp(getCurrentDateTime());

		if (DDTController.isCapturePerfMetrics()) {
			GlobalVariables.setVariable("HAR PAGE", p_componentName);
			if (DDTController.getBMPServer() != null)
				DDTController.getBMPServer().newPage(p_componentName);
		}
		return;
	}

	public void startComponent(String p_componentName, String p_componentDesc, int p_iteration) throws DatatypeConfigurationException {
		m_component = m_ObjectFactory.createComponent();
		m_component.setName(p_componentName);
		m_component.setDescription(p_componentDesc);
		m_component.setIteration(p_iteration);
		m_component.setStartTimestamp(getCurrentDateTime());

		if (DDTController.isCapturePerfMetrics()) {
			GlobalVariables.setVariable("HAR PAGE", p_componentName);
			if (DDTController.getBMPServer() != null)
				DDTController.getBMPServer().newPage(p_componentName);
		}
		return;
	}

	public void endComponent(StatusType p_status) {
		if (m_component.getStatus() == StatusType.FAILED){
			p_status = StatusType.FAILED;
		} else if (p_status != StatusType.FAILED && m_component.getStatus() == StatusType.WARNING) {
			p_status = StatusType.WARNING;
		}
		
		m_component.setStatus(p_status);

		if (m_bGroup) {
			m_group.getComponent().add(m_component);
			if (p_status == StatusType.FAILED){
				m_group.setStatus(p_status);
			} else if (m_group.getStatus() != StatusType.FAILED && p_status == StatusType.WARNING){
				m_group.setStatus(p_status);
			}

		} else {
			m_flow.getComponent().add(m_component);
			if (p_status == StatusType.FAILED){
				m_flow.setStatus(p_status);
			} else if (m_flow.getStatus() != StatusType.FAILED && p_status == StatusType.WARNING){
				m_flow.setStatus(p_status);
			}
		}

		if (p_status == StatusType.FAILED)
			m_runStatus = p_status;
		return;
	}

	// Test Steps
	public void addTestStep(String p_stepName) throws DatatypeConfigurationException {
		m_step = m_ObjectFactory.createStep();
		m_stepParams = m_ObjectFactory.createStepParams();

		m_step.setName(p_stepName);
		m_step.setStartTimestamp(getCurrentDateTime());

		m_stepStack.push(m_step);
		return;
	}

	public void addTestStep(String p_stepName, String p_description) throws DatatypeConfigurationException {
		m_step = m_ObjectFactory.createStep();
		m_stepParams = m_ObjectFactory.createStepParams();

		m_step.setName(p_stepName);
		m_step.setDescription(p_description);
		m_step.setStartTimestamp(getCurrentDateTime());

		m_stepStack.push(m_step);
		return;
	}

	public void endTestStep(StatusType p_status) {

		boolean bSkipStep = true;

		if (m_step.getStepParams() != null) {
			if (m_step.getStepParams().getStepParam().size() != 0) {
				for (StepParam stepParam : m_step.getStepParams().getStepParam()) {
					if (stepParam.getValue() != "") {
						bSkipStep = false;
						break;
					}
				}
			} else {
				bSkipStep = false;
			}
		} else {
			bSkipStep = false;
		}

		if (bSkipStep) {
			m_stepStack.pop();
		} else {
			if (m_step.getStatus() == StatusType.FAILED) {
				p_status = StatusType.FAILED;
			} else if (p_status != StatusType.FAILED && m_step.getStatus() == StatusType.WARNING){
				p_status = StatusType.WARNING;
			}

			m_step.setStatus(p_status);
			m_stepStack.pop();

			if (m_stepStack.size() == 0) {
				m_component.getStep().add(m_step);
				if (p_status == StatusType.FAILED){
					m_component.setStatus(StatusType.FAILED);
				} else if (p_status == StatusType.WARNING){
					m_component.setStatus(StatusType.WARNING);
				}
			} else {
				m_stepStack.peek().getStep().add(m_step);
				m_step = m_stepStack.peek();
				if (p_status == StatusType.FAILED) {
					m_step.setStatus(StatusType.FAILED);
				} else if (p_status == StatusType.WARNING) {
					m_step.setStatus(StatusType.WARNING);
				} 
			}
		}

		if (p_status == StatusType.FAILED)
			m_runStatus = p_status;

		return;
	}

	public void skipTestStep() {
		m_stepStack.pop();
	}

	// Step Params
	public void addTestStepInputParam(String p_paramName, String p_paramValue) {
		StepParam stepParam = m_ObjectFactory.createStepParam();
		stepParam.setName(p_paramName);
		stepParam.setValue(p_paramValue.replaceAll("<", "&lt;").replaceAll(">", "&gt;"));
		m_stepParams.getStepParam().add(stepParam);
		return;
	}

	public void addParamsToStep() {
		if (m_stepParams.getStepParam().size() > 0)
			m_step.setStepParams(m_stepParams);
		return;
	}

	public void addScreenshotCaptureStep(String p_screenshotName) throws DatatypeConfigurationException {

		Step stepScreenshot = m_ObjectFactory.createStep();
		stepScreenshot.setName(p_screenshotName);

		if (m_ScreenShotURL == null) {
			String screenshotPath = m_ScreenshotPath + "/" + p_screenshotName + ".png";
			stepScreenshot.setURL(screenshotPath);
		} else {
			String screenshotURL = m_ScreenShotURL + "/" + p_screenshotName + ".png";
			stepScreenshot.setURL(screenshotURL);
		}

		stepScreenshot.setStatus(StatusType.DONE);
		stepScreenshot.setStartTimestamp(getCurrentDateTime());

		if (m_stepStack.size() == 0) {
			m_component.getStep().add(stepScreenshot);
		} else {
			m_stepStack.peek().getStep().add(stepScreenshot);
		}
		return;
	}

	public void addComponentScreenshot(String p_screenshotName) throws DatatypeConfigurationException {
		Step stepScreenshot = m_ObjectFactory.createStep();
		stepScreenshot.setName(p_screenshotName);

		if (m_ScreenShotURL == null) {
			String screenshotPath = m_ScreenshotPath + "/" + p_screenshotName + ".png";
			stepScreenshot.setURL(screenshotPath);
		} else {
			String screenshotURL = m_ScreenShotURL + "/" + p_screenshotName + ".png";
			stepScreenshot.setURL(screenshotURL);
		}

		stepScreenshot.setStatus(StatusType.DONE);
		stepScreenshot.setStartTimestamp(getCurrentDateTime());

		m_component.getStep().add(0, stepScreenshot);

		return;
	}

	public void startVerificationLogStep() throws DatatypeConfigurationException, UnknownHostException {
		DateFormat dateFormat = new SimpleDateFormat("MMddyyyy_HHmmss");
		Date date = new Date();

		m_verfLogName = "Verification Log_" + InetAddress.getLocalHost().getHostName() + "_" + dateFormat.format(date).toString();
		m_verfLogDesc = "<table class='verLogTableTop' border='2'>";

		m_verifyStatus = StatusType.PASSED;
		m_verificationLog = true;
		
		return;
	}

	public void addEntryToVerificationLog(String p_verificationText, StatusType p_status, String p_expectedValue, String p_actualValue) {
		if (!m_verificationLog)
			return;

		String statusClass = "done";
		if (p_status == StatusType.PASSED)
			statusClass = "passed";
		if (p_status == StatusType.FAILED)
			statusClass = "failed";

		if (p_expectedValue.trim().contentEquals(""))
			p_expectedValue = "[BLANK]";
		if (p_actualValue.trim().contentEquals(""))
			p_actualValue = "[BLANK]";

		m_verfLogDesc = m_verfLogDesc + "<tr><td><table class='verLogTable " + statusClass + "'><tr><td colspan='2'><span class='text'>" + p_verificationText + "<br>Status: <b>" + p_status.toString() + "</b><br>____________________________________________</span></td></tr><tr><td><span class='text'><b>Expected:</b></span></td><td><span class='text'>" + p_expectedValue.replaceAll("<","&lt;").replaceAll(">", "&gt;") + "</span></td></tr><tr><td><span class='text'><b>Actual:</b></span></td><td><span class='text'>" + p_actualValue.replaceAll("<","&lt;").replaceAll(">", "&gt;") + "</span></td></tr></table></td></tr><tr><td>&nbsp;</td></tr>";

		if (p_status == StatusType.FAILED) {
			m_verifyStatus = StatusType.FAILED;
			GlobalVariables.setResultCode(101);
		}
		return;
	}

	public void endVerificationLogStep(StatusType p_status) throws DatatypeConfigurationException {
		if (!m_verificationLog)
			return;

		m_verifyStatus = p_status;
		endVerificationLogStep();
	}

	public void endVerificationLogStep() throws DatatypeConfigurationException {
		if (!m_verificationLog)
			return;

		m_verfLogDesc = m_verfLogDesc + "</table>";
		
		m_verificationLog = false;
		addTestStep(m_verfLogName, m_verfLogDesc);
		endTestStep(m_verifyStatus);
	}

	public void setTestStepFailed() {
		// TODO
	}

	public void setCompanyCode(String p_companyCode) {
		m_run.setCompanyCode(p_companyCode);
	}

	public void setBrowserInfo(String p_browserInfo) {
		m_run.setBrowser(p_browserInfo);
		return;
	}

	public void setBuildNumber(String p_buildNumber) {
		m_run.setBuildNumber(p_buildNumber);
	}

	public void endRun() throws DatatypeConfigurationException, IOException {
		m_run.setEndTimestamp(getCurrentDateTime());
		m_run.setStatus(m_runStatus);

		// Run Duration
		m_runEndTime = System.currentTimeMillis();
		long runDuration = (m_runEndTime - m_runStartTime) / 60000;
		m_run.setRunDuration(runDuration + " min");

		m_results.setRun(m_run);
		
		//Copy the screenshot files
		for (String screenshotPath : DDTController.getScreenshotMap().keySet()) {
			if (DDTController.getRunID() > 0) {
				try {
					NtlmPasswordAuthentication auth = new NtlmPasswordAuthentication("es.ad.adp.com", "autoxpert", "adpadp");
					DDTUtilityFunctions.copyLocalFileToNetFolder(DDTController.getScreenshotMap().get(screenshotPath), new SmbFile("smb:" + screenshotPath.replace("\\", "/"), auth));
				} catch (Exception e) { // Copy using the file utils if the SMB fails
					FileUtils.copyFile(DDTController.getScreenshotMap().get(screenshotPath), new File(screenshotPath));
				}
			} else {
				FileUtils.copyFile(DDTController.getScreenshotMap().get(screenshotPath), new File(screenshotPath));
			}
		}

		// Performance Metrics
		if (DDTController.isCapturePerfMetrics()) {
			DDTController.generateHAR();
		}

		// Splunk Metrics
		if (DDTController.isCaptureSplunkMetrics() && !GlobalVariables.getSplunkIndex().equals("")) {
			try {
				m_splunkResults = captureSplunkMetrics();
				if (m_splunkResults != null)
					m_run.setSplunkExceptions(m_splunkResults.get("TotalExceptions").getAsInt());
			} catch (Exception ex) {
				m_logger.debug("Exception occured connecting to Splunk", ex);
			}
		}
		return;
	}

	public JsonObject captureSplunkMetrics() throws IOException {

		long splunkCallStart = System.currentTimeMillis();

		HttpService.setSslSecurityProtocol(SSLSecurityProtocol.TLSv1_2);

		// Connect to Splunk
		ServiceArgs serviceArgs = new ServiceArgs();
		serviceArgs.setHost(GlobalVariables.getSplunkAPIURL());
		serviceArgs.setPort(GlobalVariables.getSplunkAPIPort());
		serviceArgs.setApp("wfn_pw");

		// Create a Service instance and log in with the argument map
		Service service = Service.connect(serviceArgs);
		service.login("autoxpert", "adpadp");

		// Construct the search string
		String index = GlobalVariables.getSplunkIndex();
		String clientID = GlobalVariables.getRuntimeClientID();
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy:HH:mm:ss");

		String runStartdate = dateFormat.format(new Date(m_runStartTime));
		String runEnddate = dateFormat.format(new Date(m_runEndTime));

		// String searchString = "index=" + index + " (sourcetype=wfnjsonlogs OR
		// sourcetype=wfnlogs) USER=*@" + clientID + " earliest=\"" +
		// runStartdate + "\" latest=\"" + runEnddate + "\" *Exception* | stats
		// count by message | sort -count";
		String searchString = "index=" + index + " (sourcetype=wfnjsonlogs OR sourcetype=wfnlogs) USER=*@" + clientID + " earliest=\"" + runStartdate + "\" latest=\"" + runEnddate + "\" *Exception* | eval Exception=if(isNull(message), STACKTRACE, message) | stats count by sourcetype,Exception | sort -count";
		m_logger.debug("Splunk Search:" + searchString);
		
		// Run the search synchronously
		JobArgs jobargs = new JobArgs();
		jobargs.setExecutionMode(JobArgs.ExecutionMode.BLOCKING);
		Job jobSearch = service.getJobs().create("search " + searchString, jobargs);

		// Retrieve the results
		JobResultsArgs resultsArgs = new JobResultsArgs();
		resultsArgs.setOutputMode(JobResultsArgs.OutputMode.JSON);

		// Display results in JSON using ResultsReaderJson
		InputStream results = jobSearch.getResults(resultsArgs);
		BufferedReader br = new BufferedReader(new InputStreamReader(results));
		String result = IOUtils.toString(br);

		// Read the JSON
		JsonParser jsonParser = new JsonParser();
		JsonObject resultsJSON = jsonParser.parse(result).getAsJsonObject();
		int resultCount = resultsJSON.get("results").getAsJsonArray().size();

		List<String> exceptions = new ArrayList<String>();
		for (JsonElement jsonObject : resultsJSON.get("results").getAsJsonArray()) {
			String exception = jsonObject.getAsJsonObject().get("Exception").getAsString();
			if (!exceptions.contains(exception)) {
				exceptions.add(exception);
			}
		}

		service.logout();

		long splunkCallEnd = System.currentTimeMillis();
		String duration = ((splunkCallEnd - splunkCallStart) / 1000) + " sec";

		// Format the splunk info
		JsonObject splunkInfo = new JsonObject();
		splunkInfo.addProperty("TotalExceptions", resultCount);
		splunkInfo.addProperty("UniqueExceptions", exceptions.size());
		splunkInfo.addProperty("ClientID", clientID);
		splunkInfo.addProperty("RunStartDateTime", runStartdate);
		splunkInfo.addProperty("RunEndDateTime", runEnddate);
		splunkInfo.addProperty("SearchDuration", duration);
		splunkInfo.addProperty("SplunkLink", GlobalVariables.getSplunkWebURL() + "?q=search " + searchString);

		return splunkInfo;
	}

	public void generateXMLReport() throws JAXBException {
		JAXBContext context = JAXBContext.newInstance(DDTResults.class);
		Marshaller m = context.createMarshaller();

		m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
		m.setProperty(Marshaller.JAXB_NO_NAMESPACE_SCHEMA_LOCATION, "ResultsSchema.xsd");

		// Write to file
		File resultsFile = new File(m_XMLfilename);
		m.marshal(m_results, resultsFile);

		return;
	}

	public void generateHTMLReport() throws IOException {
		Gson gson = new GsonBuilder().registerTypeAdapter(XMLGregorianCalendar.class, new XMLGregorianCalendarConverter.Deserializer()).registerTypeAdapter(XMLGregorianCalendar.class, new XMLGregorianCalendarConverter.Serializer()).create();

		String jsonString = gson.toJson(m_results.getRun());

		// Generate JSON
		jsonString = jsonString.replace("\"name\":", "\"title\":");
		jsonString = jsonString.replace("\"flowOrGroup\":[", "\"type\":\"flowOrGroup\", \"children\": [");
		jsonString = jsonString.replace("\"component\":[", "\"type\":\"component\", \"children\": [");
		jsonString = jsonString.replace("\"step\":[", "\"type\":\"step\", \"children\": [");
		jsonString = jsonString.replace("{\"stepParams\":{", "{\"children\": [],\"stepParams\":{");

		// Process the html
		// Document reportHTML = Jsoup.parse(new
		// File(getClass().getClassLoader().getResource("Report.html").getFile()),
		// "UTF-8");
		InputStream in = getClass().getResourceAsStream("/Report.html");
		BufferedReader br = new BufferedReader(new InputStreamReader(in));
		Document reportHTML = Jsoup.parse(br.lines().collect(Collectors.joining()), "UTF-8");
		reportHTML.getElementById("JSONData").appendText(jsonString);
		if (m_splunkResults != null)
			reportHTML.getElementById("SplunkData").appendText(m_splunkResults.toString());

		File HTMLfile = new File(m_HTMLfilename);
		FileWriter fw = new FileWriter(HTMLfile);
		fw.write(reportHTML.html());
		fw.close();

		br.close();
		in.close();

		return;
	}
}

// Implementation Requirements
// 1. Must keep track of next component ID (starts at 0 for each run)
// 2. Must keep track of next step ID (starts at 0 for each run)
// 3. Must keep track of iteration count(starts at 0 for each component)
// 4. Must keep track of current component ID (if components can be nested a
// stack must be used).
// 5. addTestStep() is relative to current component.
// 6. addScreenshotCaptureStep is relative to current component.
// 7. URLs of screenshot capture files must be recorded in report.
// 8. setTestStepFailed sets current step as failed and current component as
// failed and run as failed.

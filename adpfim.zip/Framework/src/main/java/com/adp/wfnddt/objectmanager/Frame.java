package com.adp.wfnddt.objectmanager;

import java.io.IOException;

import javax.xml.datatype.DatatypeConfigurationException;

import org.openqa.selenium.WebElement;

import com.adp.wfnddt.aspects.Step;
import com.adp.wfnddt.core.DDTFrameworkException;
import com.adp.wfnddt.objectmanager.DefaultMethod.TypeOfMethod;

public class Frame extends BaseObject {

	public Frame(String p_selector) {
		setSelector(p_selector);
	}

	public Frame(WebElement p_object) {
		setObject(p_object);
	}

	@Step
	@DefaultMethod(MethodType = TypeOfMethod.Action)
	public void switchTo() throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		findObject();

		m_webdriver.switchTo().frame(getObject());
		return;
	}

	@Step
	public void switchToDefaultContent() throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		m_webdriver.switchTo().defaultContent();
		return;
	}
}

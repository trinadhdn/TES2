package com.adp.wfnddt.aspects;

import com.adp.wfnddt.core.DDTFrameworkException;
import com.adp.wfnddt.parammanager.ParamManager;

public class SampleComponent {
	
	@Component(Name="Test Component")
	public void testComponent(ParamManager pm) throws DDTFrameworkException{
		//This is a test component to get rid of the aspect warnings
		return;
	}
}

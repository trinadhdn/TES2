package com.adp.wfnddt.objectmanager.extendedobjects;

import com.adp.wfnddt.objectmanager.WebLink;

public class ActionIcon extends WebLink {
	public ActionIcon() {
		super("CSS:span.fa.fa-angle-right, i.fa.fa-chevron-right, a[class$=ActionLink], span.fa.fa-chevron-circle-right");
	}
}

/**
 * 
 */
package com.adp.wfnddt.core;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.UnknownHostException;

import org.apache.log4j.Logger;

import jcifs.smb.SmbException;
import jcifs.smb.SmbFile;
import jcifs.smb.SmbFileInputStream;
import jcifs.smb.SmbFileOutputStream;

/**
 * @author wiermanp
 *
 */
public class DDTUtilityFunctions {
	private static Logger m_logger = DDTLoggerManager.getLogger(DDTUtilityFunctions.class);
	private static final int IOBUFFER_SIZE = 8192;

	public static void copyNetFileToLocalFolder(SmbFile p_srcNetFile, File p_destLocalFile) throws DDTFrameworkException {
		SmbFileInputStream is;
		FileOutputStream fos;
		byte[] ioBuffer = new byte[IOBUFFER_SIZE];
		
		try {
			is = new SmbFileInputStream(p_srcNetFile);
			fos = new FileOutputStream(p_destLocalFile);
			
			int bytesRead = 0;
			while ((bytesRead = is.read(ioBuffer, 0, IOBUFFER_SIZE)) >= 0 ) {
				fos.write(ioBuffer, 0, bytesRead);
			}
			
			fos.close();
			is.close();
		} catch (SmbException e) {
			m_logger.error("SMB Protocol error.", e);
			throw new DDTFrameworkException(DDTUtilityFunctions.class, e.getMessage());
		} catch (MalformedURLException e) {
			m_logger.error(String.format("Bad URL: %1$s", p_srcNetFile.getURL().toString()), e);
			throw new DDTFrameworkException(DDTUtilityFunctions.class, e.getMessage());
		} catch (UnknownHostException e) {
			m_logger.error(String.format("Unknown host: %1$s",  p_srcNetFile.getServer()), e);
			throw new DDTFrameworkException(DDTUtilityFunctions.class, e.getMessage());
		} catch (FileNotFoundException e) {
			m_logger.error(String.format("Invalid local file path (%1$s) provided.", p_destLocalFile.getPath()), e);
			throw new DDTFrameworkException(DDTUtilityFunctions.class, e.getMessage());
		} catch (IOException e) {
			m_logger.error("IO error while writing local file.", e);
			throw new DDTFrameworkException(DDTUtilityFunctions.class, e.getMessage());
		} catch (Exception e) {
			m_logger.error("Unexpected error while copying net file to local folder.", e);
			throw new DDTFrameworkException(DDTUtilityFunctions.class, e.getMessage());
		}
		
		return;
	}

	public static void copyLocalFileToNetFolder(File p_srcLocalFile, SmbFile p_destNetFile) throws DDTFrameworkException {
		FileInputStream is;
		SmbFileOutputStream fos;
		byte[] ioBuffer = new byte[IOBUFFER_SIZE];
		
		try {
			is = new FileInputStream(p_srcLocalFile);
			fos = new SmbFileOutputStream(p_destNetFile);
		
			int bytesRead = 0;
			while ((bytesRead = is.read(ioBuffer, 0, IOBUFFER_SIZE)) >= 0 ) {
				fos.write(ioBuffer, 0, bytesRead);
			}
			
			fos.close();
			is.close();
		} catch (SmbException e) {
			m_logger.error("SMB Protocol error.", e);
			throw new DDTFrameworkException(DDTUtilityFunctions.class, e.getMessage());
		} catch (MalformedURLException e) {
			m_logger.error(String.format("Bad URL: %1$s", p_destNetFile.getURL().toString()), e);
			throw new DDTFrameworkException(DDTUtilityFunctions.class, e.getMessage());
		} catch (UnknownHostException e) {
			m_logger.error(String.format("Unknown host: %1$s",  p_destNetFile.getServer()), e);
			throw new DDTFrameworkException(DDTUtilityFunctions.class, e.getMessage());
		} catch (FileNotFoundException e) {
			m_logger.error(String.format("Invalid local file path (%1$s) provided.", p_srcLocalFile.getPath()), e);
			throw new DDTFrameworkException(DDTUtilityFunctions.class, e.getMessage());
		} catch (IOException e) {
			m_logger.error("IO error while writing local file.", e);
			throw new DDTFrameworkException(DDTUtilityFunctions.class, e.getMessage());
		} catch (Exception e) {
			m_logger.error("Unexpected error while copying net file to local folder.", e);
			throw new DDTFrameworkException(DDTUtilityFunctions.class, e.getMessage());
		}
		
		return;
	}

	public static void copyNetFileToNetFolder(SmbFile p_srcNetFile, SmbFile p_destNetFile) throws DDTFrameworkException {
		SmbFileInputStream is;
		SmbFileOutputStream fos;
		byte[] ioBuffer = new byte[IOBUFFER_SIZE];
		int iStep = 1;
		
		try {
			is = new SmbFileInputStream(p_srcNetFile);
			iStep = 2;
			fos = new SmbFileOutputStream(p_destNetFile);
			
			int bytesRead = 0;
			while ((bytesRead = is.read(ioBuffer, 0, IOBUFFER_SIZE)) >= 0 ) {
				fos.write(ioBuffer, 0, bytesRead);
			}
			
			fos.close();
			is.close();
		} catch (SmbException e) {
			m_logger.error("SMB Protocol error.", e);
			throw new DDTFrameworkException(DDTUtilityFunctions.class, e.getMessage());
		} catch (MalformedURLException e) {
			m_logger.error(String.format("Bad URL: %1$s", (iStep==1) ? p_srcNetFile.getURL().toString() : p_destNetFile.getURL().toString()), e);
			throw new DDTFrameworkException(DDTUtilityFunctions.class, e.getMessage());
		} catch (UnknownHostException e) {
			m_logger.error(String.format("Unknown host: %1$s", (iStep==1) ? p_srcNetFile.getServer() : p_destNetFile.getServer()), e);
			throw new DDTFrameworkException(DDTUtilityFunctions.class, e.getMessage());
		} catch (FileNotFoundException e) {
			m_logger.error(String.format("Invalid local file path (%1$s) provided.", (iStep==1) ? p_srcNetFile.getPath() : p_destNetFile.getPath()), e);
			throw new DDTFrameworkException(DDTUtilityFunctions.class, e.getMessage());
		} catch (IOException e) {
			m_logger.error("IO error while writing local file.", e);
			throw new DDTFrameworkException(DDTUtilityFunctions.class, e.getMessage());
		} catch (Exception e) {
			m_logger.error("Unexpected error while copying net file to local folder.", e);
			throw new DDTFrameworkException(DDTUtilityFunctions.class, e.getMessage());
		}
		
		return;
	}
	
	public static long getResourceLength(InputStream p_inStrm) throws IOException
	{
		int iLen = 0;
		int iBytesRead = 0;
		byte[] ioBuff = new byte[IOBUFFER_SIZE];
		
		while ((iBytesRead = p_inStrm.read(ioBuff)) >= 0) {
			iLen += iBytesRead;
		}
		
		return iLen;
	}
}

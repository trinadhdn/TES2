/**
 * 
 */
package com.adp.wfnddt.core;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.ConsoleAppender;
import org.apache.log4j.Level;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;
import org.apache.log4j.RollingFileAppender;

/**
 * @author autoxpert
 *
 */
public class DDTLoggerManager {
	private static RollingFileAppender m_fileAppender = null;

	public static Logger getLogger(Class<?> p_clazz) {
		if(m_fileAppender == null) {
			configureLogger(p_clazz);
		}
		
		Logger classLogger = LogManager.exists(p_clazz.getName());
		
		if(classLogger == null) {
			classLogger = Logger.getLogger(p_clazz);
			classLogger.removeAllAppenders();
			classLogger.addAppender(m_fileAppender);
			classLogger.setLevel(Level.DEBUG);
		}
		
		return classLogger;
	}
	
	private static void configureLogger(Class<?> p_clazz) {
		BasicConfigurator.configure();
		
		// Send log to IDE console
		Logger rootLogger = Logger.getRootLogger();
		rootLogger.removeAllAppenders();
		ConsoleAppender consAppender = new ConsoleAppender(new PatternLayout("%d{yyyy-MM-dd HH:mm:ss} %-5p %c{1}:%L - %m%n"), ConsoleAppender.SYSTEM_OUT);
		consAppender.setName("DDT_Console");
		rootLogger.addAppender(consAppender);		
		rootLogger.setLevel(Level.DEBUG);

		// Setup file appender
		String logFilePath = DDTController.getSysProperty("logfile.path");

		if(logFilePath == null){
			logFilePath = System.getenv("TEMP");
		}

		if(logFilePath != null) {
			String logFile = logFilePath + "/" + DDTController.getRunName() + ".log";
			
			RollingFileAppender fileAppender = new RollingFileAppender();
			fileAppender.setName("DDT_Logger");
			fileAppender.setFile(logFile);
			fileAppender.setMaxBackupIndex(50);
			fileAppender.setMaxFileSize("100KB");
			fileAppender.setLayout(new PatternLayout("%d{yyyy-MM-dd HH:mm:ss} %-5p %c{1}:%L - %m%n"));
			fileAppender.setAppend(true);
			fileAppender.activateOptions();		
			m_fileAppender = fileAppender;
		}
		
		return;
	}
}

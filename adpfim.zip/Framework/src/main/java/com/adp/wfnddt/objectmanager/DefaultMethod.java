package com.adp.wfnddt.objectmanager;

import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.*;


@Retention(RUNTIME)
@Target(METHOD)
public @interface DefaultMethod {
	public enum TypeOfMethod{
		Action,
		Verification
	}
	TypeOfMethod MethodType();
}

package com.adp.wfnddt.excelcomparison;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.List;

import org.apache.log4j.Level;
import org.apache.poi.ss.util.CellAddress;

import com.adp.wfnddt.core.DDTController;
import com.adp.wfnddt.results.DDTResultsReporter;
import com.adp.wfnddt.results.jaxb.StatusType;

public class ExcelCompare {

    private static DDTResultsReporter m_results = DDTController.getResultsReporter();

    public static boolean compareTwoSpreadSheets(String p_fileName1, String p_fileName2) throws Exception {
	return compareTwoSpreadSheets(p_fileName1, p_fileName2, new String[] { "1" }, "MM/dd/yyyy", new String[] {});
    }

    public static boolean compareTwoSpreadSheets(String p_fileName1, String p_fileName2, String p_dateFormat) throws Exception {
	return compareTwoSpreadSheets(p_fileName1, p_fileName2, new String[] { "1" }, p_dateFormat, new String[] {});
    }

    public static boolean compareTwoSpreadSheets(String p_fileName1, String p_fileName2, String[] p_sheetIndexes) throws Exception {
	return compareTwoSpreadSheets(p_fileName1, p_fileName2, p_sheetIndexes, "MM/dd/yyyy", new String[] {});
    }

    public static boolean compareTwoSpreadSheets(String p_fileName1, String p_fileName2, String p_dateFormat, Object[] arrExcludeConditions) throws Exception {
	return compareTwoSpreadSheets(p_fileName1, p_fileName2, new String[] { "1" }, p_dateFormat, arrExcludeConditions);
    }

    public static boolean compareTwoSpreadSheets(String p_fileName1, String p_fileName2, String[] p_sheetIndexes, String p_dateFormat) throws Exception {
	return compareTwoSpreadSheets(p_fileName1, p_fileName2, p_sheetIndexes, p_dateFormat, new String[] {});
    }

    public static boolean compareTwoSpreadSheets(String p_fileName1, String p_fileName2, String[] sheetIndexes, String p_dateFormat, Object[] arrExcludeConditions) throws Exception {
	ExcelCompareUtil excelCompareUtil = new ExcelCompareUtil();
	m_results.startVerificationLogStep();

	excelCompareUtil.enableLog(Level.INFO);

	// Read Date Time values as required
	excelCompareUtil.dateTimeFormat(new SimpleDateFormat(p_dateFormat));

	// Ignore cells by Address
	if (arrExcludeConditions instanceof CellAddress[])
	    excelCompareUtil.excludeCellAddresses((CellAddress[]) arrExcludeConditions);

	// Ignore Columns by index
	if (arrExcludeConditions instanceof Integer[])
	    excelCompareUtil.excludeColumns((Integer[]) arrExcludeConditions);

	// Ignore Cells By Content
	if (arrExcludeConditions instanceof String[])
	    excelCompareUtil.excludeContent((String[]) arrExcludeConditions);

	excelCompareUtil.setSheetIndexes(sheetIndexes);

	boolean bFileContentMatched = excelCompareUtil.compareExcelFileContents(new File(p_fileName1), new File(p_fileName2));

	List<ExcelCompareResult> resultList = excelCompareUtil.getFileCompareResultList();

	for (ExcelCompareResult result : resultList) {
	    if (!result.isCompareStatus())
		m_results.addEntryToVerificationLog(" { " + result.getLocationOfText() + " } ", StatusType.FAILED, result.getExpectedText(), result.getActualText());
	    else
		m_results.addEntryToVerificationLog(" { " + result.getLocationOfText() + " } ", StatusType.PASSED, result.getExpectedText(), result.getActualText());
	}

	m_results.endVerificationLogStep();

	return bFileContentMatched;
    }

}

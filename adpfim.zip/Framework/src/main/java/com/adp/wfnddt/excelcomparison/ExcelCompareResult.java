package com.adp.wfnddt.excelcomparison;

public class ExcelCompareResult {
	String locationOfText;
	String expectedText;
	String actualText;
	boolean compareStatus;

	public String getLocationOfText() {
		return locationOfText;
	}

	public void setLocationOfText(String locationOfText) {
		this.locationOfText = locationOfText;
	}

	public String getExpectedText() {
		return expectedText;
	}

	public void setExpectedText(String expectedText) {
		this.expectedText = expectedText;
	}

	public String getActualText() {
		return actualText;
	}

	public void setActualText(String actualText) {
		this.actualText = actualText;
	}

	public boolean isCompareStatus() {
		return compareStatus;
	}

	public void setCompareStatus(boolean compareStatus) {
		this.compareStatus = compareStatus;
	}

}

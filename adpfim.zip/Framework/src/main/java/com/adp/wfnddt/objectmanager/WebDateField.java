package com.adp.wfnddt.objectmanager;

import static com.adp.wfnddt.commonmethods.General.performTextComparison;

import java.io.IOException;

import javax.xml.datatype.DatatypeConfigurationException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import com.adp.wfnddt.aspects.Step;
import com.adp.wfnddt.commonmethods.General;
import com.adp.wfnddt.commonmethods.General.ComparisonType;
import com.adp.wfnddt.core.DDTFrameworkException;
import com.adp.wfnddt.objectmanager.DefaultMethod.TypeOfMethod;
import com.adp.wfnddt.results.jaxb.StatusType;

public class WebDateField extends BaseObject {

	public WebDateField(String p_selector) {
		setSelector(p_selector);
	}

	public WebDateField(WebElement p_object) {
		setObject(p_object);
	}

	@Step(Params = { "Date" })
	@DefaultMethod(MethodType = TypeOfMethod.Action)
	public void setValue(String p_value) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		setValue(p_value, true);
	}

	public void setValue(String p_value, boolean p_tab) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		if (p_value.trim().contentEquals(""))
			return;

		findObject();
		waitForClickable();

		// Find the input element and enter the value
		if (getObject().findElements(By.xpath(".//input[contains(@class,'reactVDL') and contains(@class,'dateInputBox')]")).size() != 0) { // React
			clearText(getObject().findElement(By.xpath(".//input[contains(@class,'reactVDL') and contains(@class,'dateInputBox')]")));
			if (!p_value.equalsIgnoreCase("[BLANK]"))
				getObject().findElement(By.xpath(".//input[contains(@class,'reactVDL') and contains(@class,'dateInputBox')]")).sendKeys(p_value);
		} else if (getObject().findElements(By.cssSelector("input.dijitReset.dijitInputInner")).size() != 0) { // Dijit
			clearText(getObject().findElement(By.cssSelector("input.dijitReset.dijitInputInner")));
			if (!p_value.equalsIgnoreCase("[BLANK]"))
				getObject().findElement(By.cssSelector("input.dijitReset.dijitInputInner")).sendKeys(p_value);
		} else if (getObject().findElements(By.cssSelector(".vdl-date-time-picker__input")).size() != 0) {
			clearText(getObject().findElement(By.cssSelector(".vdl-date-time-picker__input")));
			
			if (!p_value.equalsIgnoreCase("[BLANK]"))
				getObject().findElement(By.cssSelector(".vdl-date-time-picker__input")).sendKeys(p_value);
		}

		if (p_tab) {
			getObject().findElement(By.xpath(".//input")).sendKeys(Keys.ENTER);
			General.sleep(1);
			getObject().findElement(By.xpath(".//input")).sendKeys(Keys.TAB);
		}
		return;
	}

	@DefaultMethod(MethodType = TypeOfMethod.Verification)
	public void verifyValue(String p_value) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		verifyValue(p_value, new ComparisonType[] { ComparisonType.Exact });
	}

	public void verifyValue(String p_value, ComparisonType[] p_comparisonTypes) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		if (p_value.trim().contentEquals(""))
			return;

		findObject();

		String expectedValue = p_value.trim();

		// Return if not displayed
		if (!getObject().isDisplayed()) {
			m_results.addEntryToVerificationLog("Verify value for : " + getClass().getSimpleName() + "(\"" + m_objectName + "\")", StatusType.FAILED, expectedValue, "[OBJECT_NOT_VISIBLE]");
			return;
		}

		String actualValue = getActualValue();

		StatusType status = performTextComparison(expectedValue, actualValue, p_comparisonTypes);

		m_results.addEntryToVerificationLog("Verify value for : " + getClass().getSimpleName() + "(\"" + m_objectName + "\")", status, expectedValue, actualValue);

		return;
	}

	public String getActualValue() throws IOException, DatatypeConfigurationException, DDTFrameworkException{
		String actualValue = getObject().getText().trim();
		actualValue = actualValue.replace("?","");
		if (actualValue.contentEquals("")) {
			if (getObject().findElements(By.cssSelector(".reactVDL.dateInputBox[type='text']")).size() != 0) {
				actualValue = getObject().findElement(By.cssSelector(".reactVDL.dateInputBox[type='text']")).getAttribute("value").trim();
			}

			if (getObject().findElements(By.cssSelector("input.dijitReset.dijitInputInner[role='textbox']")).size() != 0) {
				actualValue = getObject().findElement(By.cssSelector("input.dijitReset.dijitInputInner[role='textbox']")).getAttribute("value").trim();
			}

			if (getObject().findElements(By.cssSelector(".vdl-date-time-picker__input[type='text']")).size() != 0) {
				actualValue = getObject().findElement(By.cssSelector(".vdl-date-time-picker__input[type='text']")).getAttribute("value").trim();
			}
		}

		// Compare
		if (actualValue.contentEquals(""))
			actualValue = "[BLANK]";
		
		return actualValue;
	}
	
	public void verifyObjectProperties(String p_property) throws DDTFrameworkException, DatatypeConfigurationException, IOException {
		if (exists()) {
			if (getObject().findElements(By.cssSelector(".reactVDL.dateInputBox")).size() != 0 && (p_property.equalsIgnoreCase("[DISABLED]") || p_property.equalsIgnoreCase("[ENABLED]"))) {
				verifyObjectProperties(p_property, VerifyPropertyType.DISABLED_classDisabled, getObject().findElement(By.cssSelector(".reactVDL.dateInputBox")));
			}
			// Added vdl-date
			else if (getObject().getAttribute("class").contains("vdl-date") && (getObject().getAttribute("aria-disabled")!=null ||getObject().findElement(By.xpath("input")).getAttribute("aria-disabled")!=null) && (p_property.equalsIgnoreCase("[DISABLED]") || p_property.equalsIgnoreCase("[ENABLED]"))) {
				verifyObjectProperties(p_property, VerifyPropertyType.DISABLED_ariaDisabled, getObject().findElement(By.xpath("input")));
			} else {
				super.verifyObjectProperties(p_property);
			}
		} else {
			super.verifyObjectProperties(p_property);
		}
	}

}

/**
 * 
 */
package com.adp.wfnddt.core;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import org.apache.cxf.jaxrs.client.WebClient;
import org.apache.cxf.transport.http.HTTPConduit;
import org.apache.log4j.Logger;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

/**
 * @author Wiermanp
 *
 */
public abstract class WFNClientDBDMLServicesProxy {
	private static Logger m_logger = DDTLoggerManager.getLogger(WFNClientDBDMLServicesProxy.class);
	
	public void submitDMLCommands(String p_dbInstanceTns, String p_dbSchema, String p_password,
								   String p_vpdKey, String p_useSKIPVPD, String p_DMLResourcePath) throws DDTFrameworkException {
		String strClientSchema = GlobalVariables.getRuntimeClientDB();
		
		if(strClientSchema != null) {
			InputStream dmlInStrm = null;
			WebClient webClient = null;
			InputStream respStream = null;
			InputStreamReader isr = null;
			BufferedReader br = null;

			try {
				Class<? extends WFNClientDBDMLServicesProxy> thisClass = getClass();
				dmlInStrm = thisClass.getResourceAsStream(p_DMLResourcePath);
				
				if(dmlInStrm != null) {
					long lLen = DDTUtilityFunctions.getResourceLength(dmlInStrm);
					dmlInStrm.close();
					dmlInStrm = null;
					
					// There something in the DML script resource send it to
					// the web service for processing.
					if(lLen > 0) {
						dmlInStrm = thisClass.getResourceAsStream(p_DMLResourcePath);
						StringBuilder sbURL = new StringBuilder("http://");
						sbURL.append(DDTController.getClientDBDMLServiceHost());
						webClient = WebClient.create(sbURL.toString());
						HTTPConduit conduit = WebClient.getConfig(webClient).getHttpConduit();
						m_logger.debug(String.format("Connect Timeout=%1$d, ReceiveTimeout=%2$d", conduit.getClient().getConnectionTimeout(), conduit.getClient().getReceiveTimeout()));
						conduit.getClient().setReceiveTimeout(1000L * 370L);
			
						// Post API
						m_logger.debug("submitDMLCommands Send Post");
						Response clientPostResponse = webClient
							.type(MediaType.TEXT_PLAIN_TYPE)
							.accept(MediaType.APPLICATION_JSON_TYPE)
							.header("Content-Length", new Long(lLen).toString())
							.path("OracleDMLReqHandler/")
							.query("dbTnsName", p_dbInstanceTns)
							.query("useSKIPVPD", p_useSKIPVPD)
							.query("dbSchema", p_dbSchema)
							.query("password", p_password)
							.query("vpdKey", p_vpdKey)
							.post(dmlInStrm, Response.class);
						
						try {
							dmlInStrm.close();
						} catch (Exception ex) {
							m_logger.error("Error closing DML resource input stream: ", ex);
						}
						dmlInStrm = null;
						
						if (clientPostResponse.getStatus() == 200) {
							respStream = (InputStream) clientPostResponse.getEntity();
							isr = new InputStreamReader(respStream);
							br = new BufferedReader(isr);
							processResponse(br);
						} else if (clientPostResponse.getStatus() == 500) {
							BufferedReader buffRdr = null;

							try {
								String strAppReason = clientPostResponse.getStatusInfo().getReasonPhrase();
								String strOssErrorType = clientPostResponse.getHeaderString("OSSErrorType");
								
								// Get reason using GSON.
								if(strOssErrorType != null) {
									buffRdr = new BufferedReader(new InputStreamReader((InputStream) clientPostResponse.getEntity()));
									JsonParser parser = new JsonParser();
									JsonObject jsonObjects = parser.parse(buffRdr).getAsJsonObject();
									JsonElement jsonElem = jsonObjects.get("ErrorReason");
									strAppReason = jsonElem.getAsString();
									buffRdr.close();
								}
								
								throw new DDTFrameworkException(WFNClientDBDMLServicesProxy.class, String.format("Service call failed. Reason: %2$s [status=%1$d].", clientPostResponse.getStatus(), strAppReason));
							} catch (DDTFrameworkException dfEx) {
								throw dfEx;
							} catch (Exception ex) {
								if(buffRdr != null) {
									buffRdr.close();
								}

								throw new DDTFrameworkException(WFNClientDBDMLServicesProxy.class, String.format("Service call failed. Reason: %2$s [status=%1$d].", clientPostResponse.getStatus(), "<unknown>"));
							}
						} else {
							throw new DDTFrameworkException(WFNClientDBDMLServicesProxy.class, String.format("Service call failed. Reason: %2$s [status=%1$d].", clientPostResponse.getStatus(), clientPostResponse.getStatusInfo().getReasonPhrase()));
						}
					} else {
						throw new DDTFrameworkException(WFNClientDBDMLServicesProxy.class, "The DML script resource is empty.");
					}
				} else {
					throw new DDTFrameworkException(WFNClientDBDMLServicesProxy.class, "The DML script resource was not found.");
				}
			} catch (DDTFrameworkException dfEx) {
				throw dfEx;
			} catch (IOException ioEx) {
				throw new DDTFrameworkException(WFNClientDBDMLServicesProxy.class, "An I/O error ocurred while processing REST service streams: ", ioEx);
			} catch (Exception ex) {
				throw new DDTFrameworkException(WFNClientDBDMLServicesProxy.class, "An unexpected error ocurred while invoking REST service: ", ex);
			} finally {
				if(dmlInStrm != null) {
					try {
						dmlInStrm.close();
					} catch (Exception ex) {
						m_logger.error("Second shot error closing DML resource input stream: ", ex);
					}
				}
				
				if (webClient != null) {
					try {
						if(br != null) {
							br.close();
						} else if(isr != null) {
							isr.close();
						} else if(respStream != null) {
							respStream.close();
						}
					} catch (Exception ex) {
						m_logger.error("An error occurred while closing DML response stream: ", ex);
					}
					
					webClient.close();
				}
			}				
		} else {
			throw new DDTFrameworkException(WFNClientDBDMLServicesProxy.class, "The client schema name has not been determined");			
		}
		
		return;
	}
	
	protected abstract void processResponse(BufferedReader p_RespReader) throws IOException;
}

package com.adp.wfnddt.objectmanager;

import java.io.IOException;

import javax.xml.datatype.DatatypeConfigurationException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.adp.wfnddt.aspects.Step;
import com.adp.wfnddt.core.DDTFrameworkException;
import com.adp.wfnddt.objectmanager.DefaultMethod.TypeOfMethod;
import com.adp.wfnddt.results.jaxb.StatusType;

public class WebRadioButton extends BaseObject {

	public WebRadioButton(String p_selector) {
		setSelector(p_selector);
	}

	public WebRadioButton(WebElement p_object) {
		setObject(p_object);
	}

	@Step(Params = { "Value", "Mapped value" })
	@DefaultMethod(MethodType = TypeOfMethod.Action)
	public void click(String p_value, String p_mappedValue) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		if (!p_value.trim().equalsIgnoreCase(p_mappedValue.trim()))
			return;

		clickOnObject(ClickType.Simple);
		return;
	}

	@Step(Params = { "Value", "Mapped value", "Type of Click" })
	public void click(String p_value, String p_mappedValue, ClickType p_typeOfClick) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		if (!p_value.trim().equalsIgnoreCase(p_mappedValue.trim()))
			return;

		clickOnObject(p_typeOfClick);
		return;
	}

	@DefaultMethod(MethodType = TypeOfMethod.Verification)
	public void verifyValue(String p_value, String p_mappedValue) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		if (!p_value.trim().equalsIgnoreCase(p_mappedValue.trim()))
			return;
		findObject();
		StatusType status = StatusType.PASSED;
		String onValue = "", onValueDisabled = "";

		// Return if not displayed
		if (!getObject().isDisplayed() && Integer.parseInt(getObject().getAttribute("clientHeight")) < 1) {
			m_results.addEntryToVerificationLog("Verify value for : " + getClass().getSimpleName() + "(\"" + m_objectName + "\")", status, onValue, "[OBJECT_NOT_VISIBLE]");
			return;
		}

		String actualValue = "";

		if (getObject().getAttribute("class").equalsIgnoreCase("fa fa-circle radioButtonIcon")) {
			onValue = "color: rgb(14, 80, 97)";
			onValueDisabled = "color: rgb(106, 106, 106)";
			actualValue = getObject().getAttribute("style");
			if (actualValue.contains(onValue) || actualValue.contains(onValueDisabled))
				actualValue = "ON";
			else
				actualValue = "OFF";
		} else if (getObject().findElements(By.xpath(".//input")).size() != 0) {
			onValue = "ON";
			actualValue = getObject().findElement(By.xpath(".//input")).isSelected() ? "ON" : "OFF";
		} else if (getObject().getAttribute("class").contains("vdl-radio")) {
			onValue = "vdl-radio--checked";
			actualValue = getObject().getAttribute("class");
			if (actualValue.contains(onValue))
				actualValue = "ON";
			else
				actualValue = "OFF";
		} else if (getObject().getAttribute("class").contains("revitRadioButton")) {
			onValue = "dijitRadioChecked";
			actualValue = getObject().getAttribute("class");
			if (actualValue.contains(onValue))
				actualValue = "ON";
			else
				actualValue = "OFF";
		} else if (getObject().getAttribute("type").equalsIgnoreCase("radio")) {
			onValue = "true";
			actualValue = getObject().getAttribute("aria-checked");
			if (actualValue.equalsIgnoreCase(onValue))
				actualValue = "ON";
			else
				actualValue = "OFF";
		}

		String expectedValue = p_value.trim().equalsIgnoreCase("OFF") ? "OFF" : "ON"; //Added in case of non-OFF/ON value passed in. Like Yes or No for p_value
		if (actualValue.equalsIgnoreCase(expectedValue))
			status = StatusType.PASSED;
		else
			status = StatusType.FAILED;
		m_results.addEntryToVerificationLog("Verify value for : " + getClass().getSimpleName() + "(\"" + m_objectName + "\")", status, expectedValue, actualValue);
		return;
	}
	
	public void verifyValue(String p_value) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		if (p_value.trim().contentEquals(""))
			return;
		verifyValue(p_value, p_value);
	}
	
	public void verifyObjectProperties(String p_property) throws DDTFrameworkException, DatatypeConfigurationException, IOException {
		if (exists()) {
			if (p_property.equalsIgnoreCase("[DISABLED]") || p_property.equalsIgnoreCase("[ENABLED]")) {
				if ((getObject().getAttribute("class").contains("vdl-radio")) && (getObject().findElements(By.xpath(".//label[starts-with(@for,'radio_')]")).size() > 0)) {
					verifyObjectProperties(p_property, VerifyPropertyType.DISABLED_ariaDisabled, getObject().findElement(By.cssSelector("input")));
				} else {
					super.verifyObjectProperties(p_property);
				}
			} else {
				super.verifyObjectProperties(p_property);
			}
		} else {
			super.verifyObjectProperties(p_property);
		}
	}
}

package com.adp.wfnddt.objectmanager.extendedobjects;

import com.adp.wfnddt.objectmanager.WebLink;

public class PreviewIcon extends WebLink {
	public PreviewIcon() {
		super("CSS:span.fa.fa-eye");
	}
}

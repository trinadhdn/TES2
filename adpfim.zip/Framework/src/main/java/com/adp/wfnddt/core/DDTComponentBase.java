/**
 * 
 */
package com.adp.wfnddt.core;

import com.adp.wfnddt.objectmanager.ObjectManager;
import com.adp.wfnddt.results.DDTResultsReporter;

/**
 * @author autoxpert
 *
 */
public abstract class DDTComponentBase {
	protected ObjectManager Browser = new ObjectManager();
	protected DDTResultsReporter ResultsReporter = DDTController.getResultsReporter();

	protected void loadObjectRepository(String p_OR_Path) throws DDTFrameworkException {
		String compProject = "";
		if (super.getClass().getPackage().getName().split("\\.").length > 4)
			compProject = "COMPONENT_" + super.getClass().getPackage().getName().split("\\.")[4].toUpperCase();
		Browser.initialize(p_OR_Path, compProject);
		return;
	}
}

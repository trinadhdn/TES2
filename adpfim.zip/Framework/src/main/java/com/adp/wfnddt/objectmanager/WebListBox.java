package com.adp.wfnddt.objectmanager;

import org.openqa.selenium.*;

import com.adp.wfnddt.aspects.Step;
import com.adp.wfnddt.core.DDTController;
import com.adp.wfnddt.core.DDTFrameworkException;
import com.adp.wfnddt.objectmanager.DefaultMethod.TypeOfMethod;
import com.adp.wfnddt.results.DDTResultsReporter;
import com.adp.wfnddt.results.jaxb.StatusType;

import static org.assertj.core.api.Assertions.*;

import java.io.IOException;
import java.util.List;

import javax.xml.datatype.DatatypeConfigurationException;

public class WebListBox extends BaseObject {

	public WebListBox(String p_selector) {
		setSelector(p_selector);
	}

	public WebListBox(WebElement p_object) {
		setObject(p_object);
	}

	@Step(Params = { "Value(s) to select", "UpDown", "Number of Clicks" })
	@DefaultMethod(MethodType = TypeOfMethod.Action)
	public void moveValues(String p_value, String p_upDown, String p_numClicks) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		if (p_value.trim().contentEquals(""))
			return;

		findObject();
		waitForClickable();

		// Configure the move left/right buttons
		WebElement upDownObj = null;

		switch (p_upDown) {
		case "UP":
			upDownObj = getObject().findElement(By.xpath(".//span[contains(@class,'revitButton') and @title='Sort Selected Up']"));
			break;
		case "DOWN":
			upDownObj = getObject().findElement(By.xpath(".//span[contains(@class,'revitButton') and @title='Sort Selected Down']"));
			break;
		default:
			fail("The updown value [" + p_upDown + "] is not valid. Expected UP or DOWN");
			break;
		}

		String[] inputItems = p_value.split(";");
		for (int i = 0; i < inputItems.length; i++) {
			WebElement option = getObject().findElement(By.xpath(".//li[contains(text(),'" + inputItems[i] + "')]"));
			if (option != null) {
				option.click();
				for (int j = 1; j <= Integer.parseInt(p_numClicks); j++) {
					upDownObj.click();
				}
			} else {
				fail("The value [" + inputItems[i] + "] is not found in the ListBox");
				return;
			}
		}

		return;
	}

	@DefaultMethod(MethodType = TypeOfMethod.Verification)
	public void verifyValue(String p_value) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		DDTResultsReporter results = DDTController.getResultsReporter();

		if (p_value.trim().contentEquals(""))
			return;

		findObject();
		
		String strActual = getActualValue();

		if (p_value.trim().contentEquals(strActual)) {
			results.addEntryToVerificationLog("Verify value for : " + getClass().getSimpleName() + "(\"" + m_objectName + "\") - ", StatusType.PASSED, p_value, strActual);
		} else {
			results.addEntryToVerificationLog("Verify value for : " + getClass().getSimpleName() + "(\"" + m_objectName + "\") - ", StatusType.FAILED, p_value, strActual);
		}
		return;
	}
	
	public String getActualValue() throws IOException, DatatypeConfigurationException, DDTFrameworkException{
		WebElement boxElem = null;
		boxElem = getObject().findElement(By.xpath("//ul[contains(@id,'_Left') or contains(@class,'left-list')]"));

		String strActual = "";
		List<WebElement> arrItems = boxElem.findElements(By.xpath(".//li"));
		if (arrItems.isEmpty()) {
			strActual = "[BLANK]";
		} else {
			for (WebElement dblListItem : arrItems) {
				strActual = strActual + ";" + dblListItem.getAttribute("innerText");
			}
			strActual = strActual.substring(1);
		}
		return strActual;
	}
}

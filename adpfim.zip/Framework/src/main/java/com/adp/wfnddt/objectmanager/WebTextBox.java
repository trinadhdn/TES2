package com.adp.wfnddt.objectmanager;

import static com.adp.wfnddt.commonmethods.General.performTextComparison;
import static com.adp.wfnddt.commonmethods.General.replaceSpaceKeyWord;
import java.io.IOException;
import javax.xml.datatype.DatatypeConfigurationException;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import com.adp.wfnddt.aspects.Step;
import com.adp.wfnddt.commonmethods.General.ComparisonType;
import com.adp.wfnddt.core.DDTFrameworkException;
import com.adp.wfnddt.objectmanager.DefaultMethod.TypeOfMethod;
import com.adp.wfnddt.results.jaxb.StatusType;

public class WebTextBox extends BaseObject {

	public WebTextBox(String p_selector) {
		setSelector(p_selector);
	}

	public WebTextBox(WebElement p_object) {
		setObject(p_object);
	}

	@Step(Params = { "Value" })
	@DefaultMethod(MethodType = TypeOfMethod.Action)
	public void set(String p_value) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		//Default using tab off to clear text, if textbox having issue use method with extra argument set TabOff to false
		if (p_value.trim().contentEquals("")) return;
		p_value = p_value.trim();
		p_value = replaceSpaceKeyWord(p_value);
		findObject();
		clearText();
		if (!p_value.equalsIgnoreCase("[BLANK]")) {
			getObject().sendKeys(p_value);
			getObject().sendKeys(Keys.TAB);
		} else {
			if (exists()) {
				getObject().click();
			} 
		}
		return;
	}

	//option to clear textbox w/wo using tab key
	public void set(String p_value, Boolean bTabOff) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		if (p_value.trim().contentEquals("")) return;
		p_value = p_value.trim();
		p_value = replaceSpaceKeyWord(p_value);
		findObject();
		clearText();
		
		if (bTabOff) getObject().sendKeys(Keys.TAB);
		
		if (!p_value.equalsIgnoreCase("[BLANK]")) {
			getObject().sendKeys(p_value);
			if (bTabOff) getObject().sendKeys(Keys.TAB);
		}
		return;
	}
	
	public void set(Keys p_value) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		if (p_value == null)
			return;
		findObject();
		getObject().click();
		switch (p_value) {
		case TAB:
			getObject().sendKeys(Keys.TAB);
			break;
		case ENTER:
			getObject().sendKeys(Keys.ENTER);
			break;
		default:
			break;
		}
		return;
	}
	
	//Add to support textbox become disabled after text entered
	public void justEnterText(String p_value) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		if (p_value == null)
			return;
		findObject();
		getObject().click();
		getObject().sendKeys(p_value);
		return;
	}

	@DefaultMethod(MethodType = TypeOfMethod.Verification)
	public void verifyValue(String p_value) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		verifyValue(p_value, new ComparisonType[] { ComparisonType.Exact });
	}

	public void verifyValue(String p_value, ComparisonType[] p_comparisonTypes) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		if (p_value.trim().contentEquals(""))
			return;

		findObject();

		String expectedValue = p_value.trim();
		expectedValue = replaceSpaceKeyWord(p_value);
		// Return if not displayed
		if (!getObject().isDisplayed()) {
			m_results.addEntryToVerificationLog("Verify value for : " + getClass().getSimpleName() + "(\"" + m_objectName + "\")", StatusType.FAILED, expectedValue, "[OBJECT_NOT_VISIBLE]");
			return;
		}

		String actualValue = getActualValue();

		// Compare
		StatusType status = performTextComparison(expectedValue, actualValue, p_comparisonTypes);

		m_results.addEntryToVerificationLog("Verify value for : " + getClass().getSimpleName() + "(\"" + m_objectName + "\")", status, expectedValue, actualValue);

		return;
	}
	
	public String getActualValue() throws IOException, DatatypeConfigurationException, DDTFrameworkException{
		String actualValue = getObject().getText().trim();

		if (actualValue.contentEquals("")) {
			actualValue = getObject().getAttribute("value").trim();
		}

		if (actualValue.contentEquals("")) {
			actualValue = "[BLANK]";
		}
		
		return actualValue;
	}

	public void verifyObjectProperties(String p_property) throws DDTFrameworkException, DatatypeConfigurationException, IOException {
		if (exists()) {
			if (getObject().getAttribute("class").contains("reactTextBox") && (p_property.equalsIgnoreCase("[DISABLED]") || p_property.equalsIgnoreCase("[ENABLED]"))) {
				verifyObjectProperties(p_property, VerifyPropertyType.DISABLED_classDisabled, getObject());
			} else {
				super.verifyObjectProperties(p_property);
			}
		} else {
			super.verifyObjectProperties(p_property);
		}
	}

}

package com.adp.wfnddt.objectmanager;

import static com.adp.wfnddt.commonmethods.General.performTextComparison;

import java.io.IOException;

import javax.xml.datatype.DatatypeConfigurationException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.adp.wfnddt.aspects.Step;
import com.adp.wfnddt.commonmethods.General.ComparisonType;
import com.adp.wfnddt.core.DDTFrameworkException;
import com.adp.wfnddt.objectmanager.DefaultMethod.TypeOfMethod;
import com.adp.wfnddt.results.jaxb.StatusType;

public class WebToggleButton extends BaseObject {

	public WebToggleButton(String p_selector) {
		setSelector(p_selector);
	}

	public WebToggleButton(WebElement p_object) {
		setObject(p_object);
	}

	public void set(String p_inputValue, String p_value, String p_mappedValue) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		if (!p_inputValue.trim().equalsIgnoreCase(p_value.trim())) return;

		set(p_mappedValue);
		return;
	}
	
	@Step(Params = { "Value" })
	@DefaultMethod(MethodType = TypeOfMethod.Action)
	public void set(String p_value) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		if (p_value.trim().contentEquals(""))
			return;

		findObject();
		waitForPresense();

		String className = getObject().getAttribute("class").toUpperCase();

		if (!className.contentEquals("")) {
			p_value = p_value.trim().toUpperCase();

			// MDF6: LEFT/RIGHT
			if (className.contains("VDL-TOGGLE-SWITCH")) {
				String sSide = "LEFT";
				if (className.contains("VDL-TOGGLE-SWITCH--CHECKED")) {
					sSide = "RIGHT";
				}
				if (!p_value.toUpperCase().equals(sSide)) {
					getObject().click();
				}
			//React Toggle button
			} else if(className.contains("reactVDL toggleButton")){
				String sSide = "LEFT";
				if (className.contains("floatRight")) {
					sSide = "RIGHT";
				}
				if (!p_value.toUpperCase().equals(sSide)) {
					getObject().click();
				}	
			}
			else {

				if (!className.contains(p_value))
					getObject().click();
			}
		} else {
			String currentState = getObject().findElement(By.xpath(".//div[contains(@style,'16px')]/parent::td")).getAttribute("align").toUpperCase();
			p_value = p_value.trim().toUpperCase();
			if (!currentState.contains(p_value))
				getObject().findElement(By.xpath(".//div[contains(@style,'16px')]")).click();
		}

		return;
	}

	@DefaultMethod(MethodType = TypeOfMethod.Verification)
	public void verifyValue(String p_value) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		verifyValue(p_value, new ComparisonType[] { ComparisonType.Partial });
	}

	public void verifyValue(String p_value, ComparisonType[] p_comparisonTypes) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		if (p_value.trim().contentEquals(""))
			return;

		findObject();
		waitForPresense();

		String expectedValue = p_value.trim().toUpperCase();

		// Return if not displayed
		if (!getObject().isDisplayed()) {
			m_results.addEntryToVerificationLog("Verify value for : " + getClass().getSimpleName() + "(\"" + m_objectName + "\")", StatusType.FAILED, expectedValue, "[OBJECT_NOT_VISIBLE]");
			return;
		}

		String actualValue = getActualValue();

		// Compare
		StatusType status = performTextComparison(expectedValue, actualValue, p_comparisonTypes);

		m_results.addEntryToVerificationLog("Verify value for : " + getClass().getSimpleName() + "(\"" + m_objectName + "\")", status, expectedValue, actualValue);

		return;
	}

	public String getActualValue() throws IOException, DatatypeConfigurationException, DDTFrameworkException{
		String actualValue = getObject().getAttribute("class").toUpperCase();

		// MDF6 toggle switch
		if (actualValue.contains("VDL-TOGGLE-SWITCH")) {
			if (actualValue.contains("VDL-TOGGLE-SWITCH--CHECKED")) {
				actualValue = "RIGHT";
			} else {
				actualValue = "LEFT";
			}
		}
		
		//React toggle button
		if (actualValue.contains("REACTVDL TOGGLEBUTTON")) {
			if (actualValue.contains("FLOATRIGHT")) {
				actualValue = "RIGHT";
			} else {
				actualValue = "LEFT";
			}
		}
		
		return actualValue;
	}
	
	public void verifyObjectProperties(String p_property) throws DDTFrameworkException, DatatypeConfigurationException, IOException {

		if (exists()) {
			if (getObject().getAttribute("class").contains("toggleButtonNob") && (p_property.equalsIgnoreCase("[DISABLED]") || p_property.equalsIgnoreCase("[ENABLED]"))) {
				verifyObjectProperties(p_property, VerifyPropertyType.DISABLED_classDisableComponent, getObject().findElement(By.xpath("./parent::DIV")));
			} else if (getObject().getAttribute("id").contains("StatusToggle.node") && (p_property.equalsIgnoreCase("[DISABLED]") || p_property.equalsIgnoreCase("[ENABLED]"))) {
				verifyObjectProperties(p_property, VerifyPropertyType.DISABLED_styleopacity04, getObject().findElement(By.xpath("./child::table")));
			} else {
				super.verifyObjectProperties(p_property);
			}
		} else {
			super.verifyObjectProperties(p_property);
		}
	}
}

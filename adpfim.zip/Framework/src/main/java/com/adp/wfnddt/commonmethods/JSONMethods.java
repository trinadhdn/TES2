package com.adp.wfnddt.commonmethods;

import static org.skyscreamer.jsonassert.JSONCompareMode.LENIENT;
import static org.skyscreamer.jsonassert.JSONCompareMode.STRICT;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Scanner;

import javax.xml.datatype.DatatypeConfigurationException;

import org.apache.log4j.Logger;
import org.everit.json.schema.Schema;
import org.everit.json.schema.ValidationException;
import org.everit.json.schema.loader.SchemaLoader;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONString;
import org.json.JSONTokener;
import org.skyscreamer.jsonassert.FieldComparisonFailure;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.skyscreamer.jsonassert.JSONCompareResult;
import org.skyscreamer.jsonassert.JSONParser;
import org.skyscreamer.jsonassert.comparator.DefaultComparator;
import org.skyscreamer.jsonassert.comparator.JSONComparator;
import com.adp.wfnddt.core.DDTController;
import com.adp.wfnddt.core.DDTFrameworkException;
import com.adp.wfnddt.core.DDTLoggerManager;
import com.adp.wfnddt.core.GlobalVariables;
import com.adp.wfnddt.results.DDTResultsReporter;
import com.adp.wfnddt.results.jaxb.StatusType;
import com.adp.wfnddt.webapi.rest.TestRestAPI;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.jayway.restassured.path.json.JsonPath;

public class JSONMethods {
	private static Logger m_logger = DDTLoggerManager.getLogger(JSONMethods.class);
	private DDTResultsReporter m_results = DDTController.getResultsReporter();

	private JSONMethods() {
	}

	private static JSONComparator getComparatorForMode(JSONCompareMode mode) {
		return new DefaultComparator(mode);
	}

	public static JSONCompareResult compareJSONStr(String expectedStr, String actualStr, JSONComparator comparator) throws JSONException {
		Object expected = JSONParser.parseJSON(expectedStr);
		Object actual = JSONParser.parseJSON(actualStr);
		if ((expected instanceof JSONObject) && (actual instanceof JSONObject)) {
			return compareJSONObject((JSONObject) expected, (JSONObject) actual, comparator);
		} else if ((expected instanceof JSONArray) && (actual instanceof JSONArray)) {
			return compareJSONArray((JSONArray) expected, (JSONArray) actual, comparator);
		} else if (expected instanceof JSONString && actual instanceof JSONString) {
			return compareJSONString((JSONString) expected, (JSONString) actual);
		} else if (expected instanceof JSONObject) {
			return new JSONCompareResult().fail("", expected, actual);
		} else {
			return new JSONCompareResult().fail("", expected, actual);
		}
	}

	public static JSONCompareResult compareJSONObject(JSONObject expected, JSONObject actual, JSONComparator comparator) throws JSONException {
		return comparator.compareJSON(expected, actual);
	}

	public static JSONCompareResult compareJSONArray(JSONArray expected, JSONArray actual, JSONComparator comparator) throws JSONException {
		return comparator.compareJSON(expected, actual);
	}

	public static JSONCompareResult compareJSONString(final JSONString expected, final JSONString actual) {
		final JSONCompareResult result = new JSONCompareResult();
		final String expectedJson = expected.toJSONString();
		final String actualJson = actual.toJSONString();
		if (!expectedJson.equals(actualJson)) {
			result.fail("");
		}
		return result;
	}

	public static JSONCompareResult compareJSONString(String expectedStr, String actualStr, JSONCompareMode mode) throws JSONException {
		return compareJSONStr(expectedStr, actualStr, getComparatorForMode(mode));
	}

	public static JSONCompareResult compareJSONObject(JSONObject expected, JSONObject actual, JSONCompareMode mode) throws JSONException {
		return compareJSONObject(expected, actual, getComparatorForMode(mode));
	}

	public static JSONCompareResult compareJSONArray(JSONArray expected, JSONArray actual, JSONCompareMode mode) throws JSONException {
		return compareJSONArray(expected, actual, getComparatorForMode(mode));
	}
	
	public static JSONCompareResult validateJSONFileSchema(String retValue, String clientPostResponse) throws JSONException, DDTFrameworkException {
		return validateJSONSchema(retValue, clientPostResponse);
	}

	// JE - Added below functions for components only. Above functions for framework use

	/**
	 * Compares 2 JSON files. Just provide the base and actual json file locations in the parameters and the HTML report will show the differences if any. Use < IGNORE > to ignore some values (Note that < IGNORE > causes the search to be split into sections)
	 * 
	 * @param p_JSONBaseLocation
	 *            Base File location of Eclipse resource (i.e. /Objects/JSON/MyJSON.json)
	 * @param p_JSONActualLocation
	 *            Actual File location as an Eclipse resource (i.e. /Objects/JSON/MyJSON.json)
	 * @return N/A
	 * @throws DDTFrameworkException
	 */

	public void compareJSONFiles(String p_JSONBaseLocation, String p_JSONActualLocation) throws DDTFrameworkException {
		Scanner scannerBase = null;
		Scanner scannerActual = null;
		String jsonBase = "";
		String jsonActual = "";
		Boolean blnPassed = false;
		try {
			m_logger.debug("Reading Files Now...");
			scannerBase = new Scanner(new BufferedReader(new InputStreamReader(getClass().getResourceAsStream(p_JSONBaseLocation), "ISO-8859-1")));
			scannerActual = new Scanner(new BufferedReader(new InputStreamReader(getClass().getResourceAsStream(p_JSONActualLocation), "ISO-8859-1")));

			scannerBase.useDelimiter("\\Z");
			scannerActual.useDelimiter("\\Z");
			jsonBase = scannerBase.next();
			jsonActual = scannerActual.next();
			scannerBase.close();
			scannerActual.close();

			// Compare Files Completely
			m_logger.debug("Comparing Full JSON Data...");
			m_results.addTestStep("COMPARE JSON DATA");
			m_results.startVerificationLogStep();
			String[] arrExpResponses = jsonBase.split("<IGNORE>");
			for (String strExpResponse : arrExpResponses) {
				if (jsonActual.contains(strExpResponse)) {
					blnPassed = true;
				} else {
					blnPassed = false;
					break;
				}
			}
			if (blnPassed) {
				m_results.addEntryToVerificationLog("Verification of Compare JSON File", StatusType.PASSED, jsonBase, jsonActual);
				m_results.endVerificationLogStep(StatusType.PASSED);
				m_results.endTestStep(StatusType.PASSED);
			} else {
				m_results.addEntryToVerificationLog("Verification of Compare JSON File", StatusType.FAILED, jsonBase, jsonActual);
				m_results.endVerificationLogStep(StatusType.FAILED);
				m_results.endTestStep(StatusType.FAILED);
			}
			return;
		} catch (Exception ex) {
			throw new DDTFrameworkException(JSONMethods.class, "An unexpected error occurred while invoking compareJSONFiles.", ex);
		}
	}

	/**
	 * Compares 2 JSON file by individual object types. Just provide the base and actual json file locations in the parameters and the HTML report will show the differences if any
	 * 
	 * @param p_JSONBaseLocation
	 *            Base File location of Eclipse resource (i.e. /Objects/JSON/MyJSON.json)
	 * @param p_JSONActualLocation
	 *            Actual File location as an Eclipse resource (i.e. /Objects/JSON/MyJSON.json)
	 * @param p_CompareType
	 *            a string of either "LENIENT" or "STRICT"
	 * @return N/A
	 * @throws DDTFrameworkException
	 */

	public void compareJSONEntities(String p_JSONBaseLocation, String p_JSONActualLocation, String p_CompareType) throws DDTFrameworkException {
		Scanner scannerBase = null;
		Scanner scannerActual = null;
		String jsonBase = "";
		String jsonActual = "";
		DefaultComparator jsonComparator;
		try {
			scannerBase = new Scanner(new BufferedReader(new InputStreamReader(getClass().getResourceAsStream(p_JSONBaseLocation), "ISO-8859-1")));
			scannerActual = new Scanner(new BufferedReader(new InputStreamReader(getClass().getResourceAsStream(p_JSONActualLocation), "ISO-8859-1")));

			scannerBase.useDelimiter("\\Z");
			scannerActual.useDelimiter("\\Z");
			jsonBase = scannerBase.next();
			jsonActual = scannerActual.next();
			scannerBase.close();
			scannerActual.close();

			// Compare Files Completely
			m_logger.debug("Comparing JSON Data...");
			m_results.addTestStep("COMPARE JSON DATA");
			m_results.startVerificationLogStep();
			switch (p_CompareType) {
			case "LENIENT":
				jsonComparator = new DefaultComparator(LENIENT);
				break;
			default:
				jsonComparator = new DefaultComparator(STRICT);
				break;
			}
			JSONCompareResult resultSet = JSONMethods.compareJSONStr(jsonBase, jsonActual, jsonComparator);
			if (!resultSet.passed()) { // Compare failed
				for (FieldComparisonFailure failedField : resultSet.getFieldFailures()) {
					m_results.addEntryToVerificationLog("Failure On: " + failedField.getField(), StatusType.FAILED, failedField.getExpected().toString(), failedField.getActual().toString());
				}
				for (FieldComparisonFailure failedField : resultSet.getFieldMissing()) {
					m_results.addEntryToVerificationLog("Field Missing On: " + failedField.getField(), StatusType.FAILED, failedField.getExpected().toString(), failedField.getActual().toString());
				}
				for (FieldComparisonFailure failedField : resultSet.getFieldUnexpected()) {
					m_results.addEntryToVerificationLog("Unexpected Failure On: " + failedField.getField(), StatusType.FAILED, failedField.getExpected().toString(), failedField.getActual().toString());
				}
				m_results.addEntryToVerificationLog("Verification of Compare JSON Entities", StatusType.FAILED, jsonBase, jsonActual);
				m_results.endVerificationLogStep(StatusType.FAILED);
				m_results.endTestStep(StatusType.FAILED);
			} else {
				m_results.addEntryToVerificationLog("Verification of Compare JSON Entities", StatusType.PASSED, jsonBase, jsonActual);
				m_results.endVerificationLogStep(StatusType.PASSED);
				m_results.endTestStep(StatusType.PASSED);
			}
			return;
		} catch (Exception ex) {
			throw new DDTFrameworkException(TestRestAPI.class, "An unexpected error occurred while invoking compareJSONEntities.", ex);
		}
	}

	/**
	 * Returns the JSON Object value of the JSON key
	 * 
	 * @param p_JSONText
	 *            JSON Body/Text
	 * @param p_JSONKey
	 *            Key value to retrieve in GPATH format like "emps.employee[0].'Position ID'"
	 * @return String
	 * @throws DDTFrameworkException
	 */

	public static String getJSONObjectValue(String p_JSONText, String p_JSONKey) throws DDTFrameworkException {
		return JsonPath.from(p_JSONText).get(p_JSONKey).toString();
	}


	/**
	 * Compares 2 JSON files. Just provide the base and actual schema json file locations in the parameters and the HTML report will show the differences if any. Use < IGNORE > to ignore some values (Note that < IGNORE > causes the search to be split into sections)
	 * 
	 * @param p_JSONSchemaBaseLocation
	 *            Base File location of Eclipse resource (i.e. /Objects/JSON/MySchemaJSON.json)
	 * @param clientPostResponse
	 *            Actual File location as an Eclipse resource (i.e. /Objects/JSON/MyJSON.json)
	 * @return JSONCompareResult
	 * @throws DDTFrameworkException
	 * @throws JSONException 
	 */
	public static JSONCompareResult validateJSONSchema(String p_JSONSchemaBaseLocation, String clientPostResponse) throws DDTFrameworkException, JSONException {
			final JSONCompareResult valid = new JSONCompareResult();
		
			try{
		   
		    	JSONObject jsonSubject = new JSONObject(new JSONTokener(clientPostResponse));;
		    	JSONObject schemaObject = new JSONObject((p_JSONSchemaBaseLocation));
		    	Schema schema = SchemaLoader.load(schemaObject);
		    	schema.validate((jsonSubject));	
		    	
		    	return valid;
		    }catch (ValidationException  e) {
		    	valid.fail(e.getMessage());
		    	return valid;
			}			
	}

public static String getJSONData(String p_variableName) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		JsonObject jsonObjects;
		BufferedReader buffRdr;

		InputStream in = JSONMethods.class.getResourceAsStream("/JSONDATA/" + GlobalVariables.getVariable("JSONDATAFILE") + ".json");
		buffRdr = new BufferedReader(new InputStreamReader(in));
		JsonParser parser = new JsonParser();
		jsonObjects = parser.parse(buffRdr).getAsJsonObject();
		JsonArray jsonArray = jsonObjects.get("JSONDATA").getAsJsonArray();
		int iPodCnt = jsonArray.size();
		String jsonParamVal = "";

		for (int iIdx = 0; iIdx < iPodCnt; iIdx++) {
			JsonObject EnvInfo = jsonArray.get(iIdx).getAsJsonObject();
			String ENV = EnvInfo.get("ENV").getAsString();

			if (ENV.equalsIgnoreCase(DDTController.getWfnEnvironment())) {
				jsonParamVal = EnvInfo.get(p_variableName).getAsString();
				break;
			}
		}

		return jsonParamVal;
	}
	
}

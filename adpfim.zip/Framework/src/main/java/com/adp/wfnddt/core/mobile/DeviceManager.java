/**
 * 
 */
package com.adp.wfnddt.core.mobile;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.MalformedURLException;
import java.net.Proxy;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSession;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.HttpCommandExecutor;
import org.openqa.selenium.remote.http.HttpClient;
import org.openqa.selenium.remote.http.HttpClient.Factory;
import org.openqa.selenium.remote.internal.OkHttpClient;

import com.adp.wfnddt.core.DDTController;
import com.adp.wfnddt.core.DDTController.Mobile_BrowserType;
import com.adp.wfnddt.core.DDTController.Mobile_OSName;
import com.adp.wfnddt.core.DDTFrameworkException;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileCommand;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.remote.IOSMobileCapabilityType;
import io.appium.java_client.remote.MobileBrowserType;
import okhttp3.Authenticator;
import okhttp3.Credentials;
import okhttp3.OkHttpClient.Builder;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.Route;

/**
 * @author autoxpert
 *
 */
public class DeviceManager {
	private static AppiumDriver<WebElement> driver;
	private static String AppiumServer;

	// Proxy host/port and authentication
	private static final String proxy_host = "11.164.4.21";
	private static final String proxy_port = "8080";
	private static final String proxy_user = "autoxpert";
	private static final String proxy_password = "adpadp";

	// Android Emulators
	private static String Appium_AndoirdEmulator = "http://hyrdwsz0057:4723/wd/hub";

	// Experitest
	private static boolean isExperitest = DDTController.isExperitest();
	private static String Appium_ExperitestDemoCloud = DDTController.getAppiumRemoteURL();
	private static String Experitest_AccessKey = "eyJ4cC51Ijo2LCJ4cC5wIjoyLCJ4cC5tIjoiTVRVME56Y3dOekl4TlRnek53IiwiYWxnIjoiSFMyNTYifQ.eyJleHAiOjE4NjMwNjcyMTYsImlzcyI6ImNvbS5leHBlcml0ZXN0In0.TwAwE9IPg-PXy0fxyxGOzlpNuCN2JG3TYHWc5Cqks08";
	
	//Perfecto
	private static boolean isPerfecto = DDTController.isPerfecto();
	private static String Appium_PerfectoCloud = DDTController.getAppiumRemoteURL();
	private static String Perfecto_SecurityToken = "eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICJQWURISDhDekZwQ2REWmVJWmlLeHVSMmQ4WGIzOXJQcC1ibzhSVVctSXVNIn0.eyJqdGkiOiJkNzZmZjUxNi1jODhhLTQ2YzctODAwMS0wM2EyYTIwNmU4ODMiLCJleHAiOjAsIm5iZiI6MCwiaWF0IjoxNTY5ODMxNDk4LCJpc3MiOiJodHRwczovL2F1dGgucGVyZmVjdG9tb2JpbGUuY29tL2F1dGgvcmVhbG1zL2FkcC1wZXJmZWN0b21vYmlsZS1jb20iLCJhdWQiOiJvZmZsaW5lLXRva2VuLWdlbmVyYXRvciIsInN1YiI6IjhiMGY3NDA1LWE1NGUtNGZmMy1hNGY3LTYyYjExNWU3YzljNiIsInR5cCI6Ik9mZmxpbmUiLCJhenAiOiJvZmZsaW5lLXRva2VuLWdlbmVyYXRvciIsIm5vbmNlIjoiZmFlZWNjNTYtMjc5MC00ZmU1LThiN2QtYjcxODBmNmFkN2M5IiwiYXV0aF90aW1lIjowLCJzZXNzaW9uX3N0YXRlIjoiOGM5ODQ5OGEtNTcxOC00NmQzLWJkN2ItOGViODMyNGJmYzA0IiwicmVhbG1fYWNjZXNzIjp7InJvbGVzIjpbIm9mZmxpbmVfYWNjZXNzIiwidW1hX2F1dGhvcml6YXRpb24iXX0sInJlc291cmNlX2FjY2VzcyI6eyJhY2NvdW50Ijp7InJvbGVzIjpbIm1hbmFnZS1hY2NvdW50IiwibWFuYWdlLWFjY291bnQtbGlua3MiLCJ2aWV3LXByb2ZpbGUiXX19fQ.H0tMocSZgfvMB7mEi8P_OxD4LrnQ46ZLsri8UcWMSbdEJOdGSDW7PzHJqAD2py_9Zx9sU1fRpn1hO12avk9HMzcmEiwc1koPg7HTPkeS-VMjr0bUF4wVWaxX9SM2LKHwqmheNZ4gHFLTN1MVBteOmOTvNPGYhGvW91i6rbix8rbAdtdHjrOcvOuoIQ_16j-ewkmFq82ZU15HhOKU8IvFzuFXIZ1roGAfKSIqugO84rgY1UqF_FhTiahIpIurZ627Z5kMFEewHdDREhT80dbAL5bXnMFS1od1Zr-8GXI4SZxs6wuolXnaw1Ge-dpGqFjSuoBky8mcMl2n_fa_nfEWig";

	
	public static AppiumDriver<WebElement> setupAppiumDriver() throws DDTFrameworkException, MalformedURLException {
		long lMaxWait = DDTController.getMaxWaitTime();

		/*
		System.getProperties().put("http.proxyHost", proxy_host);
		System.getProperties().put("http.proxyPort", proxy_port);
		System.getProperties().put("https.proxyHost", proxy_host);
		System.getProperties().put("https.proxyPort", proxy_port);

		System.getProperties().put("http.proxyUser", proxy_user);
		System.getProperties().put("http.proxyPassword", proxy_password);
		System.getProperties().put("https.proxyUser", proxy_user);
		System.getProperties().put("https.proxyPassword", proxy_password);
		*/

		// Set the Desired Capabilities
		DesiredCapabilities caps = new DesiredCapabilities();

		switch (DDTController.getMobileDeviceConfig()) {
		case "Pixel-Nougat":
			caps.setCapability("deviceName", "ADP Mobile");
			caps.setCapability("udid", "emulator-5554");
			caps.setCapability("platformName", DDTController.getMobileOSName().toString());
			caps.setCapability("platformVersion", "7.1.1");
			caps.setCapability("newCommandTimeout", 300);

			AppiumServer = Appium_AndoirdEmulator;
			break;

		case "Nexus-Oreo":
			caps.setCapability("deviceName", "ADP Mobile");
			caps.setCapability("udid", "emulator-5556");
			caps.setCapability("platformName", DDTController.getMobileOSName().toString());
			caps.setCapability("platformVersion", "8.0.0");
			caps.setCapability("newCommandTimeout", 300);

			AppiumServer = Appium_AndoirdEmulator;
			break;

		case "Nexus-P":
			caps.setCapability("deviceName", "ADP Mobile");
			caps.setCapability("udid", "emulator-5558");
			caps.setCapability("platformName", DDTController.getMobileOSName().toString());
			caps.setCapability("platformVersion", "P");
			caps.setCapability("newCommandTimeout", 300);

			AppiumServer = Appium_AndoirdEmulator;
			break;

		case "NexusTab-Oreo":
			caps.setCapability("deviceName", "ADP Mobile");
			caps.setCapability("udid", "emulator-5560");
			caps.setCapability("platformName", DDTController.getMobileOSName().toString());
			caps.setCapability("platformVersion", "8.0.0");
			caps.setCapability("newCommandTimeout", 300);

			AppiumServer = Appium_AndoirdEmulator;
			break;

		case "Experitest-Galaxy S8":
			caps.setCapability("testName", "Experitest Demo - Galaxy S8");
			caps.setCapability("accessKey", Experitest_AccessKey);
			caps.setCapability("deviceQuery", "@os='android' and @category='PHONE' and @model='SM-G950F'");
			caps.setCapability("newCommandTimeout", 300);

			DDTController.setMobileOSName(Mobile_OSName.Android);
			AppiumServer = Appium_ExperitestDemoCloud;
			lMaxWait = 150;
			break;

		case "Experitest-Galaxy S7":
			caps.setCapability("testName", "Experitest Demo - Galaxy S7");
			caps.setCapability("accessKey", Experitest_AccessKey);
			caps.setCapability("deviceQuery", "@os='android' and @category='PHONE' and @model='SM-G930F'");
			caps.setCapability("newCommandTimeout", 300);

			DDTController.setMobileOSName(Mobile_OSName.Android);
			AppiumServer = Appium_ExperitestDemoCloud;
			lMaxWait = 150;
			break;
			
		case "Experitest-iPad 4":
			caps.setCapability("testName", "Experitest Demo - iPad 4");
			caps.setCapability("accessKey", Experitest_AccessKey);
			caps.setCapability("deviceQuery", "@os='ios' and @category='TABLET'");
			caps.setCapability("newCommandTimeout", 300);

			DDTController.setMobileOSName(Mobile_OSName.iOS);
			AppiumServer = Appium_ExperitestDemoCloud;
			lMaxWait = 150;
			break;
			
		case "Perfecto-Galaxy S10":
			caps.setCapability("automationName", "Appium");
			caps.setCapability("securityToken", Perfecto_SecurityToken);
			caps.setCapability("udid", "R38M206BBWZ");
			caps.setCapability("platformName", DDTController.getMobileOSName().toString());
			caps.setCapability("newCommandTimeout", 300);
			caps.setCapability("enableAppiumBehavior", true);
			caps.setCapability("useAppiumForWeb", true);

			DDTController.setMobileOSName(Mobile_OSName.Android);
			AppiumServer = Appium_PerfectoCloud;
			lMaxWait = 150;
			break;	
			
		case "Perfecto-iPhone XS":
			DDTController.setMobileOSName(Mobile_OSName.iOS);
			DDTController.setMobileBrowserType(Mobile_BrowserType.Safari);

			caps.setCapability("automationName", "Appium");
			caps.setCapability("securityToken", Perfecto_SecurityToken);
			caps.setCapability("udid", "00008020-000A59582650003A");
			caps.setCapability("platformName", DDTController.getMobileOSName().toString());
			caps.setCapability("newCommandTimeout", 300);

			AppiumServer = Appium_PerfectoCloud;
			lMaxWait = 150;
			break;				

		case "AWS-iPhone":
			caps.setCapability("testName", "AWS Demo - Samsung Galaxy");
			break;

		default:
			caps.setCapability("deviceName", "ADP Mobile");
			caps.setCapability("udid", "emulator-5556");
			caps.setCapability("platformName", DDTController.getMobileOSName().toString());
			caps.setCapability("platformVersion", "7.1.1");
			caps.setCapability("newCommandTimeout", 300);

			break;
		}

		switch (DDTController.getMobileAccessType()) {
		case ADPMobileApp:
			switch (DDTController.getMobileOSName()) {
			case Android:
				caps.setCapability("appPackage", "com.adpmobile.android");
				caps.setCapability("appActivity", "com.adpmobile.android.ui.AuthAppActivity");
				caps.setCapability("noReset", "true");
				break;
			case iOS:
				caps.setCapability(IOSMobileCapabilityType.BUNDLE_ID, "com.adp.es.mobile.prod.enterprise");
				break;
			}
			break;
		case Browser:
			if (!isExperitest) {
				caps.setCapability("browserName", DDTController.getMobileBrowserType().toString());
			} else {
				switch (DDTController.getMobileDeviceConfig()) {
				case "Experitest-iPad 4":
				case "Perfecto-iPhone XS":
					caps.setBrowserName(MobileBrowserType.SAFARI);
					break;
				default:
					caps.setBrowserName(MobileBrowserType.CHROME);
					break;
				}
			}

			break;
		}

		// Instantiate Appium Driver
		if (DDTController.getMobileOSName() == Mobile_OSName.Android) {
			if (isExperitest || isPerfecto) {
				driver = new AndroidDriver<WebElement>(getProxyHTTPExecutor(new URL(AppiumServer), true), caps);
			} else {
				driver = new AndroidDriver<WebElement>(new URL(AppiumServer), caps);
			}
		} else if (DDTController.getMobileOSName() == Mobile_OSName.iOS) {
			if (isExperitest || isPerfecto) {
				driver = new IOSDriver<WebElement>(getProxyHTTPExecutor(new URL(AppiumServer), true), caps);
			} else {
				driver = new IOSDriver<WebElement>(new URL(AppiumServer), caps);
			}
		}

		DDTController.setWebDriver(driver, lMaxWait);
		DDTController.setMobileDriver(driver, lMaxWait);

		return driver;
	}

	public static void closeApp() {

		if (DDTController.getMobileDriver() != null) {
			DDTController.getMobileDriver().closeApp();
			DDTController.getMobileDriver().quit();
			
			DDTController.setMobileDriver(null, 0);
		}
		
		if (DDTController.getWebDriver() != null) {
			DDTController.getWebDriver().quit();
			DDTController.setWebDriver(null, 0);
		}

		return;
	}
	
	public static HttpCommandExecutor getProxyHTTPExecutor(URL url, boolean useProxy) {

		okhttp3.OkHttpClient.Builder builder = new Builder();
		if(useProxy){
			Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(proxy_host, Integer.parseInt(proxy_port)));
	
			Authenticator proxyAuthenticator = new Authenticator() {
				@Override
				public Request authenticate(Route route, Response response) throws IOException {
					String credential = Credentials.basic(proxy_user, proxy_password);
					return response.request().newBuilder().header("Proxy-Authorization", credential).build();
				}
			};
	
			builder.proxy(proxy);
			builder.proxyAuthenticator(proxyAuthenticator);
		}
		builder.connectTimeout(300, TimeUnit.SECONDS);
		builder.readTimeout(300, TimeUnit.SECONDS);
		builder.hostnameVerifier(new HostnameVerifier() {
	        @Override
	        public boolean verify(String hostname, SSLSession session) {
	            return true;
	        }
	    });

		Factory factory = new Factory() {
			@Override
			public HttpClient createClient(URL url) {
				
				return new OkHttpClient(builder.build(), url);
			}

			@Override
			public void cleanupIdleClients() {
				// TODO Auto-generated method stub
			}

			@Override
			public org.openqa.selenium.remote.http.HttpClient.Builder builder() {
				// TODO Auto-generated method stub
				return null;
			}
		};

		HttpCommandExecutor executor = new HttpCommandExecutor(MobileCommand.commandRepository, url, factory);
		return executor;
	}

	/*
	public static HttpCommandExecutor getProxyHTTPExecutor(URL url) {

		HttpClientBuilder builder = HttpClientBuilder.create();
		HttpHost proxy = new HttpHost(proxy_host, Integer.parseInt(proxy_port));
		CredentialsProvider credsProvider = new BasicCredentialsProvider();
		credsProvider.setCredentials(new AuthScope(proxy_host, Integer.parseInt(proxy_port)),
				new UsernamePasswordCredentials(proxy_user, proxy_password));

		builder.setProxy(proxy);
		builder.setDefaultCredentialsProvider(credsProvider);

		Factory factory = new Factory() {
			@Override
			public HttpClient createClient(URL url) {
				return new ApacheHttpClient(builder.build(), url);
			}

			@Override
			public void cleanupIdleClients() {
				// TODO Auto-generated method stub

			}
		};

		HttpCommandExecutor executor = new HttpCommandExecutor(MobileCommand.commandRepository, url, factory);
		return executor;
	}
	*/
	
}

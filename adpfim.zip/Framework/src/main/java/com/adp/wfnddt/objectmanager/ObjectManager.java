package com.adp.wfnddt.objectmanager;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.Enumeration;

import com.adp.wfnddt.core.DDTFrameworkException;
import com.google.gson.*;


public class ObjectManager {
	private JsonObject objects;

	public void initialize(String p_OR_Path, String compProject) throws DDTFrameworkException{
		BufferedReader br;
		try {
			InputStream in = null;
			
			// Check if there are ORs with the same name across projects
			boolean bMultiple = false;
			Enumeration<URL> resources = getClass().getClassLoader().getResources(p_OR_Path.substring(1));
			while (resources.hasMoreElements()) {
				resources.nextElement();
				if (resources.hasMoreElements())
					bMultiple = true;
			}
			
			if(bMultiple){
				resources = getClass().getClassLoader().getResources(p_OR_Path.substring(1));
				while (resources.hasMoreElements()) {
					URL elem = resources.nextElement();
					System.out.println(elem.getPath());
					if (elem.getPath().toUpperCase().contains(compProject)) {
						in = elem.openStream();
						break;
					}
				}
			} else {
				in = getClass().getResourceAsStream(p_OR_Path);
			}
			
			br = new BufferedReader(new InputStreamReader(in));
			JsonParser parser = new JsonParser();
			objects = parser.parse(br).getAsJsonObject();
		} catch (Exception e) {
			throw new DDTFrameworkException(ObjectManager.class, String.format("Unable to process JSON object file: %1$s", p_OR_Path), e);  
		}
	}

	public ObjectTypes Page(String pageName){
		JsonArray pageArray =  objects.get("Pages").getAsJsonArray();
		ObjectTypes pageobjects = new ObjectTypes();
		int iPageCount =pageArray.size();
		for(int i=0;i<iPageCount;i++){
			if(pageArray.get(i).getAsJsonObject().get("Page Name").getAsString().trim().contentEquals(pageName.trim())){
				JsonArray pageObjectsJSON = pageArray.get(i).getAsJsonObject().get("Data").getAsJsonArray();
				pageobjects.setPage(pageObjectsJSON);
				return pageobjects;
			}
		}
		return pageobjects;
	}
}

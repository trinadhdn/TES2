package com.adp.wfnddt.webapi.rest;

import static org.skyscreamer.jsonassert.JSONCompareMode.LENIENT;
import static org.skyscreamer.jsonassert.JSONCompareMode.STRICT;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.KeyStore;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.ws.rs.core.Form;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;
import javax.xml.datatype.DatatypeConfigurationException;

import org.apache.commons.io.IOUtils;
import org.apache.cxf.configuration.jsse.TLSClientParameters;
import org.apache.cxf.jaxrs.client.WebClient;
import org.apache.cxf.transport.http.HTTPConduit;
import org.apache.cxf.transports.http.configuration.ProxyServerType;
import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.skyscreamer.jsonassert.FieldComparisonFailure;
import org.skyscreamer.jsonassert.JSONCompareResult;
import org.skyscreamer.jsonassert.JSONParser;
import org.skyscreamer.jsonassert.comparator.DefaultComparator;

import com.adp.wfnddt.commonmethods.GZIPMethods;
import com.adp.wfnddt.commonmethods.General;
import com.adp.wfnddt.commonmethods.JSONMethods;
import com.adp.wfnddt.core.DDTController;
import com.adp.wfnddt.core.DDTFrameworkException;
import com.adp.wfnddt.core.DDTLoggerManager;
import com.adp.wfnddt.core.GlobalVariables.CharSet;
import com.adp.wfnddt.results.DDTResultsReporter;
import com.adp.wfnddt.results.jaxb.StatusType;

import jcifs.smb.SmbFile;
import jcifs.smb.SmbFileOutputStream;

public class TestRestAPI {
	private static Logger m_logger = DDTLoggerManager.getLogger(TestRestAPI.class);
	private String m_restUri;
	private MultivaluedMap<String, String> m_restHeaders; // Header,Value of header
	private String m_jsonFileRequestFile;
	private String m_jsonFileResponseFile;
	private DDTResultsReporter m_results = DDTController.getResultsReporter();
	private HashMap<String, String> m_replaceBodyValue = null; // Use this ONLY if you need to change values on the fly in the file. i.e. {associateOID} keyword in file needs to be changed to G47ABC485AAA
	private HashMap<String, String> m_replaceResponseBodyValue = null;
	private boolean m_DecompressGZIP = false;
	private String m_Proxy = "";
	private Integer m_ProxyPort = 8080;
	private ProxyServerType m_ProxyType = ProxyServerType.HTTP;
	private CharSet m_CharSet = CharSet.ISO_8859_1;
	protected boolean isExcel = false;
	private String m_keyStore = "";
	private String m_keyPassphrase = "";
	private String m_jsonBodyInputContent = "";
	private String m_jsonExpectedResultContent = "";
	private String[] m_encoding = {"gzip", "deflate", "sdch"};
	private String[] m_acceptLanguage = {"en-US", "en;q=0.8"};
	private MediaType m_mediaType = MediaType.APPLICATION_JSON_TYPE;
	private MediaType m_acceptMediaType = MediaType.APPLICATION_JSON_TYPE;
	private LinkedHashMap<String, Object> m_queryParams = new LinkedHashMap<>();
	private Boolean m_sortExpActual = false;

	public void setSortExpActual (Boolean p_OnOff) {
		m_sortExpActual = p_OnOff;
	}
	
	public void setEncoding (String[] p_encoding) {
		m_encoding = p_encoding;
	}

	public void setAcceptLanguage (String[] p_acceptLanguage) {
		m_acceptLanguage = p_acceptLanguage;
	}

	public void setMediaType (MediaType p_mediaType) {
		m_mediaType = p_mediaType;
	}

	public void setAcceptMediaType (MediaType p_acceptMediaType) {
		m_acceptMediaType = p_acceptMediaType;
	}

	public void setCharSet(CharSet p_charSet) {
		m_CharSet = p_charSet;
	}

	public void setDecompressGZIP(boolean p_decGZIP) {
		m_DecompressGZIP = p_decGZIP;
	}

	public void setProxy(String p_Proxy) {
		m_Proxy = p_Proxy;
	}

	public void setProxyPort(Integer p_ProxyPort) {
		m_ProxyPort = p_ProxyPort;
	}

	public void setProxyType(ProxyServerType p_ProxyPortType) {
		m_ProxyType = p_ProxyPortType;
	}

	public void addQueryParam(String p_key, Object p_value){
		m_queryParams.put(p_key, p_value);
	}
		
	private void setJSONData () throws DDTFrameworkException {
		//Sets JSON Body and Expected Result into Strings
		try {
			Scanner scannerInput = null;
			Scanner scannerResult = null;
			String jsonFileContent = "";
			String jsonResponseContent = "";
			if (!m_jsonFileRequestFile.isEmpty()) {
				if (m_jsonFileRequestFile.startsWith("RESOURCE:")) {
					scannerInput = new Scanner(new BufferedReader(new InputStreamReader(getClass().getResourceAsStream(m_jsonFileRequestFile.substring(9)))));
				} else {
					scannerInput = new Scanner(new File(m_jsonFileRequestFile));
				}				
				scannerInput.useDelimiter("\\Z");
				jsonFileContent = scannerInput.next();
				scannerInput.close();
				m_jsonBodyInputContent = replaceJSONBodyKeywords(jsonFileContent);
			}
			if (!m_jsonFileResponseFile.isEmpty()) {
				if (m_jsonFileResponseFile.startsWith("RESOURCE:")) {
					if (m_CharSet == CharSet.UTF8)
						scannerResult = new Scanner(new BufferedReader(new InputStreamReader(getClass().getResourceAsStream(m_jsonFileResponseFile.substring(9)), "UTF-8")));
					else
						scannerResult = new Scanner(new BufferedReader(new InputStreamReader(getClass().getResourceAsStream(m_jsonFileResponseFile.substring(9)), "ISO-8859-1")));
				} else {
					if (m_CharSet == CharSet.UTF8)
						scannerResult = new Scanner(new File(m_jsonFileResponseFile), "UTF-8");
					else
						scannerResult = new Scanner(new File(m_jsonFileResponseFile), "ISO-8859-1");
				}
				scannerResult.useDelimiter("\\Z");
				jsonResponseContent = scannerResult.next();
				scannerResult.close();
				m_jsonExpectedResultContent = replaceJSONBodyKeywords(jsonResponseContent);
			}
		} catch (Exception e) {
			throw new DDTFrameworkException(this.getClass(), "Failed to load JSON Content");
		}		
	}

	private Response sendRequest (String p_Action) throws DDTFrameworkException {
		Response clientPostResponse = null;
		
		try{
			WebClient webClient = WebClient.create(m_restUri);
			addX509TrustManager(webClient);
			HTTPConduit conduit = WebClient.getConfig(webClient).getHttpConduit();
			if (!m_Proxy.isEmpty()) {
				conduit.getClient().setProxyServer(m_Proxy);
				conduit.getClient().setProxyServerPort(m_ProxyPort);
				conduit.getClient().setProxyServerType(m_ProxyType);
			} else {
				conduit.getClient().setProxyServer("");
				conduit.getClient().setProxyServerPort(8080);
				conduit.getClient().setProxyServerType(ProxyServerType.HTTP);
			}
			// Post API
			m_logger.debug("postRestAPI Send Post");
			
			if (m_queryParams.size() > 0) {
				for (String key : m_queryParams.keySet()) {
					webClient = webClient.query(key, m_queryParams.get(key));
				}
			}
			
			switch (p_Action.toUpperCase()) {
			case "POST":
				clientPostResponse = webClient.acceptEncoding(m_encoding).acceptLanguage(m_acceptLanguage).type(m_mediaType).accept(m_acceptMediaType).headers(m_restHeaders).post(m_jsonBodyInputContent);
				break;
			case "PUT":
				clientPostResponse = webClient.acceptEncoding(m_encoding).acceptLanguage(m_acceptLanguage).type(m_mediaType).accept(m_acceptMediaType).headers(m_restHeaders).put(m_jsonBodyInputContent);
				break;
			case "GET":
				clientPostResponse = webClient.acceptEncoding(m_encoding).acceptLanguage(m_acceptLanguage).type(m_mediaType).accept(m_acceptMediaType).headers(m_restHeaders).get();
				break;
			default:
				break;
			}
			webClient.close();
			return clientPostResponse;
		} catch (Exception e) {
			throw new DDTFrameworkException(this.getClass(), "Failed to send web service request");
		}
	}
	
	public TestRestAPI(String p_restUri, MultivaluedMap<String, String> p_restHeaders, String p_jsonFileRequest, String p_jsonFileResponse) {
		m_restUri = p_restUri;
		m_restHeaders = p_restHeaders;
		m_jsonFileRequestFile = p_jsonFileRequest;
		m_jsonFileResponseFile = p_jsonFileResponse;
		return;
	}

	public TestRestAPI(String p_restUri, MultivaluedMap<String, String> p_restHeaders, String p_jsonFileRequest) {
		m_restUri = p_restUri;
		m_restHeaders = p_restHeaders;
		m_jsonFileRequestFile = p_jsonFileRequest;

		return;
	}

	private String replaceJSONBodyKeywords(String p_FileContent) {
		if (!isExcel) {
			if (m_replaceBodyValue == null)
				return p_FileContent; // return is nothing is set
			for (Map.Entry<String, String> record : m_replaceBodyValue.entrySet()) {
				String source = (String) record.getKey();
				String target = (String) record.getValue();
				p_FileContent = p_FileContent.replaceAll(source, target); // both are regex related - please use regex formats
			}
			return p_FileContent;
		} else {
			if (m_replaceBodyValue == null && m_replaceResponseBodyValue == null)
				return p_FileContent; // return is nothing is set
			else if (m_replaceBodyValue != null) {
				for (Map.Entry<String, String> record : m_replaceBodyValue.entrySet()) {
					String source = (String) record.getKey();
					String target = (String) record.getValue();
					p_FileContent = p_FileContent.replaceAll(source, target); // both are regex related - please use regex formats
				}
				m_replaceBodyValue = null;
				return p_FileContent;
			} else if (m_replaceResponseBodyValue != null) {
				for (Map.Entry<String, String> record : m_replaceResponseBodyValue.entrySet()) {
					String source = (String) record.getKey();
					String target = (String) record.getValue();
					p_FileContent = p_FileContent.replaceAll(source, target); // both are regex related - please use regex formats
				}
				m_replaceResponseBodyValue = null;
				return p_FileContent;
			}
			return p_FileContent;
		}
	}

	public void setReplaceBodyValues(HashMap<String, String> p_replacementHash) {
		m_replaceBodyValue = new HashMap<String, String>();
		m_replaceBodyValue.clear();
		m_replaceBodyValue.putAll(p_replacementHash);
	}

	public void setReplaceResponseBodyValues(HashMap<String, String> p_replacementHash) {
		m_replaceResponseBodyValue = new HashMap<String, String>();
		m_replaceResponseBodyValue.clear();
		m_replaceResponseBodyValue.putAll(p_replacementHash);
	}

	public Response postRestAPIResponse() throws DDTFrameworkException {
		Response clientPostResponse = null;
		try {
			setJSONData();

			// Post API
			m_logger.debug("postRestAPI Send Post");
			clientPostResponse = sendRequest("POST");

			return clientPostResponse;
		} catch (Exception ex) {
			throw new DDTFrameworkException(TestRestAPI.class, "An unexpected error occurred while invoking postRestAPIResponse TestRestAPI service.", ex);
		}
	}

	/**
	 * Returns the JSON Object value provided by the GPATH p_FindObject
	 * 
	 * @param p_FindObject
	 *            Key value to retrieve in GPATH format like "emps.employee[0].'Position ID'"
	 * @return String
	 * @throws DDTFrameworkException
	 */

	public String postAndGetObjectValue(String p_FindObject) throws DDTFrameworkException {
		Response clientPostResponse = null;
		String retValue = "";
		byte[] byteResponse = null;
		try {
			setJSONData();
			
			// Post API
			m_logger.debug("postRestAPI Send Post");
			clientPostResponse = sendRequest("POST");
			if (m_DecompressGZIP) {
				byteResponse = clientPostResponse.readEntity(byte[].class);
				retValue = GZIPMethods.decompressGZIP(byteResponse);
			} else {
				retValue = clientPostResponse.readEntity(String.class);
			}
			return JSONMethods.getJSONObjectValue(retValue, p_FindObject);
		} catch (Exception ex) {
			throw new DDTFrameworkException(TestRestAPI.class, "An unexpected error occurred while invoking postRestApi TestRestAPI service.", ex);
		}
	}

	public String postRestAPI() throws DDTFrameworkException {
		Response clientPostResponse = null;
		String retValue = "";
		Boolean blnPassed = false;
		byte[] byteResponse = null;
		try {
			setJSONData();
			// Post API
			m_logger.debug("postRestAPI Send Post");
			clientPostResponse = sendRequest("POST");
			if (m_DecompressGZIP) {
				byteResponse = clientPostResponse.readEntity(byte[].class);
				retValue = GZIPMethods.decompressGZIP(byteResponse);
			} else {
				retValue = clientPostResponse.readEntity(String.class);
			}

			m_results.addTestStep("POST API");
			m_results.startVerificationLogStep();
			String[] arrExpResponses = m_jsonExpectedResultContent.split("<IGNORE>");
			for (String strExpResponse : arrExpResponses) {
				if (retValue.contains(strExpResponse)) {
					blnPassed = true;
				} else {
					blnPassed = false;
					break;
				}
			}
			if (blnPassed) {
				m_results.addEntryToVerificationLog("Verification of Test Post API", StatusType.PASSED, m_jsonExpectedResultContent, retValue);
				m_results.endVerificationLogStep(StatusType.PASSED);
				m_results.endTestStep(StatusType.PASSED);
			} else {
				m_results.addEntryToVerificationLog("Verification of Test Post API", StatusType.FAILED, m_jsonExpectedResultContent, retValue);
				m_results.endVerificationLogStep(StatusType.FAILED);
				m_results.endTestStep(StatusType.FAILED);
			}
			return retValue;
		} catch (Exception ex) {
			throw new DDTFrameworkException(TestRestAPI.class, "An unexpected error occurred while invoking postRestApi TestRestAPI service.", ex);
		}
	}

	/**
	 * Compares each individual line in the Expected Json file to the actual and passes if each line exists
	 * 
	 * @return String
	 * @throws DDTFrameworkException
	 */
	public String postRestAPILineCompare() throws DDTFrameworkException {
		Response clientPostResponse = null;
		String retValue = "FAILED";
		Boolean blnPassed = true;
		byte[] byteResponse = null;
		try {
			setJSONData();
			
			// Post API
			m_logger.debug("postRestAPI Send Post");
			clientPostResponse = sendRequest("POST");
			if (m_DecompressGZIP) {
				byteResponse = clientPostResponse.readEntity(byte[].class);
				retValue = GZIPMethods.decompressGZIP(byteResponse);
			} else {
				retValue = clientPostResponse.readEntity(String.class);
			}

			m_results.addTestStep("POST API LINE COMPARE");
			m_results.startVerificationLogStep();
			m_results.addEntryToVerificationLog("Actual Value Used for Compare", StatusType.DONE, "FULL ACTUAL VALUE:", retValue);
			String[] arrExpResponses = m_jsonExpectedResultContent.split("<IGNORE>|\n");
			for (String strExpResponse : arrExpResponses) {
				if (retValue.contains(strExpResponse)) {
					m_results.addEntryToVerificationLog("Verification of Test Post API Line Compare", StatusType.PASSED, strExpResponse, "See Full Actual Value Above");
				} else {
					blnPassed = false;
					m_results.addEntryToVerificationLog("Verification of Test Post API Line Compare", StatusType.FAILED, strExpResponse, "See Full Actual Value Above");
				}
			}
			if (blnPassed) {
				m_results.endVerificationLogStep();
				m_results.endTestStep(StatusType.PASSED);
			} else {
				m_results.endVerificationLogStep();
				m_results.endTestStep(StatusType.FAILED);
			}
			return retValue;
		} catch (Exception ex) {
			throw new DDTFrameworkException(TestRestAPI.class, "An unexpected error occurred while invoking postRestApi TestRestAPI service.", ex);
		}
	}

	public String postRestAPIJSONCompare() throws DDTFrameworkException {
		return postRestAPIJSONCompare("STRICT");
	}

	public String postRestAPIJSONCompare(String p_compareType) throws DDTFrameworkException {
		Response clientPostResponse = null;
		String retValue = "";
		DefaultComparator jsonComparator;
		byte[] byteResponse = null;
		try {
			setJSONData();
			
			// Post API
			m_logger.debug("postRestAPIJSONCompare Send Post");
			clientPostResponse = sendRequest("POST");
			if (m_DecompressGZIP) {
				byteResponse = clientPostResponse.readEntity(byte[].class);
				retValue = GZIPMethods.decompressGZIP(byteResponse);
			} else {
				retValue = clientPostResponse.readEntity(String.class);
			}

			m_results.addTestStep("POST API JSON COMPARE");
			m_results.startVerificationLogStep();
			switch (p_compareType) {
			case "LENIENT":
				jsonComparator = new DefaultComparator(LENIENT);
				break;
			default:
				jsonComparator = new DefaultComparator(STRICT);
				break;
			}
			JSONCompareResult resultSet = JSONMethods.compareJSONStr(m_jsonExpectedResultContent, retValue, jsonComparator);
			boolean m_actualFailed = false;
			if (!resultSet.passed()) { // Compare failed
				for (FieldComparisonFailure failedField : resultSet.getFieldFailures()) {
					if (failedField.getExpected().toString().equalsIgnoreCase("<IGNORE>")) {
						m_results.addEntryToVerificationLog("Failure On: " + failedField.getField(), StatusType.PASSED, failedField.getExpected().toString(), failedField.getActual().toString());
					} else {
						m_results.addEntryToVerificationLog("Failure On: " + failedField.getField(), StatusType.FAILED, failedField.getExpected().toString(), failedField.getActual().toString());
						m_actualFailed = true;
					}
				}
				for (FieldComparisonFailure failedMissing : resultSet.getFieldMissing()) {
					String actual = (failedMissing.getActual() == null) ? "" : failedMissing.getActual().toString();
					String expected = (failedMissing.getExpected() == null) ? "" : failedMissing.getExpected().toString();
					m_results.addEntryToVerificationLog("Field Missing On: " + failedMissing.getField(), StatusType.FAILED, expected, actual);
					m_actualFailed = true;
				}
				for (FieldComparisonFailure failedField : resultSet.getFieldUnexpected()) {
					m_results.addEntryToVerificationLog("Unexpected Failure On: " + failedField.getField(), StatusType.FAILED, failedField.getExpected().toString(), failedField.getActual().toString());
					m_actualFailed = true;
				}
				if (m_actualFailed) {
					m_results.addEntryToVerificationLog("Verification of Test Post API JSON Compare", StatusType.FAILED, m_jsonExpectedResultContent, retValue);
					m_results.endVerificationLogStep(StatusType.FAILED);
					m_results.endTestStep(StatusType.FAILED);
				} else {
					m_results.addEntryToVerificationLog("Verification of Test Post API JSON Compare", StatusType.PASSED, m_jsonExpectedResultContent, retValue);
					m_results.endVerificationLogStep(StatusType.PASSED);
					m_results.endTestStep(StatusType.PASSED);
				}

			} else {
				m_results.addEntryToVerificationLog("Verification of Test Post API JSON Compare", StatusType.PASSED, m_jsonExpectedResultContent, retValue);
				m_results.endVerificationLogStep(StatusType.PASSED);
				m_results.endTestStep(StatusType.PASSED);
			}

			return retValue;
		} catch (Exception ex) {
			throw new DDTFrameworkException(TestRestAPI.class, "An unexpected error occurred while invoking postRestApi TestRestAPI service.", ex);
		}
	}

	public Response postRestAPIPDF(String p_PDFFileLocation) throws DDTFrameworkException {
		// p_PDFFileLocation will point to the location you want to put the PDF file to compare like "M:\Reports\All Reports\Current..."
		Response clientPostResponse = null;
		byte[] retValue = null;
		try {
			setJSONData();

			// Post API
			m_logger.debug("postRestAPIPDF Send Post");
			setAcceptMediaType(MediaType.WILDCARD_TYPE); 
			clientPostResponse = sendRequest("POST");
			// retValue = clientPostResponse.readEntity(String.class);
			retValue = (byte[]) clientPostResponse.readEntity(byte[].class);
			if (retValue != null) {
				createPDFFile(retValue, p_PDFFileLocation);
			} else { // response is null - should never happen but I have seen 1 case
				m_results.addTestStep("POST API for PDF - null response");
				m_results.endTestStep(StatusType.FAILED);
				m_logger.error("postRestAPIPDF response was null. Caught exception and moving on");
			}

			m_results.addTestStep("POST API for PDF");
			m_results.endTestStep(StatusType.DONE);
			return clientPostResponse;
		} catch (Exception ex) {
			throw new DDTFrameworkException(TestRestAPI.class, "An unexpected error occurred while invoking postRestApi TestRestAPI service for PDF.", ex);
		}
	}

	public Response putRestAPIResponse() throws DDTFrameworkException {
		Response clientPostResponse = null;
		try {
			setJSONData();

			// Put API
			m_logger.debug("putRestAPI Send Put");
			clientPostResponse = sendRequest("PUT");

			return clientPostResponse;
		} catch (Exception ex) {
			throw new DDTFrameworkException(TestRestAPI.class, "An unexpected error occurred while invoking putRestApi TestRestAPI service.", ex);
		}
	}

	/**
	 * Returns the JSON Object value provided by the GPATH p_FindObject
	 * 
	 * @param p_FindObject
	 *            Key value to retrieve in GPATH format like "emps.employee[0].'Position ID'"
	 * @return String
	 * @throws DDTFrameworkException
	 */

	public String putAndGetObjectValue(String p_FindObject) throws DDTFrameworkException {
		Response clientPostResponse = null;
		String retValue = "";
		byte[] byteResponse = null;
		try {
			setJSONData();
			
			// Put API
			m_logger.debug("putRestAPI Send Put");
			clientPostResponse = sendRequest("PUT");
			if (m_DecompressGZIP) {
				byteResponse = clientPostResponse.readEntity(byte[].class);
				retValue = GZIPMethods.decompressGZIP(byteResponse);
			} else {
				retValue = clientPostResponse.readEntity(String.class);
			}
			return JSONMethods.getJSONObjectValue(retValue, p_FindObject);
		} catch (Exception ex) {
			throw new DDTFrameworkException(TestRestAPI.class, "An unexpected error occurred while invoking putRestApi TestRestAPI service.", ex);
		}
	}

	public String putRestAPI() throws DDTFrameworkException {
		Response clientPostResponse = null;
		String retValue = "";
		Boolean blnPassed = false;
		byte[] byteResponse = null;
		try {
			setJSONData();
			
			// Put API
			m_logger.debug("putRestAPI Send Put");
			clientPostResponse = sendRequest("PUT");
			if (m_DecompressGZIP) {
				byteResponse = clientPostResponse.readEntity(byte[].class);
				retValue = GZIPMethods.decompressGZIP(byteResponse);
			} else {
				retValue = clientPostResponse.readEntity(String.class);
			}

			m_results.addTestStep("PUT API");
			m_results.startVerificationLogStep();
			String[] arrExpResponses = m_jsonExpectedResultContent.split("<IGNORE>");
			for (String strExpResponse : arrExpResponses) {
				if (retValue.contains(strExpResponse)) {
					blnPassed = true;
				} else {
					blnPassed = false;
					break;
				}
			}
			if (blnPassed) {
				m_results.addEntryToVerificationLog("Verification of Test Put API", StatusType.PASSED, m_jsonExpectedResultContent, retValue);
				m_results.endVerificationLogStep(StatusType.PASSED);
				m_results.endTestStep(StatusType.PASSED);
			} else {
				m_results.addEntryToVerificationLog("Verification of Test Put API", StatusType.FAILED, m_jsonExpectedResultContent, retValue);
				m_results.endVerificationLogStep(StatusType.FAILED);
				m_results.endTestStep(StatusType.FAILED);
			}
			return retValue;
		} catch (Exception ex) {
			throw new DDTFrameworkException(TestRestAPI.class, "An unexpected error occurred while invoking putRestApi TestRestAPI service.", ex);
		}
	}

	/**
	 * Compares each individual line in the Expected Json file to the actual and passes if each line exists
	 * 
	 * @return String
	 * @throws DDTFrameworkException
	 */
	public String putRestAPILineCompare() throws DDTFrameworkException {
		Response clientPostResponse = null;
		String retValue = "FAILED";
		Boolean blnPassed = true;
		byte[] byteResponse = null;
		try {
			setJSONData();
			
			// Put API
			m_logger.debug("putRestAPI Send Put");
			clientPostResponse = sendRequest("PUT");
			if (m_DecompressGZIP) {
				byteResponse = clientPostResponse.readEntity(byte[].class);
				retValue = GZIPMethods.decompressGZIP(byteResponse);
			} else {
				retValue = clientPostResponse.readEntity(String.class);
			}

			m_results.addTestStep("PUT API LINE COMPARE");
			m_results.startVerificationLogStep();
			m_results.addEntryToVerificationLog("Actual Value Used for Compare", StatusType.DONE, "FULL ACTUAL VALUE:", retValue);
			String[] arrExpResponses = m_jsonExpectedResultContent.split("<IGNORE>|\n");
			for (String strExpResponse : arrExpResponses) {
				if (retValue.contains(strExpResponse)) {
					m_results.addEntryToVerificationLog("Verification of Test Put API Line Compare", StatusType.PASSED, strExpResponse, "See Full Actual Value Above");
				} else {
					blnPassed = false;
					m_results.addEntryToVerificationLog("Verification of Test Put API Line Compare", StatusType.FAILED, strExpResponse, "See Full Actual Value Above");
				}
			}
			if (blnPassed) {
				m_results.endVerificationLogStep();
				m_results.endTestStep(StatusType.PASSED);
			} else {
				m_results.endVerificationLogStep();
				m_results.endTestStep(StatusType.FAILED);
			}
			return retValue;
		} catch (Exception ex) {
			throw new DDTFrameworkException(TestRestAPI.class, "An unexpected error occurred while invoking putRestApi TestRestAPI service.", ex);
		}
	}

	public String putRestAPIJSONCompare() throws DDTFrameworkException {
		Response clientPostResponse = null;
		String retValue = "";
		byte[] byteResponse = null;
		try {
			setJSONData();

			// Put API
			m_logger.debug("putRestAPI Send Put JSON Compare");
			clientPostResponse = sendRequest("PUT");
			if (m_DecompressGZIP) {
				byteResponse = clientPostResponse.readEntity(byte[].class);
				retValue = GZIPMethods.decompressGZIP(byteResponse);
			} else {
				retValue = clientPostResponse.readEntity(String.class);
			}

			m_results.addTestStep("PUT API JSON COMPARE");
			m_results.startVerificationLogStep();

			DefaultComparator jsonComparator = new DefaultComparator(STRICT);
			JSONCompareResult resultSet = JSONMethods.compareJSONStr(m_jsonExpectedResultContent, retValue, jsonComparator);
			if (!resultSet.passed()) { // Compare failed
				for (FieldComparisonFailure failedField : resultSet.getFieldFailures()) {
					m_results.addEntryToVerificationLog("Failure On: " + failedField.getField(), StatusType.FAILED, failedField.getExpected().toString(), failedField.getActual().toString());
				}
				for (FieldComparisonFailure failedField : resultSet.getFieldMissing()) {
					m_results.addEntryToVerificationLog("Field Missing On: " + failedField.getField(), StatusType.FAILED, failedField.getExpected().toString(), failedField.getActual().toString());
				}
				for (FieldComparisonFailure failedField : resultSet.getFieldUnexpected()) {
					m_results.addEntryToVerificationLog("Unexpected Failure On: " + failedField.getField(), StatusType.FAILED, failedField.getExpected().toString(), failedField.getActual().toString());
				}
				m_results.addEntryToVerificationLog("Verification of Test Put API JSON Compare", StatusType.FAILED, m_jsonExpectedResultContent, retValue);
				m_results.endVerificationLogStep(StatusType.FAILED);
				m_results.endTestStep(StatusType.FAILED);
			} else {
				m_results.addEntryToVerificationLog("Verification of Test Put API JSON Compare", StatusType.PASSED, m_jsonExpectedResultContent, retValue);
				m_results.endVerificationLogStep(StatusType.PASSED);
				m_results.endTestStep(StatusType.PASSED);
			}

			return retValue;
		} catch (Exception ex) {
			throw new DDTFrameworkException(TestRestAPI.class, "An unexpected error occurred while invoking putRestApi TestRestAPI service.", ex);
		}
	}

	public Response getRestAPIResponse() throws DDTFrameworkException {
		Response clientPostResponse = null;

		try {

			// Get API
			m_logger.debug("getRestAPI Send Get");
			clientPostResponse = sendRequest("GET");

			return clientPostResponse;
		} catch (Exception ex) {
			throw new DDTFrameworkException(TestRestAPI.class, "An unexpected error occurred while invoking getRestApi TestRestAPI service.", ex);
		}
	}

	/**
	 * Returns the JSON Object value provided by the GPATH p_FindObject
	 * 
	 * @param p_FindObject
	 *            Key value to retrieve in GPATH format like "emps.employee[0].'Position ID'"
	 * @return String
	 * @throws DDTFrameworkException
	 */

	public String getAndGetObjectValue(String p_FindObject) throws DDTFrameworkException {
		Response clientPostResponse = null;
		String retValue = "FAILED";
		byte[] byteResponse = null;
		try {
			setJSONData();
			
			// Get API
			m_logger.debug("getRestAPI Send Get");

			clientPostResponse = sendRequest("GET");
			if (m_DecompressGZIP) {
				byteResponse = clientPostResponse.readEntity(byte[].class);
				retValue = GZIPMethods.decompressGZIP(byteResponse);
			} else {
				retValue = clientPostResponse.readEntity(String.class);
			}
			return JSONMethods.getJSONObjectValue(retValue, p_FindObject);
		} catch (Exception ex) {
			throw new DDTFrameworkException(TestRestAPI.class, "An unexpected error occurred while invoking getAndGetObjectValue TestRestAPI service.", ex);
		}
	}

	/**
	 * This method validates the content of your p_FindObject and compares it with a text file containing the data expected.
	 * 
	 * @param p_FindObject
	 * @param txtFilePath
	 * @return String of the p_FindObject if needed.
	 * @throws DDTFrameworkException
	 */
	public String getAndGetObjectValue(String p_FindObject, String txtFilePath) throws DDTFrameworkException {
		Response clientPostResponse = null;
		String retValue = "FAILED";
		Boolean blnPassed = false;
		byte[] byteResponse = null;
		try {
			// Get API
			m_logger.debug("getRestAPI Send Get");
			clientPostResponse = sendRequest("GET");
			if (m_DecompressGZIP) {
				byteResponse = clientPostResponse.readEntity(byte[].class);
				retValue = GZIPMethods.decompressGZIP(byteResponse);
			} else {
				retValue = clientPostResponse.readEntity(String.class);
			}
			String value = JSONMethods.getJSONObjectValue(retValue, p_FindObject);

			// Doing some replaces to remove all the [, ], {, } and replacing all ", " for a single ",";
			String newRetValue = value.replaceAll("[\\[\\]\\{\\}]", "");
			String newRetValue2 = newRetValue.replaceAll(",\\s", ",");
			List<String> actualResponse = new ArrayList<String>(Arrays.asList(newRetValue2.split(",")));
			String actualResp = actualResponse.toString();

			String responseContent = new String(Files.readAllBytes(Paths.get(txtFilePath)));
			String newResponseContent = responseContent.replaceAll(",\\s", ",");
			List<String> expectedResponse = new ArrayList<String>(Arrays.asList(newResponseContent.split(",")));
			String expectedResp = expectedResponse.toString();

			m_results.addTestStep("GET API");
			m_results.startVerificationLogStep();

			if (actualResponse.containsAll(expectedResponse)) {
				blnPassed = true;
			} else {
				blnPassed = false;
			}

			if (blnPassed) {
				m_results.addEntryToVerificationLog("Verification of Test Get API", StatusType.PASSED, expectedResp, actualResp);
				m_results.endVerificationLogStep(StatusType.PASSED);
				m_results.endTestStep(StatusType.PASSED);
			} else {
				m_results.addEntryToVerificationLog("Verification of Test Get API", StatusType.FAILED, expectedResp, actualResp);
				m_results.endVerificationLogStep(StatusType.FAILED);
				m_results.endTestStep(StatusType.FAILED);
			}

			return JSONMethods.getJSONObjectValue(retValue, p_FindObject);
		} catch (Exception ex) {
			throw new DDTFrameworkException(TestRestAPI.class, "An unexpected error occurred while invoking getAndGetObjectValue2 TestRestAPI service.", ex);
		}
	}

	public String getRestAPI() throws DDTFrameworkException {
		Response clientPostResponse = null;
		String retValue = "FAILED";
		Boolean blnPassed = false;
		byte[] byteResponse = null;
		try {
			setJSONData();
			
			// Get API
			m_logger.debug("getRestAPI Send Get");
			clientPostResponse = sendRequest("GET");
			if (m_DecompressGZIP) {
				byteResponse = clientPostResponse.readEntity(byte[].class);
				retValue = GZIPMethods.decompressGZIP(byteResponse);
			} else {
				retValue = clientPostResponse.readEntity(String.class);
			}

			m_results.addTestStep("GET API");
			m_results.startVerificationLogStep();
			String[] arrExpResponses = m_jsonExpectedResultContent.split("<IGNORE>");
			if (m_sortExpActual) {
				for (int i = 0; i < arrExpResponses.length; i++) {
					arrExpResponses[i] = General.sortedString(arrExpResponses[i]);
				}
				retValue = General.sortedString(retValue);				
			}
			for (String strExpResponse : arrExpResponses) {
				if (retValue.contains(strExpResponse)) {
					blnPassed = true;
				} else {
					blnPassed = false;
					break;
				}
			}
			if (blnPassed) {
				m_results.addEntryToVerificationLog("Verification of Test Get API", StatusType.PASSED, m_jsonExpectedResultContent, retValue);
				m_results.endVerificationLogStep(StatusType.PASSED);
				m_results.endTestStep(StatusType.PASSED);
			} else {
				m_results.addEntryToVerificationLog("Verification of Test Get API", StatusType.FAILED, m_jsonExpectedResultContent, retValue);
				m_results.endVerificationLogStep(StatusType.FAILED);
				m_results.endTestStep(StatusType.FAILED);
			}
			return retValue;
		} catch (Exception ex) {
			throw new DDTFrameworkException(TestRestAPI.class, "An unexpected error occurred while invoking getRestApi TestRestAPI service.", ex);
		}
	}

	/**
	 * Execute a get call and validate the response across the the schema of response based on schema file path.
	 * 
	 * @return String
	 * @throws DDTFrameworkException
	 */
	public String getRestAPIJSONSchemaValidation() throws DDTFrameworkException {
		Response clientPostResponse = null;
		String retValue = "FAILED";
		byte[] byteResponse = null;
		try {
			setJSONData();
			
			// Get API
			m_logger.debug("Send Get Schema Validation");
			m_results.addTestStep("GET API Schema Validation");
			m_results.startVerificationLogStep();
			clientPostResponse = sendRequest("GET");
			if (m_DecompressGZIP) {
				byteResponse = clientPostResponse.readEntity(byte[].class);
				retValue = GZIPMethods.decompressGZIP(byteResponse);
			} else {
				retValue = clientPostResponse.readEntity(String.class);
			}
			Object expected = JSONParser.parseJSON(retValue);			
			if (expected instanceof JSONObject) {

				JSONCompareResult resultSet = JSONMethods.validateJSONFileSchema(m_jsonExpectedResultContent, retValue);
				if (resultSet.passed()) { 					
					m_results.addEntryToVerificationLog("Verification of Schema", StatusType.PASSED, m_jsonExpectedResultContent, retValue);
					m_results.endVerificationLogStep(StatusType.PASSED);
					m_results.endTestStep(StatusType.PASSED);
				}else{
					m_results.addEntryToVerificationLog("Verification of Schema", StatusType.FAILED,retValue, resultSet.getMessage());
					m_results.endVerificationLogStep(StatusType.FAILED);
					m_results.endTestStep(StatusType.FAILED);
				}
			} else {
				m_results.addEntryToVerificationLog("Verification of Schema", StatusType.FAILED, m_jsonExpectedResultContent, retValue);
				m_results.endVerificationLogStep(StatusType.FAILED);
				m_results.endTestStep(StatusType.FAILED);
			}
			return retValue;
		} catch (Exception ex) {
			throw new DDTFrameworkException(TestRestAPI.class, "An unexpected error occurred while invoking getRestApi TestRestAPI service.", ex);
		}
	}

	/**
	 * Compares each individual line in the Expected Json file to the actual and passes if each line exists
	 * 
	 * @return String
	 * @throws DDTFrameworkException
	 */
	public String getRestAPILineCompare() throws DDTFrameworkException {
		Response clientPostResponse = null;
		String retValue = "FAILED";
		Boolean blnPassed = true;
		byte[] byteResponse = null;
		try {
			setJSONData();

			// Get API
			m_logger.debug("getRestAPI Send Get");
			clientPostResponse = sendRequest("GET");
			if (m_DecompressGZIP) {
				byteResponse = clientPostResponse.readEntity(byte[].class);
				retValue = GZIPMethods.decompressGZIP(byteResponse);
			} else {
				retValue = clientPostResponse.readEntity(String.class);
			}

			m_results.addTestStep("GET API LINE COMPARE");
			m_results.startVerificationLogStep();
			m_results.addEntryToVerificationLog("Actual Value Used for Compare", StatusType.DONE, "FULL ACTUAL VALUE:", retValue);
			String[] arrExpResponses = m_jsonExpectedResultContent.split("<IGNORE>|\n");
			for (String strExpResponse : arrExpResponses) {
				if (retValue.contains(strExpResponse)) {
					m_results.addEntryToVerificationLog("Verification of Test Get API Line Compare", StatusType.PASSED, strExpResponse, "See Full Actual Value Above");
				} else {
					blnPassed = false;
					m_results.addEntryToVerificationLog("Verification of Test Get API Line Compare", StatusType.FAILED, strExpResponse, "See Full Actual Value Above");
				}
			}
			if (blnPassed) {
				m_results.endVerificationLogStep();
				m_results.endTestStep(StatusType.PASSED);
			} else {
				m_results.endVerificationLogStep();
				m_results.endTestStep(StatusType.FAILED);
			}
			return retValue;
		} catch (Exception ex) {
			throw new DDTFrameworkException(TestRestAPI.class, "An unexpected error occurred while invoking getRestApi TestRestAPI service.", ex);
		}
	}

	public String getRestAPIJSONCompare() throws DDTFrameworkException {
		return getRestAPIJSONCompare("STRICT");
	}

	public String getRestAPIJSONCompare(String p_compareType) throws DDTFrameworkException {
		Response clientPostResponse = null;
		String retValue = "FAILED";
		DefaultComparator jsonComparator;
		byte[] byteResponse = null;
		try {
			setJSONData();
			
			// Get API
			m_logger.debug("getRestAPI Send Get JSON Compare");
			clientPostResponse = sendRequest("GET");
			if (m_DecompressGZIP) {
				byteResponse = clientPostResponse.readEntity(byte[].class);
				retValue = GZIPMethods.decompressGZIP(byteResponse);
			} else {
				retValue = clientPostResponse.readEntity(String.class);
			}

			m_results.addTestStep("GET API JSON COMPARE");
			m_results.startVerificationLogStep();
			switch (p_compareType) {
			case "LENIENT":
				jsonComparator = new DefaultComparator(LENIENT);
				break;
			default:
				jsonComparator = new DefaultComparator(STRICT);
				break;
			}
			JSONCompareResult resultSet = JSONMethods.compareJSONStr(m_jsonExpectedResultContent, retValue, jsonComparator);
			boolean m_actualFailed = false;
			if (!resultSet.passed()) { // Compare failed
				for (FieldComparisonFailure failedField : resultSet.getFieldFailures()) {
					String actual = (failedField.getActual() == null) ? "" : failedField.getActual().toString();
					String expected = (failedField.getExpected() == null) ? "" : failedField.getExpected().toString();
					if (expected.equalsIgnoreCase("<IGNORE>")) {
						m_results.addEntryToVerificationLog("Failure On: " + failedField.getField(), StatusType.PASSED, expected, actual);
					} else {
						m_results.addEntryToVerificationLog("Failure On: " + failedField.getField(), StatusType.FAILED, expected, actual);
						m_actualFailed = true;
					}
				}
				for (FieldComparisonFailure failedMissing : resultSet.getFieldMissing()) {
					String actual = (failedMissing.getActual() == null) ? "" : failedMissing.getActual().toString();
					String expected = (failedMissing.getExpected() == null) ? "" : failedMissing.getExpected().toString();
					m_results.addEntryToVerificationLog("Field Missing On: " + failedMissing.getField(), StatusType.FAILED, expected, actual);
					m_actualFailed = true;
				}
				for (FieldComparisonFailure failedUnexpected : resultSet.getFieldUnexpected()) {
					String actual = (failedUnexpected.getActual() == null) ? "" : failedUnexpected.getActual().toString();
					String expected = (failedUnexpected.getExpected() == null) ? "" : failedUnexpected.getExpected().toString();
					m_results.addEntryToVerificationLog("Unexpected Failure On: " + failedUnexpected.getField(), StatusType.FAILED, expected, actual);
					m_actualFailed = true;
				}
				if (m_actualFailed) {
					m_results.addEntryToVerificationLog("Verification of Test Get API JSON Compare", StatusType.FAILED, m_jsonExpectedResultContent, retValue);
					m_results.endVerificationLogStep(StatusType.FAILED);
					m_results.endTestStep(StatusType.FAILED);
				} else {
					m_results.addEntryToVerificationLog("Verification of Test Get API JSON Compare", StatusType.PASSED, m_jsonExpectedResultContent, retValue);
					m_results.endVerificationLogStep(StatusType.PASSED);
					m_results.endTestStep(StatusType.PASSED);
				}
			} else {
				m_results.addEntryToVerificationLog("Verification of Test Get API JSON Compare", StatusType.PASSED, m_jsonExpectedResultContent, retValue);
				m_results.endVerificationLogStep(StatusType.PASSED);
				m_results.endTestStep(StatusType.PASSED);
			}

			return retValue;
		} catch (Exception ex) {
			throw new DDTFrameworkException(TestRestAPI.class, "An unexpected error occurred while invoking getRestApi TestRestAPI service.", ex);
		}
	}

	/*
	 * p_CopyFileToPath should contain the full path including SMB or include the keyword [REPORTS] i.e. smb://Cdlisilon01-cifs.cdl.rose.us.adp/wfn/Automation/Reports/All Reports/Current/COBRA Continuation Letter/TEST.pdf (OFFICIAL FORMAT) i.e. [REPORTS]/All Reports/Current/COBRA Continuation Letter/TEST.pdf (OFFICIAL FORMAT)
	 * 
	 * i.e. /Temp/Test.pdf (local copy for windows, MAC or Linux) i.e. C:/Temp/Test.pdf (windows only)
	 */
	public void createPDFFile(byte[] p_Output, String p_CreateFilePath) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		SmbFile targetfile = null;
		String targetname = p_CreateFilePath;
		targetname = targetname.replaceAll("\\\\", "\\/");
		targetname = targetname.replace("smb://", "smb://es.ad.adp.com;autoxpert:adpadp@");
		targetname = targetname.replace("[REPORTS]", "smb://es.ad.adp.com;autoxpert:adpadp@Cdlisilon01-cifs.cdl.rose.us.adp/wfn/Automation/Reports");
		try {
			if (p_CreateFilePath.startsWith("/") || p_CreateFilePath.startsWith("C:/") || p_CreateFilePath.startsWith("D:/")) { // Local file creation on windows
				IOUtils.write(p_Output, new FileOutputStream(p_CreateFilePath, false));
			} else { // SMB
				targetfile = new SmbFile(targetname);
				IOUtils.write(p_Output, new SmbFileOutputStream(targetfile, false));
			}

			return;
		} catch (Exception e) {
			throw new DDTFrameworkException(TestRestAPI.class, "An unexpected error occurred while invoking createPDFFile.", e);
		}
	}

	private void addX509TrustManager(WebClient p_webClient) throws DDTFrameworkException {

		try {
			HTTPConduit conduit = WebClient.getConfig(p_webClient).getHttpConduit();
			TLSClientParameters params = conduit.getTlsClientParameters();

			if (params == null) {
				params = new TLSClientParameters();
				conduit.setTlsClientParameters(params);
			}

			params.setTrustManagers(new TrustManager[] { (TrustManager) new BlindTrustManager() });
			params.setDisableCNCheck(true);

			if (!m_keyStore.equals("")) {
				// System.setProperty("javax.net.debug", "ssl");

				KeyStore keyStore = KeyStore.getInstance("JKS");
				keyStore.load(this.getClass().getResourceAsStream(m_keyStore), m_keyPassphrase.toCharArray());

				KeyManagerFactory keyFactory = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
				keyFactory.init(keyStore, m_keyPassphrase.toCharArray());

				params.setKeyManagers(keyFactory.getKeyManagers());
			}
		} catch (Exception ex) {
			throw new DDTFrameworkException(TestRestAPI.class, ex.getMessage());
		}
	}

	private class BlindTrustManager implements X509TrustManager {

		@Override
		public void checkClientTrusted(X509Certificate[] chain, String authType) throws java.security.cert.CertificateException {
		}

		@Override
		public void checkServerTrusted(X509Certificate[] chain, String authType) throws java.security.cert.CertificateException {
		}

		public X509Certificate[] getAcceptedIssuers() {
			return null;
		}
	}

	public void setKeyStore(String keyStorePath) {
		m_keyStore = keyStorePath;
	}

	public void setKeyPassphrase(String keyPassphrase) {
		m_keyPassphrase = keyPassphrase;
	}

	public Response postRestAPIResponseWithParams(Form form) throws DDTFrameworkException {
		Response clientPostResponse = null;

		try {
			WebClient webClient = WebClient.create(m_restUri);
			addX509TrustManager(webClient);

			// Post API
			m_logger.debug("postRestAPI Send Post");

			clientPostResponse = webClient.acceptLanguage("en-US", "en;q=0.8").type(MediaType.APPLICATION_FORM_URLENCODED_TYPE).accept(MediaType.APPLICATION_FORM_URLENCODED_TYPE).headers(m_restHeaders).form(form);

			webClient.close();

			return clientPostResponse;
		} catch (Exception ex) {
			throw new DDTFrameworkException(TestRestAPI.class, "An unexpected error occurred while invoking postRestAPIResponse TestRestAPI service.", ex);
		}
	}

	public Response deleteRestAPIResponse() throws DDTFrameworkException {
		Response clientPostResponse = null;

		try {
			WebClient webClient = WebClient.create(m_restUri);
			addX509TrustManager(webClient);
			m_logger.debug("postRestAPI Send Delete");
			clientPostResponse = webClient.acceptLanguage("en-US", "en;q=0.8").type(MediaType.APPLICATION_JSON_TYPE).accept(MediaType.APPLICATION_JSON_TYPE).headers(m_restHeaders).delete();
			webClient.close();

			return clientPostResponse;
		} catch (Exception ex) {
			throw new DDTFrameworkException(TestRestAPI.class, "An unexpected error occurred while invoking postRestAPIResponse TestRestAPI service.", ex);
		}
	}
}

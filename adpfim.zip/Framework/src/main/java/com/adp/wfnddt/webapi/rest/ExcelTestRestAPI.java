package com.adp.wfnddt.webapi.rest;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.HashMap;

import javax.ws.rs.core.MultivaluedMap;

import org.apache.poi.ss.usermodel.Sheet;

import com.adp.wfnddt.core.DDTFrameworkException;
import com.adp.wfnddt.excelcomparison.ExcelUtil;

public class ExcelTestRestAPI extends TestRestAPI {

	private HashMap<Integer, HashMap<String, String>> requestExcelData = new HashMap<>();
	private HashMap<Integer, HashMap<String, String>> responseExcelData = new HashMap<>();

	public ExcelTestRestAPI(String p_restUri, MultivaluedMap<String, String> p_restHeaders, String p_jsonFileRequest) {
		super(p_restUri, p_restHeaders, p_jsonFileRequest);
	}

	public ExcelTestRestAPI(String p_restUri, MultivaluedMap<String, String> p_restHeaders, String p_jsonFileRequest, String p_jsonFileResponse) {
		super(p_restUri, p_restHeaders, p_jsonFileRequest, p_jsonFileResponse);
	}

	public HashMap<Integer, String> excelGetRestAPIJSONCompare() throws DDTFrameworkException {
		HashMap<Integer, String> responseVals = new HashMap<>();

		HashMap<Integer, HashMap<String, String>> excelData = responseExcelData;
		
		if (requestExcelData == null) {
			excelData = responseExcelData;
		}

		for (Integer row : excelData.keySet()) {
			if (responseExcelData != null && responseExcelData.containsKey(row))
				super.setReplaceBodyValues(responseExcelData.get(row));

			if (responseExcelData != null && responseExcelData.containsKey(row))
				super.setReplaceResponseBodyValues(responseExcelData.get(row));

			responseVals.put(row, super.getRestAPIJSONCompare());
		}
		return responseVals;
	}

	public HashMap<Integer, String> excelPostAndGetObjectValues(String p_FindObject) throws DDTFrameworkException {
		// Call the Post service and get object value
		HashMap<Integer, String> responseVals = new HashMap<>();

		HashMap<Integer, HashMap<String, String>> excelData = requestExcelData;
		if (requestExcelData == null) {
			excelData = responseExcelData;
		}

		for (Integer row : excelData.keySet()) {
			if (requestExcelData != null && requestExcelData.containsKey(row))
				super.setReplaceBodyValues(requestExcelData.get(row));

			if (responseExcelData != null && responseExcelData.containsKey(row))
				super.setReplaceResponseBodyValues(responseExcelData.get(row));

			responseVals.put(row, super.postAndGetObjectValue(p_FindObject));
		}
		return responseVals;
	}

	public HashMap<Integer, String> excelPostRestAPI() throws DDTFrameworkException {
		// Call the Post service and get object value
		HashMap<Integer, String> responseVals = new HashMap<>();

		HashMap<Integer, HashMap<String, String>> excelData = requestExcelData;
		if (requestExcelData == null) {
			excelData = responseExcelData;
		}

		for (Integer row : excelData.keySet()) {
			if (requestExcelData != null && requestExcelData.containsKey(row))
				super.setReplaceBodyValues(requestExcelData.get(row));

			if (responseExcelData != null && responseExcelData.containsKey(row))
				super.setReplaceResponseBodyValues(responseExcelData.get(row));

			responseVals.put(row, super.postRestAPI());
		}
		return responseVals;
	}

	public HashMap<Integer, String> excelPostRestAPIJSONCompare() throws DDTFrameworkException {
		// Call the Post service and get object value
		HashMap<Integer, String> responseVals = new HashMap<>();

		HashMap<Integer, HashMap<String, String>> excelData = requestExcelData;
		if (requestExcelData == null) {
			excelData = responseExcelData;
		}

		for (Integer row : excelData.keySet()) {
			if (requestExcelData != null && requestExcelData.containsKey(row))
				super.setReplaceBodyValues(requestExcelData.get(row));

			if (responseExcelData != null && responseExcelData.containsKey(row))
				super.setReplaceResponseBodyValues(responseExcelData.get(row));

			responseVals.put(row, super.postRestAPIJSONCompare());
		}
		return responseVals;
	}

	public void setRequestExcelData(String ExcelFilePath, String RequestDataSheetName, String ExcelRowRange, String JSONRequestFileLocation) throws FileNotFoundException, DDTFrameworkException {
		// Get request data from excel as HashMap
		requestExcelData = storeExcelRowDatawithColumnName(ExcelFilePath, RequestDataSheetName, ExcelRowRange);
		this.isExcel = true;
	}

	public void setResponseExcelData(String ExcelFilePath, String ResponseDataSheetName, String ExcelRowRange, String JSONResponseFileLocation) throws FileNotFoundException, DDTFrameworkException {
		// Get request data from excel as HashMap
		responseExcelData = storeExcelRowDatawithColumnName(ExcelFilePath, ResponseDataSheetName, ExcelRowRange);
		this.isExcel = true;
	}

	private HashMap<Integer, HashMap<String, String>> storeExcelRowDatawithColumnName(String ExcelFilePath, String ExcelSheetName, String DataRowsRange) throws FileNotFoundException {
		HashMap<Integer, HashMap<String, String>> excelDataMap = new HashMap<>();
		HashMap<String, String> DatawithColumnNames = new HashMap<>();

		FileInputStream excelFilePath = new FileInputStream(ExcelFilePath);
		ExcelUtil excelutil = new ExcelUtil(excelFilePath);
		excelutil.setSheet(ExcelSheetName);
		Sheet sheetObj = excelutil.getSheetObj();

		// Store the row numbers in array list
		if (DataRowsRange.equalsIgnoreCase("ALL")) {
			int rowcount = sheetObj.getLastRowNum();
			for (int iRow = 1; iRow <= rowcount; iRow++) {
				DatawithColumnNames = excelutil.getRowDataWithHeaders(iRow);
				excelDataMap.put(iRow, DatawithColumnNames);
			}
		} else {
			String[] DataRowsArr = DataRowsRange.split(",");
			for (int iRow = 0; iRow <= DataRowsArr.length - 1; iRow++) {
				if (DataRowsArr[iRow].contains("-")) {
					String[] RowArr = DataRowsArr[iRow].split("-");
					int iStartRow = Integer.parseInt(RowArr[0].trim());
					int iEndRow = Integer.parseInt(RowArr[1].trim());
					for (int intR = 0; intR <= iEndRow - iStartRow; intR++) {
						DatawithColumnNames = excelutil.getRowDataWithHeaders((iStartRow + intR));
						excelDataMap.put(iStartRow + intR, DatawithColumnNames);
					}
				} else if (isInteger(DataRowsArr[iRow])) {
					DatawithColumnNames = excelutil.getRowDataWithHeaders(Integer.parseInt(DataRowsArr[iRow].trim()));
					excelDataMap.put(Integer.parseInt(DataRowsArr[iRow].trim()), DatawithColumnNames);
				}
			}
		}
		return excelDataMap;
	}

	private static boolean isInteger(String str) {
		try {
			Integer.parseInt(str);
			return true;
		} catch (NumberFormatException nfe) {
			return false;
		}
	}

}

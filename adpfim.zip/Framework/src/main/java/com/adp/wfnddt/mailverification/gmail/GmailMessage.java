package com.adp.wfnddt.mailverification.gmail;

public class GmailMessage {
	private String messageBody;

	public String getMessageBody() {
		return messageBody;
	}

	public void setMessageBody(String messageBody) {
		this.messageBody = messageBody;
	}
}

package com.adp.wfnddt.excelcomparison;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.ss.util.CellAddress;
import org.apache.poi.ss.util.NumberToTextConverter;

import com.adp.wfnddt.core.DDTLoggerManager;
import com.google.common.primitives.Ints;

public class ExcelCompareUtil {

    private boolean		     m_breakOnFirstMismatch;
    private boolean		     m_trimCellValues;
    private SimpleDateFormat	     m_dateTimeFormat;
    private String[]		     m_excludeCellValues;
    private int[]		     m_excludeColumnIndexes;
    private CellAddress[]	     m_excludeCellAddresses;
    private int[]		     m_excludeRowIndexes;
    private List<ExcelCompareResult> m_fileCompareResultList;
    private String[]		     m_sheetIndexes		= { "1" };
    private static Logger	     m_logger			= DDTLoggerManager.getLogger(ExcelCompareUtil.class);
    private static int		     m_sheet_number;

    // These parmeter are to validate the differences
    private int[]		     m_ColumnAddressesForChangeInPercentage;
    private Float		     m_expectedChangePercentage	= null;
    private String		     m_logPercentageChangeDetails;
    private String		     m_RTPReports;

    Workbook			     workbook1;
    Workbook			     workbook2;
    Sheet			     sheet1;
    Sheet			     sheet2;

    public ExcelCompareUtil() {

	this.m_breakOnFirstMismatch = false;
	this.m_trimCellValues = false;
	m_excludeCellValues = new String[] {};
	m_excludeColumnIndexes = new int[] {};
	m_excludeCellAddresses = new CellAddress[] {};
	m_excludeRowIndexes = new int[] {};
	m_dateTimeFormat = new SimpleDateFormat("MM/dd/yyyy");
	m_fileCompareResultList = new ArrayList<ExcelCompareResult>();

	m_logger.setLevel(Level.OFF);
    }

    public void enableLog() {
	m_logger.setLevel(Level.INFO);
    }

    public void enableLog(Level logLevel) {
	m_logger.setLevel(logLevel);
    }

    public void trimCellValues(boolean flag) {
	this.m_trimCellValues = flag;
    }

    public void dateTimeFormat(SimpleDateFormat format) {
	this.m_dateTimeFormat = format;
    }

    public void breakOnFirstMismatch(boolean flag) {
	this.m_breakOnFirstMismatch = flag;
    }

    public List<ExcelCompareResult> getFileCompareResultList() {
	return m_fileCompareResultList;
    }

    public void setFileCompareResultList(List<ExcelCompareResult> fileCompareResultList) {
	this.m_fileCompareResultList = fileCompareResultList;
    }

    public void excludeCellAddresses(CellAddress... cellAddress) {
	this.m_excludeCellAddresses = cellAddress;
    }

    public void excludeColumns(int... columnIndexes) {
	this.m_excludeColumnIndexes = columnIndexes;
    }

    public void excludeRows(int... rowIndexes) {
	this.m_excludeRowIndexes = rowIndexes;
    }

    public void excludeColumns(Integer... columnIndexes) {
	// Converting Integer[] to int[]
	List<Integer> listInteger = Arrays.asList(columnIndexes);
	// Below line works with Java 8 only
	int[] intArray = listInteger.stream().mapToInt(i -> i).toArray();

	this.m_excludeColumnIndexes = intArray;
    }

    public void excludeRows(Integer... rowIndexes) {
	// Converting Integer[] to int[]
	List<Integer> listInteger = Arrays.asList(rowIndexes);
	// Below line works with Java 8 only
	int[] intArray = listInteger.stream().mapToInt(i -> i).toArray();

	this.m_excludeRowIndexes = intArray;
    }

    public void excludeContent(String... regexs) {
	this.m_excludeCellValues = regexs;
    }

    public boolean compareExcelFileContents(File p_xslxFile1, File p_xslxFile2) throws Exception {
	boolean bResultAllSheets = true;
	FileInputStream excellFile1 = null;
	FileInputStream excellFile2 = null;
	workbook1 = null;
	workbook2 = null;

	try {

	    m_logger.debug("File 1 : " + p_xslxFile1);
	    m_logger.debug("File 2 : " + p_xslxFile2);

	    excellFile1 = new FileInputStream(p_xslxFile1);
	    excellFile2 = new FileInputStream(p_xslxFile2);

	    // Create Workbook instance holding reference to .xlsx file
	    workbook1 = WorkbookFactory.create(excellFile1);
	    workbook2 = WorkbookFactory.create(excellFile2);

	    // BLANK meant for ALL sheets, Replace it with -1
	    if (m_sheetIndexes.length == 1 && m_sheetIndexes[0].equals(""))
		m_sheetIndexes[0] = "-1";

	    int[] arrayInt = null;
	    try {
		// Convert String[] to int[]
		arrayInt = Arrays.stream(m_sheetIndexes).mapToInt(Integer::parseInt).toArray();
	    } catch (java.lang.NumberFormatException exception) {
		// if Indexes are Not Numeric
		m_logger.debug("Sheet Index is NOT By Number, Considering Sheet Index By Name");
	    }

	    if (arrayInt != null) {
		// Get Sheets By Index As Number
		List<Integer> listInteger = Ints.asList(arrayInt);
		int iSheetCount = workbook1.getNumberOfSheets();
		for (int indexZeroBased = 0; indexZeroBased < iSheetCount; indexZeroBased++) {
		    m_sheet_number = indexZeroBased + 1;
		    // -1 meant for ALL sheets
		    if (listInteger.contains(m_sheet_number) || listInteger.contains(-1)) {
			bResultAllSheets = bResultAllSheets & compareTwoSheetsAndWriteToHTML(indexZeroBased);
		    }
		}

	    } else {
		// Get Sheets By Index As Name
		for (Object sheetName : m_sheetIndexes) {
		    bResultAllSheets = bResultAllSheets & compareTwoSheetsAndWriteToHTML(String.valueOf(sheetName));
		}
	    }
	} catch (Exception e) {
	    throw e;
	} finally {
	    // close files
	    workbook1.close();
	    workbook2.close();

	    // close input streams
	    excellFile1.close();
	    excellFile2.close();
	}
	return bResultAllSheets;

    }

    public boolean compareTwoSheetsAndWriteToHTML(Object sheetNumberOrSheetName) {
	boolean bCurrentWorkSheetMatches = false;
	sheet1 = null;
	sheet2 = null;

	if (sheetNumberOrSheetName instanceof String) {
	    sheet1 = workbook1.getSheet(String.valueOf(String.valueOf(sheetNumberOrSheetName)));
	    sheet2 = workbook2.getSheet(String.valueOf(String.valueOf(sheetNumberOrSheetName)));
	} else if (isNumber(String.valueOf(sheetNumberOrSheetName))) {
	    sheet1 = workbook1.getSheetAt(((Integer) sheetNumberOrSheetName).intValue());
	    sheet2 = workbook2.getSheetAt(((Integer) sheetNumberOrSheetName).intValue());
	}

	// Compare sheets
	bCurrentWorkSheetMatches = compareTwoSheets(sheet1, sheet2);

	// Start of Logging & Reporting
	String sheetName = sheet1.getSheetName();
	String expectedResult = "Sheet: " + sheetName + " : content matches with base file";
	String actualResult = "Sheet: " + sheetName + " : content does NOT match with base file";

	if (bCurrentWorkSheetMatches)
	    m_logger.info(expectedResult);
	else
	    m_logger.warn(actualResult);

	ExcelCompareResult currentRowResult = new ExcelCompareResult();
	currentRowResult.setLocationOfText(sheetName);
	currentRowResult.setExpectedText(expectedResult);
	currentRowResult.setActualText(actualResult);
	currentRowResult.setCompareStatus(bCurrentWorkSheetMatches);
	m_fileCompareResultList.add(currentRowResult);

	// End of Logging & Reporting

	return bCurrentWorkSheetMatches;
    }

    // Compare Two Sheets
    public boolean compareTwoSheets(Sheet p_sheet1, Sheet p_sheet2) {

	int firstRow1 = p_sheet1.getFirstRowNum();
	int lastRow1 = p_sheet1.getLastRowNum();
	boolean equalSheets = true;

	for (int i = firstRow1; i <= lastRow1; i++) {

	    Row row1 = p_sheet1.getRow(i);
	    Row row2 = p_sheet2.getRow(i);

	    if (!compareTwoRows(row1, row2)) {
		equalSheets = false;
		m_logger.debug("Row " + i + " - NOT Equal");
		if (m_breakOnFirstMismatch)
		    break;
	    } else {
		m_logger.debug("Row " + i + " - Equal");
	    }

	}
	return equalSheets;
    }

    // Compare Two Rows
    public boolean compareTwoRows(Row p_row1, Row p_row2) {

	if ((p_row1 == null) && (p_row2 == null)) {
	    return true;
	} else if ((p_row1 == null) || (p_row2 == null)) {
	    return false;
	} else if (contains(m_excludeRowIndexes, (p_row1.getRowNum() + 1))) {
	    return true;
	}
	int firstCell1 = p_row1.getFirstCellNum();
	int lastCell1 = p_row1.getLastCellNum();
	int lastCell2 = p_row2.getLastCellNum();

	int rowNumber = p_row1.getRowNum() + 1;

	boolean equalRows = true;
	if (lastCell1 != lastCell2) {
	    m_logger.info("Column count does not match. [Row: " + rowNumber + "][Source-Last Cell Number : " + lastCell1 + "][Destination Last Cell Number : " + lastCell2 + "]");
	    ExcelCompareResult currentRowResult = new ExcelCompareResult();
	    currentRowResult.setLocationOfText(String.valueOf("Row: " + rowNumber) + " Column count does not match");
	    currentRowResult.setExpectedText(String.valueOf(lastCell1));
	    currentRowResult.setActualText(String.valueOf(lastCell2));
	    currentRowResult.setCompareStatus(false);
	    m_fileCompareResultList.add(currentRowResult);
	    return false;

	}
	// Compare all cells in a row
	for (int i = firstCell1; i < lastCell1; i++) {

	    Cell cell1 = p_row1.getCell(i);
	    Cell cell2 = p_row2.getCell(i);

	    m_logPercentageChangeDetails = "";
	    boolean bCellCompare = true;

	    bCellCompare = compareTwoCellsAsStringValues(cell1, cell2);

	    if (!(cell1 == null)) {

		// Start of Reporting code
		if (!bCellCompare) {
		    equalRows = false;

		    String cellValue1 = getCellValueAsString(cell1);
		    String cellValue2 = getCellValueAsString(cell2);
		    String cellLocation = cell1.getAddress().toString();
		    String sheetName = cell1.getSheet().getSheetName();

		    String logCellLocation = sheetName + " - Cell : " + cellLocation + "," + m_logPercentageChangeDetails;

		    ExcelCompareResult currentRowResult = new ExcelCompareResult();
		    currentRowResult.setLocationOfText(logCellLocation);
		    currentRowResult.setExpectedText(cellValue1);
		    currentRowResult.setActualText(cellValue2);
		    currentRowResult.setCompareStatus(bCellCompare);
		    m_fileCompareResultList.add(currentRowResult);

		    m_logger.error("[ " + sheetName + " : " + cellLocation + " ] -- NOT matched --");
		    m_logger.error("Expected Value [" + cellValue1 + "]");
		    m_logger.error("Actual Value   [" + cellValue2 + "]");

		    if (i != lastCell1) {
			if (m_breakOnFirstMismatch)
			    break;
		    }
		}
		// End of Reporting code

	    }
	}
	return equalRows;
    }

    public boolean compareTwoCellsAsStringValues(Cell p_cell1, Cell p_cell2) {
	if ((p_cell1 == null) && (p_cell2 == null)) {
	    return true;
	} else if ((p_cell1 == null) || (p_cell2 == null)) {
	    return false;
	}
	m_logger.debug("Verifying " + p_cell1.getAddress());
	String cellValue1 = getCellValueAsString(p_cell1);
	String cellValue2 = getCellValueAsString(p_cell2);
	boolean ignoreCell = true;
	if (contains(m_excludeColumnIndexes, p_cell1.getColumnIndex()))
	    return ignoreCell;
	if (contains(m_excludeCellAddresses, p_cell1.getAddress()))
	    return ignoreCell;
	if (contains(new String[] { "[IGNORE]" }, cellValue1))
	    return ignoreCell;
	if (regExmatch(m_excludeCellValues, cellValue1))
	    return ignoreCell;
	if (null != this.m_ColumnAddressesForChangeInPercentage && this.m_ColumnAddressesForChangeInPercentage.length > 0) {
	    if (contains(m_ColumnAddressesForChangeInPercentage, p_cell1.getColumnIndex())) {
		// if Number, compare % change
		if (isNumber(cellValue1))
		    return compareChangeInPercentage(cellValue1, cellValue2);
	    }
	}
	boolean equalCells = false;
	if (null != m_RTPReports && m_RTPReports.equals("YES")) {
	    equalCells = rtpCellValidation(cellValue1, cellValue2);
	} else {
	    if (cellValue1.equals(cellValue2)) {
		equalCells = true;
	    }
	}
	return equalCells;
    }

    public String getCellValueAsString(Cell p_cell) {
	String cellValue = null;
	switch (p_cell.getCellType()) {
	case FORMULA:
	    cellValue = p_cell.getCellFormula();
	    break;
	case NUMERIC:
	    if (DateUtil.isCellDateFormatted(p_cell)) {
		Date date = p_cell.getDateCellValue();
		cellValue = m_dateTimeFormat.format(date);
		m_logger.debug("Cell " + p_cell.getAddress() + " Date Value:" + cellValue);
	    } else {
		cellValue = String.valueOf(p_cell.getNumericCellValue()); // Appending decimals.
		cellValue = NumberToTextConverter.toText(p_cell.getNumericCellValue());
	    }
	    break;
	case STRING:
	    cellValue = p_cell.getStringCellValue();
	    break;
	case BLANK:
	    cellValue = ""; // null or "" ?
	    break;
	case BOOLEAN:
	    cellValue = String.valueOf(p_cell.getBooleanCellValue());
	    break;
	case ERROR:
	    cellValue = String.valueOf(p_cell.getErrorCellValue());
	    break;
	default:
	    cellValue = p_cell.getStringCellValue();
	    break;
	}

	if (m_trimCellValues)
	    return cellValue.trim();
	else
	    return cellValue;

    }

    private static boolean contains(Object[] p_array, Object p_value) {
	boolean flag = false;
	for (Object obj : p_array) {
	    if (obj.equals(p_value)) {
		flag = true;
		return flag;
	    }
	}
	return flag;
    }

    private static boolean regExmatch(String[] p_array, String p_value) {
	boolean flag = false;
	for (String objRegEx : p_array) {
	    if (p_value.matches(objRegEx)) {
		flag = true;
		return flag;
	    }
	}
	return flag;
    }

    private static boolean contains(int[] p_iArray, int p_value) {
	boolean flag = false;
	for (int i : p_iArray) {
	    if (i == p_value) {
		flag = true;
		return flag;
	    }
	}
	return flag;
    }

    public void setSheetIndexes(String... pSheetIndexes) {
	this.m_sheetIndexes = pSheetIndexes;
    }

    // -- This below methods are to support for verification of percentage
    // change in cell value ------ //
    public int[] getColumnIndexesForChangeInPercentage() {
	return m_ColumnAddressesForChangeInPercentage;
    }

    public void setColumnIndexesForChangeInPercentage(int... m_ColumnIndexesForChangePercentageValidations) {
	this.m_ColumnAddressesForChangeInPercentage = m_ColumnIndexesForChangePercentageValidations;
    }

    public float getExpectedChangePercentage() {
	return m_expectedChangePercentage;
    }

    public void setExpectedChangePercentage(float m_expectedChangePercentage) {
	this.m_expectedChangePercentage = m_expectedChangePercentage;
    }

    public String getRTPReports() {
	return m_RTPReports;
    }

    public void setRTPReports(String rtpReports) {
	this.m_RTPReports = rtpReports;
    }

    public boolean compareChangeInPercentage(String cellValue1, String cellValue2) {
	boolean bCellValueWithinRange = false;

	Float m_actualValue;
	Float m_obtainedValue;

	try {
	    m_actualValue = Float.parseFloat(cellValue1.replaceAll(",", ""));
	    m_obtainedValue = Float.parseFloat(cellValue2.replaceAll(",", ""));
	    float percentage = (float) ((m_obtainedValue * 100) / m_actualValue);
	    float m_actualChangePercentage = percentage - 100;
	    m_actualChangePercentage = (float) (Math.round(m_actualChangePercentage * 100.0) / 100.0);
	    int result = Float.compare(m_expectedChangePercentage, m_actualChangePercentage);
	    bCellValueWithinRange = result >= 0;
	    m_logPercentageChangeDetails = "Expected % " + m_expectedChangePercentage + ", Actual   % " + m_actualChangePercentage;
	    if (!bCellValueWithinRange) {
		m_logger.error(m_logPercentageChangeDetails);
	    }

	} catch (java.lang.NumberFormatException e) {
	    m_logger.error("Cell content is NOT a number");
	}

	return bCellValueWithinRange;
    }

    public boolean isNumber(String string) {
	if (string.trim().equals(""))
	    return false;
	// assuming integer is in decimal number system
	for (int i = 0; i < string.length(); i++) {
	    if (i == 0 && string.charAt(i) == '-')
		continue;
	    else if (i > 0 && string.charAt(i) == '.')
		continue;
	    else if (i > 0 && string.charAt(i) == ',')
		continue;
	    if (!Character.isDigit(string.charAt(i)))
		return false;
	}
	return true;
    }

    public boolean rtpCellValidation(String cellValue1, String cellValue2) {
	boolean equalCells = false;
	String[] stringNewlines = cellValue1.split("\n");
	List<String> li = new ArrayList<>();
	for (int i = 0; i < stringNewlines.length; i++) {
	    String s = stringNewlines[i];
	    String[] sa = s.split("\\s");
	    if (!sa[sa.length - 1].equals("0.00") && !sa[0].equals("Clock:")) {
		li.add(s);
	    }
	}
	StringBuilder appendCellValue = new StringBuilder();
	for (int i = 0; i < li.size(); i++) {
	    String s = li.get(i);
	    appendCellValue.append(s);
	    if (i != li.size() - 1)
		appendCellValue.append("\n");
	}
	if (appendCellValue.toString().equals(cellValue2)) {
	    return true;
	} else if (cellValue1.equals(cellValue2)) {
	    return true;
	} else if (cellValue1.equals("0.0")) {
	    return true;
	}
	return equalCells;
    }
    // -------------------------------------------------------------------------------------------

}

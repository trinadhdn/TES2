package com.adp.wfnddt.pdfcomparison;

public class PDFImageCompareResult {
	int comparePageNo;
	String compareDiffImageFileName;
	boolean compareStatus;

	public int getComparePageNo() {
		return comparePageNo;
	}

	public void setComparePageNo(int comparePageNo) {
		this.comparePageNo = comparePageNo;
	}

	public String getCompareDiffImageFileName() {
		return compareDiffImageFileName;
	}

	public void setCompareDiffImageFileName(String compareDiffImageFileName) {
		this.compareDiffImageFileName = compareDiffImageFileName;
	}

	public boolean isCompareStatus() {
		return compareStatus;
	}

	public void setCompareStatus(boolean compareStatus) {
		this.compareStatus = compareStatus;
	}

}

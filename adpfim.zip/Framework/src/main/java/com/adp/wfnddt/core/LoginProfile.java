/**
 * 
 */
package com.adp.wfnddt.core;

/**
 * @author wiermanp
 *
 */
public class LoginProfile {
	public class UserCredential {
		private String m_userID;
		private String m_password;
		
		public UserCredential(String p_userID, String p_password) {
			m_userID = p_userID;
			m_password = p_password;
		}
		
		public String getUserID() { return m_userID; }
		public String getPassword() { return m_password; }
	}
	
	private String m_url;
	private String m_clientID = null;
	private String m_sellingRegion = null;
	private String m_vpdKey = null;
	private UserCredential m_practCredential = null;
	private UserCredential m_eeCredential = null;
	private UserCredential m_mgrCredential = null;
	private UserCredential m_uaCredential = null;
	
	public void setURL(String p_url) {
		m_url = p_url;
		return;
	}
	
	public String getURL() {
		return m_url;
	}
	
	public void setClientID(String p_clientID) {
		m_clientID = p_clientID;
		return;
	}
	
	public String getClientID() {
		return m_clientID;
	}
	
	public void setSellingRegion(String p_sellingRegion) {
		m_sellingRegion = p_sellingRegion;
		return;
	}
	
	public String getSellingRegion() {
		return m_sellingRegion;
	}
	
	public void setVPDKey(String p_vpdKey) {
		m_vpdKey = p_vpdKey;
		return;
	}
	
	public String getVPDKey() {
		return m_vpdKey;
	}
	
	public UserCredential getPractUserCredential() {
		return m_practCredential;
	}
	
	public UserCredential getEEUserCredential() {
		return m_eeCredential;
	}
	
	public UserCredential getMgrUserCredential() {
		return m_mgrCredential;
	}
	
	public UserCredential getUAUserCredential() {
		return m_uaCredential;
	}
	
	public void setPractUserCredentials(UserCredential p_userCred) {
		m_practCredential = p_userCred;
		return;
	}
	public void setEEUserCredentials(UserCredential p_userCred) {
		m_eeCredential = p_userCred;
		return;
	}
	public void setMgrUserCredentials(UserCredential p_userCred) {
		m_mgrCredential = p_userCred;
		return;
	}
	public void setUAUserCredentials(UserCredential p_userCred) {
		m_uaCredential = p_userCred;
		return;
	}

}

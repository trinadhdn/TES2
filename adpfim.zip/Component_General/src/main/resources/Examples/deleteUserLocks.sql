delete from data_lock;
commit;
Select * from {schema}.DEPOSIT where VPD_KEY = '{vpdKey}';

Select * from {schema}.BENEFIT_PLAN where VPD_KEY = '{vpdKey}';

Delete from WFN10SCH00028.DEPOSIT where VPD_KEY = '{vpdKey}' and
    OID = '9876:540' and 
      (EFF_DATE = TO_DATE('1/1/2017', 'MM/DD/YYYY') or
       EFF_DATE = TO_DATE('2/1/2017', 'MM/DD/YYYY') or
       EFF_DATE = TO_DATE('3/1/2017', 'MM/DD/YYYY'));
       
Insert into {schema}.DEPOSIT (VPD_KEY, OID, EFF_DATE, EFF_DATE_END, PAID, 
    ABA_TRANSIT_NO, ACCOUNT_NO, FULL_DEPOSIT, DEPOSIT_POSITION_OID, VOLUNTARY_DED_OID, 
    F_DBLOAD, ACTIVE, VERSION, MODIFIED_BY_USER, MODIFIED_ON, 
    F_BONUS, F_PERCENT_NET)
\ --This character allows for multi-inserts to make it easier!
'{vpdKey}', '9876:540', TO_DATE('2/1/2017', 'MM/DD/YYYY'), TO_DATE('12/31/4000', 'MM/DD/YYYY'), '71674:1248','111111118', '123450', 0, 'SYS:4:3723', '71674:1252', 1, 1, 0, 'SUPERUSER', TO_DATE('2/22/2017 10:01:52 AM', 'MM/DD/YYYY HH:MI:SS AM'), 0, 0
'{vpdKey}', '9876:540', TO_DATE('3/1/2017', 'MM/DD/YYYY'), TO_DATE('12/31/4000', 'MM/DD/YYYY'), '71674:1248','111111118', '123450', 0, 'SYS:4:3723', '71674:1252', 1, 1, 0, 'SUPERUSER', TO_DATE('2/22/2017 10:01:52 AM', 'MM/DD/YYYY HH:MI:SS AM'), 0, 0
/
    
Insert into {schema}.DEPOSIT
   (VPD_KEY, OID, EFF_DATE, EFF_DATE_END, PAID, 
    ABA_TRANSIT_NO, ACCOUNT_NO, FULL_DEPOSIT, DEPOSIT_POSITION_OID, VOLUNTARY_DED_OID, 
    F_DBLOAD, ACTIVE, VERSION, MODIFIED_BY_USER, MODIFIED_ON, 
    F_BONUS, F_PERCENT_NET)
 Values
   ('{vpdKey}', '9876:540', TO_DATE('1/1/2017', 'MM/DD/YYYY'), TO_DATE('12/31/4000', 'MM/DD/YYYY'), '71674:1248', 
    '111111118', '123450', 0, 'SYS:4:3723', '71674:1252', 
    1, 1, 0, 'SUPERUSER', TO_DATE('2/22/2017 10:01:52 AM', 'MM/DD/YYYY HH:MI:SS AM'), 
    0, 0);

Update {schema}.DEPOSIT Set F_BONUS = 1
  where VPD_KEY = '{vpdKey}' and
    	OID = '9876:540' and EFF_DATE = TO_DATE('1/1/2017', 'MM/DD/YYYY');

Commit;

Execute {schema}.sp_dummy('able', 5, 7.23, TO_DATE('2/1/2017', 'MM/DD/YYYY'));
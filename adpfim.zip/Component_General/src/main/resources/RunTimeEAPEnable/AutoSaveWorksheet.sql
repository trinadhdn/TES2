exec sp_seT_vpd_Ctx('{vpdKey}','adp',spv_prod_locale=>'UN');
select * from tl_comp_event_Reco_snap_cmpty
where TL_COMP_EVENT_RECO_SNAP_OID in
(select oid from tl_comp_event_reco_snap where tl_comp_Event_oid in
(select oid from tl_comp_Event where event_name = 'AutoSave Worksheet Test'))
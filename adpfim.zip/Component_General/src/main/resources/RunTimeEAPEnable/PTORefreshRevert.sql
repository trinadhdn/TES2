exec sp_seT_vpd_Ctx('{vpdKey}','adp',spv_prod_locale=>'UN');
DELETE FROM WFN_FEATURE WHERE FEATURE = 'EnhancedTimeOffSetup' and VPD_KEY='{vpdKey}';
commit;
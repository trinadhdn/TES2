exec sp_seT_vpd_Ctx('{vpdKey}','adp',spv_prod_locale=>'UN');
INSERT INTO WFN_FEATURE VALUES ('{vpdKey}','CompMgntRefresh');
commit;
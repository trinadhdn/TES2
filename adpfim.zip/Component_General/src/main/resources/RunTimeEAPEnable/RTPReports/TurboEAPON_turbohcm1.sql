exec sp_seT_vpd_Ctx('WNVPD0000067753','adp',spv_prod_locale=>'UN');
INSERT INTO WFN_FEATURE VALUES ('WNVPD0000066738','CalculatePreviewPayrollMicroservice');
commit;
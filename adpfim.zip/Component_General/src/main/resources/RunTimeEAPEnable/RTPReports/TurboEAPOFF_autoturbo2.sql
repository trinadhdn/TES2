exec sp_seT_vpd_Ctx('WNVPD0000066738','adp',spv_prod_locale=>'UN');
DELETE FROM WFN_FEATURE WHERE FEATURE='CalculatePreviewPayrollMicroservice';
commit;
call sp_set_vpd_ctx('{vpdKey}','SUPERUSER'); 
update BN_OE_DEDICATD_SUPRT_RQST_INFO set MODIFIED_ON = to_date( to_char(SYSDATE-7), 'dd/mm/yy') where VPD_KEY='{vpdKey}'; 
commit;


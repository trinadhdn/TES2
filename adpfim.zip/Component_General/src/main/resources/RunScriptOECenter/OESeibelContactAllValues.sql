call sp_set_vpd_ctx('{vpdKey}','SUPERUSER'); 
update BN_OE_SIEBEL_SUPPORT_INFO set MODIFIED_ON = sysdate , EMAIL = 'OEAutomation@auto.com' , FIRST_NAME = 'Automation' , LAST_NAME = 'Client' , PROJECT_TEAM_CONTACT_EXISTS = '1' , OE_SUPPORT_CATEGORY = 'Annual OE Support' where VPD_KEY='{vpdKey}';
commit;


exec {schema}.sp_set_vpd_ctx('{vpdKey}','SUPERUSER'); 
UPDATE acs_sia SET hiredate = sysdate-1 WHERE client_oid = 'G3Z5WZC2G5QR9PPH' AND user_oid = 'G3JEYXGSED53XE4T';
commit;


delete from {schema}.MC_ALERT_USER_READ where client_oid = 'G32SCWSFFTKRVK36';
delete from {schema}.MC_ALERT_USER_READ_HISTORY  where client_oid = 'G32SCWSFFTKRVK36';
delete from {schema}.MC_CLIENT_ALERT  where client_oid = 'G32SCWSFFTKRVK36';
delete from {schema}.MC_MESSAGE_INSTANCE  where client_oid = 'G32SCWSFFTKRVK36';
delete from {schema}.MC_MESSAGE_INSTANCE_ARCH  where client_oid = 'G32SCWSFFTKRVK36';
delete from {schema}.MC_MESSAGE_INSTANCE_PURGE  where client_oid = 'G32SCWSFFTKRVK36';
delete from {schema}.MC_MESSAGE_USER  where client_oid = 'G32SCWSFFTKRVK36';
delete from {schema}.MC_MESSAGE_USER_ARCH  where client_oid = 'G32SCWSFFTKRVK36';
delete from {schema}.MC_MESSAGE_USER_INVALID_TYPES  where client_oid = 'G32SCWSFFTKRVK36';
delete from {schema}.MC_MESSAGE_USER_PURGE  where client_oid = 'G32SCWSFFTKRVK36';
delete from {schema}.MC_RECIPIENT_CONTENT  where client_oid = 'G32SCWSFFTKRVK36';
delete from {schema}.MC_RECIPIENT_CONTENT_HISTORY  where client_oid = 'G32SCWSFFTKRVK36';

commit;

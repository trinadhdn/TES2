call sp_set_vpd_ctx('AWNVPD0000068327_USXXXXWFN20','SUPERUSER'); 
select count(*) From Overtime Pay EditTest
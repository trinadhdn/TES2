call sp_set_vpd_ctx('AWNVPD0000072452_USXXXXWFN21SNAP','SUPERUSER'); 
select count(*) From 401(k) Loans EditTest
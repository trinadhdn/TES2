call sp_set_vpd_ctx('AWNVPD0000072448_USXXXXWFN21SNAP','SUPERUSER'); 
select count(*) From Creditor EditTest
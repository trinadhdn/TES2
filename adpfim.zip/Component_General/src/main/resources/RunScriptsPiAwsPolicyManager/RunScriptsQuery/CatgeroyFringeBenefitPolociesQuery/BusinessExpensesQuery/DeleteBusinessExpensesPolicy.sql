call sp_set_vpd_ctx('AWNVPD0000072450_USXXXXWFN21SNAP','SUPERUSER'); 
select count(*) From Business Expenses EditTest
call sp_set_vpd_ctx('AWNVPD0000072249_USXXXXWFN21SNAP','SUPERUSER'); 
select count(*) From Incentive Stock Options EditTest
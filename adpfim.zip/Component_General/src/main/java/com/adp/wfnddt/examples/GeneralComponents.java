package com.adp.wfnddt.examples;

import com.adp.wfnddt.aspects.Component;
import com.adp.wfnddt.commonmethods.General;
import com.adp.wfnddt.commonmethods.Navigation;
import com.adp.wfnddt.core.DDTComponentBase;
import com.adp.wfnddt.core.DDTController;
import com.adp.wfnddt.core.DDTFrameworkException;
import com.adp.wfnddt.objectmanager.ObjectTypes;
import com.adp.wfnddt.objectmanager.WebLink;
import com.adp.wfnddt.parammanager.ParamManager;
import com.adp.wfnddt.results.DDTResultsReporter;
import java.io.IOException;
import javax.xml.datatype.DatatypeConfigurationException;

public class GeneralComponents extends DDTComponentBase {
	private static final String OR_Path ="/Objects/Feature_Folder/Feature.json";

	public GeneralComponents() throws DDTFrameworkException{
		loadObjectRepository(OR_Path);
	}

	@Component(Name = "Open <FEATURE> Page") //Open page - components and function names are the same
	public void openFeaturePage(ParamManager pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException{
		Navigation navigation = new Navigation();
		navigation.navigateToPage("Setup", "Validation Tables");
		
		new WebLink("CSS:#html id").click();		
	}

	@Component(Name = "Enter Data on <FEATURE> Page",
			Params = {"Button_To_Click|*^*|Required!! Valid Values: AddNew, Delete, Done, AddAnother, Cancel",
					"Code1",
					"CBox|*^*|Valid Values: ON or OFF",
					"Description",
					"Available|*^*|Double List Box left side",
					"Selected|*^*|Double List Box right side",
					"Status|*^*|Valid Values: Active,Inactive",
					"Show Hide Inactive|*^*|Valid Values for toggle: Inactive or Active"}) //spaces are allowed on Params now!
	public void enterDataOnFeaturePage(ParamManager pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException{
		ObjectTypes Page = Browser.Page("Feature Page");

		Page.WebTextBox("Code1").set(pm.Parameter("Code1"));
		Page.WebComboBox("Description_US").select(pm.Parameter("Description"));
		Page.WebCheckBox("Active").setValue(pm.Parameter("CBox"));

		Page.WebRadioButton("Active").click(pm.Parameter("Status"),"Active");
		Page.WebRadioButton("Inactive").click(pm.Parameter("Status"),"Inactive");
		
		Page.WebDoubleListBox("Available").moveValues(pm.Parameter("Available_Companies"),"LEFT"); //Pass second parameter as side the DL is on
		Page.WebDoubleListBox("Selected").moveValues(pm.Parameter("Selected_Companies"),"RIGHT");
		
		Page.WebToggleButton("ShowInactive").set(pm.Parameter("Show Hide Inactive"));

		Page.WebButton("AddNew").click(pm.Parameter("Button_To_Click"));
		Page.WebButton("Delete").click(pm.Parameter("Button_To_Click"));
		Page.WebButton("ShowInactive").click(pm.Parameter("Button_To_Click"));
		Page.WebButton("HideInactive").click(pm.Parameter("Button_To_Click"));
		Page.WebButton("AddAnother").click(pm.Parameter("Button_To_Click"));
		Page.WebButton("Cancel").click(pm.Parameter("Button_To_Click"));
		Page.WebButton("Done").click(pm.Parameter("Button_To_Click"));
	}

	@Component(Name = "Verify Onscreen Message on <FEATURE> Page",
			Params = {"Message_Text"})
	public void verifyOnscreenMessageOnFeaturePage(ParamManager pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException{
		
		General.verifyOnScreenMessageOrExistanceOnPage(pm.Parameter("Message_Text"));
	}
	
	@Component(Name = "Verify Listbox Contents on <FEATURE> Page",
			Params = {"Company",
					"TypeOfTest|*^*|Valid Values: EXACT, PARTIAL, EXACT_ANY_ORDER, DOES_NOT_EXIST"})
	public void verifyListboxContentsOnFeaturePage(ParamManager pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException{
		ObjectTypes Page = Browser.Page("Feature Page");
		DDTResultsReporter results = DDTController.getResultsReporter();
		
		results.startVerificationLogStep();
		Page.WebComboBox("Company").verifyContents(pm.Parameter("Company"), pm.Parameter("TypeOfTest"));
		results.endVerificationLogStep();
	}

	@Component(Name = "Verify Object Properties on <FEATURE> Page",
			Params = {"Code1|*^*|Valid Values: [VERIFY_EDITABLE] , [VERIFY_NOT_EDITABLE]"})
	public void verifyObjectPropertiesOnFeaturePage(ParamManager pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException{
		ObjectTypes Page = Browser.Page("Feature Page");
		DDTResultsReporter results = DDTController.getResultsReporter();
		
		results.startVerificationLogStep();
		Page.WebTextBox("Code1").verifyObjectProperties(pm.Parameter("Code1"));
		results.endVerificationLogStep();
	}

	@Component(Name = "Verify Data on <FEATURE> Page",
			Params = {"Company",
					"Code1",
					"Description",
					"Status|*^*|Valid Values: Active,Inactive"})
	public void verifyDataOnFeaturePage(ParamManager pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException{
		ObjectTypes Page = Browser.Page("Feature Page");
		DDTResultsReporter results = DDTController.getResultsReporter();
		
		results.startVerificationLogStep();
		Page.WebStatic("Company Code").verifyValue(pm.Parameter("Company"));
		Page.WebTextBox("Code1").verifyValue(pm.Parameter("Code1"));
		Page.WebTextBox("Description_US").verifyValue(pm.Parameter("Description"));
		Page.WebRadioButton("Active").verifyValue(pm.Parameter("Status"),"Active");
		Page.WebRadioButton("Inactive").verifyValue(pm.Parameter("Status"),"Inactive");
		results.endVerificationLogStep();

	}
}
/**
 * 
 */
package com.adp.wfnddt.fault;

import com.adp.wfnddt.core.DDTLoggerManager;

/**
 * @author autoxpert
 *
 */
public class DDTComponentException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 7470615243378449613L;

	public DDTComponentException(Class<?> p_class, String p_message) {
        super(p_message);
        DDTLoggerManager.getLogger(p_class).error(p_message);
        return;
    }

	public DDTComponentException(Class<?> p_class, String p_message, Throwable p_cause) {
        super(p_message, p_cause);
        DDTLoggerManager.getLogger(p_class).error(p_message, p_cause);
        return;
    }

}

package com.adp.wfnddt.components.wfnstart;

import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.mail.Address;
import javax.mail.Message;
import javax.mail.Message.RecipientType;
import javax.mail.MessagingException;
import javax.mail.internet.InternetAddress;
import javax.mail.search.ComparisonTerm;
import javax.mail.search.FromStringTerm;
import javax.mail.search.ReceivedDateTerm;
import javax.mail.search.RecipientStringTerm;
import javax.mail.search.SearchTerm;
import javax.xml.datatype.DatatypeConfigurationException;

import org.apache.log4j.Logger;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.adp.wfnddt.aspects.Component;
import com.adp.wfnddt.commonmethods.General;
import com.adp.wfnddt.core.BrowserManager;
import com.adp.wfnddt.core.DDTAssertionError;
import com.adp.wfnddt.core.DDTController;
import com.adp.wfnddt.core.DDTController.E_OSs;
import com.adp.wfnddt.core.DDTController.MailBox;
import com.adp.wfnddt.core.DDTFrameworkException;
import com.adp.wfnddt.core.DDTLoggerManager;
import com.adp.wfnddt.core.GlobalVariables;
import com.adp.wfnddt.core.LoginProfile;
import com.adp.wfnddt.core.OracleScriptServicesProxy;
import com.adp.wfnddt.core.OracleScriptServicesProxy.ClientSnapshotLoadParams;
import com.adp.wfnddt.core.OracleScriptServicesProxy.ClientSnapshotLoadResponse;
import com.adp.wfnddt.core.OracleScriptServicesProxy.E_Mode;
import com.adp.wfnddt.core.OracleScriptServicesProxy.UserMappingByAssocIDParams;
import com.adp.wfnddt.core.OracleScriptServicesProxy.UserMappingBySSNParams;
import com.adp.wfnddt.mailverification.EmailSearcher;
import com.adp.wfnddt.mailverification.EmailUtil;
import com.adp.wfnddt.objectmanager.WebButton;
import com.adp.wfnddt.objectmanager.WebObject;
import com.adp.wfnddt.parammanager.ParamManager;
import com.adp.wfnddt.results.jaxb.StatusType;
import com.adp.wfnddt.webapi.rest.GemFireServices;
import com.adp.wfnddt.webapi.rest.GemFireServices.GemFireUpdateFeaturesParms;
import com.adp.wfnddt.webapi.rest.GemFireServices.GemFireUpdateFeaturesResponse;

import io.appium.java_client.AppiumDriver;

public class WFNLogin {

	private static Logger m_logger = DDTLoggerManager.getLogger(WFNLogin.class);
	private WebDriver m_webDriver = null;
	private AppiumDriver<WebElement> m_appDriver = null;
	private WebDriverWait m_webDriverWait = null;

	@Component(Name = "refresh my WFN Client", Params = { "Login Profile|*^*|Optional", "Company Code|*^*|Required!", "Client Type|*^*|Required! Valid Values: US, NAPR,AUTOPAY_US,AUTOPAY_XB,AUTOPAY_NAPR" })
	public void ResetWFNClient(ParamManager p_resetClient) throws DDTFrameworkException, DatatypeConfigurationException {
		if (!p_resetClient.Parameter("Company Code").equals("") && !p_resetClient.Parameter("Client Type").equals("")) {
			GlobalVariables.initialize(p_resetClient.Parameter("Client Type").toUpperCase());
			GlobalVariables.setRuntimeClientID(GlobalVariables.getClientPrefix() + p_resetClient.Parameter("Company Code").toUpperCase());
			// FOR NOW ONLY SUPPORT AUTO1/2, IPE, AWS_FIT1
			if (DDTController.getWfnEnvironment().startsWith("AUTO") || DDTController.getWfnEnvironment().startsWith("IPE") || DDTController.getWfnEnvironment().startsWith("DIT2") || DDTController.getWfnEnvironment().startsWith("FIT1") || DDTController.getWfnEnvironment().startsWith("AWS_FIT")) {
				// Calling WebService Load Dump Script
				OracleScriptServicesProxy oracleScriptSvcProxy = new OracleScriptServicesProxy();
				ClientSnapshotLoadParams cltSSLoadParams = oracleScriptSvcProxy.new ClientSnapshotLoadParams();
				cltSSLoadParams.setEnvironmentID(GlobalVariables.getDBEnvID());
				cltSSLoadParams.setCompanyCode(p_resetClient.Parameter("Company Code").toUpperCase());
				cltSSLoadParams.setRunID(Integer.valueOf(DDTController.getRunID()));
				ClientSnapshotLoadResponse response = oracleScriptSvcProxy.loadClientSnapshot(cltSSLoadParams); // response
																												// is
																												// "SUCCESS"
																												// or
																												// "FAILED";
				m_logger.debug(String.format("Status: %1$s, VPDKey: %2$s", response.getStatus(), response.getVPDKey()));

				if (response.getStatus().equalsIgnoreCase("FAILED")) {
					GlobalVariables.setResultCode(106);
					String m_log = "http://cdlautowfnrpt/DB_Logs/load_wfn_" + p_resetClient.Parameter("Company Code").toUpperCase() + "_" + DDTController.getRunID() + ".out";
					DDTController.getResultsReporter().addTestStep("<a href='" + m_log + "'>Load Dump DB Log</a>");
					DDTController.getResultsReporter().endTestStep(StatusType.DONE);
					DDTAssertionError.fail("Check Load Dump File Log File", "Environment issue - ***Check Load Dump DB log***");
				} else {
					GlobalVariables.setRuntimeVPDKey(response.getVPDKey());
				}

			}
		}
		// TODO: When DIT/FIT available, it needs load login profile and run
		// Load Dump

		return;
	}

	@Component(Name = "login to WFN as Practitioner User", Params = { "Login Profile|*^*|Optional", "Company Code|*^*|Required!", "Client Type|*^*|Required! Valid Values: US, NAPR,AUTOPAY_US,AUTOPAY_XB,AUTOPAY_NAPR" })
	public void PractionerLogin(ParamManager p_pm_login) throws DDTFrameworkException {
		if (!p_pm_login.Parameter("Company Code").equals("") && !p_pm_login.Parameter("Client Type").equals("")) {
			String currentUserID;
			String currentUserPwd = "adpadp10";
			GlobalVariables.initialize(p_pm_login.Parameter("Client Type").toUpperCase());
			GlobalVariables.setRuntimeClientID(GlobalVariables.getClientPrefix() + p_pm_login.Parameter("Company Code").toUpperCase());
			currentUserID = "autopractitioner@" + GlobalVariables.getRuntimeClientID();

			LoginProfile currentProfile = null;
			if (!p_pm_login.Parameter("Login Profile").equals("") && !p_pm_login.Parameter("Login Profile").toUpperCase().equals("DEFAULT")) {
				currentProfile = DDTController.getLoginProfile(p_pm_login.Parameter("Login Profile"));
			} // Required for DIT and FIT environments.

			// Set Runtime variables from Login Profile
			if (!(currentProfile == null)) {
				// URL is optional, default will be set by EnvID from
				// GlobalVariables
				if (currentProfile.getURL() == null || currentProfile.getURL().equals("")) {
				} else {
					GlobalVariables.setRuntimeURL(currentProfile.getURL());
				}

				if ((currentProfile.getClientID() == null) || currentProfile.getClientID().equals("")) {
					throw new DDTFrameworkException(WFNLogin.class, "ClientID is not set in LoginProfile");
				} else {
					GlobalVariables.setRuntimeClientID(currentProfile.getClientID());
				}

				if ((currentProfile.getPractUserCredential().getUserID() == null) || currentProfile.getPractUserCredential().getUserID().equals("")) {
					throw new DDTFrameworkException(WFNLogin.class, "PractUser UserID is not set in LoginProfile");
				} else {
					currentUserID = currentProfile.getPractUserCredential().getUserID();
				}

				if ((currentProfile.getPractUserCredential().getPassword() == null) || currentProfile.getPractUserCredential().getPassword().equals("")) {
					throw new DDTFrameworkException(WFNLogin.class, "PractUser Password is not set in LoginProfile");
				} else {
					currentUserPwd = currentProfile.getPractUserCredential().getPassword();
				}

				if (currentProfile.getSellingRegion() == null || currentProfile.getSellingRegion().equals("")) {
				} else {
					GlobalVariables.setRuntimeSellingRegion(currentProfile.getSellingRegion());
				}

				if (currentProfile.getVPDKey() == null || currentProfile.getVPDKey().equals("")) {
				} else {
					GlobalVariables.setRuntimeVPDKey(currentProfile.getVPDKey());
				}
			}

			ArcotLogin(GlobalVariables.getRuntimeClientID(), "PRACTITIONER", currentUserID, currentUserPwd, "NO");
		}
		return;
	}

	@Component(Name = "login to WFN as UA User", Params = { "Login Profile|*^*|Optional", "Company Code|*^*|Required!", "Client Type|*^*|Required! Valid Values: US, NAPR,AUTOPAY_US,AUTOPAY_XB,AUTOPAY_NAPR" })
	public void UAUserLogin(ParamManager p_pm_login) throws DDTFrameworkException {
		if (!p_pm_login.Parameter("Company Code").equals("") && !p_pm_login.Parameter("Client Type").equals("")) {
			String currentUserID;
			String currentUserPwd = "adpadp10";
			GlobalVariables.initialize(p_pm_login.Parameter("Client Type").toUpperCase());
			GlobalVariables.setRuntimeClientID(GlobalVariables.getClientPrefix() + p_pm_login.Parameter("Company Code").toUpperCase());
			currentUserID = "autoipe@adp";

			if (p_pm_login.Parameter("Client Type").equals("NAPR") || p_pm_login.Parameter("Client Type").equals("AUTOPAY_NAPR")) {
				currentUserID = "AUTOCA@ADP";
			}

			LoginProfile currentProfile = null;
			if (!p_pm_login.Parameter("Login Profile").equals("") && !p_pm_login.Parameter("Login Profile").toUpperCase().equals("DEFAULT")) {
				currentProfile = DDTController.getLoginProfile(p_pm_login.Parameter("Login Profile"));
			} // Required for DIT and FIT environments.
				// Set Runtime variables from Login Profile
			if (!(currentProfile == null)) {
				// URL is optional, default will be set by EnvID from
				// GlobalVariables
				if (currentProfile.getURL() == null || currentProfile.getURL().equals("")) {
				} else {
					GlobalVariables.setRuntimeURL(currentProfile.getURL());
				}

				if ((currentProfile.getClientID() == null) || currentProfile.getClientID().equals("")) {
					throw new DDTFrameworkException(WFNLogin.class, "ClientID is not set in LoginProfile");
				} else {
					GlobalVariables.setRuntimeClientID(currentProfile.getClientID());
					// Overwrite profile ClientID if user specified value in ALM custom column
					if (!(DDTController.getCustom().equals(""))) {
						GlobalVariables.setRuntimeClientID(DDTController.getCustom());
					}
				}

				if ((currentProfile.getUAUserCredential().getUserID() == null) || currentProfile.getUAUserCredential().getUserID().equals("")) {
					throw new DDTFrameworkException(WFNLogin.class, "UAUser UserID is not set in LoginProfile");
				} else {
					currentUserID = currentProfile.getUAUserCredential().getUserID();
				}

				if ((currentProfile.getUAUserCredential().getPassword() == null) || currentProfile.getUAUserCredential().getPassword().equals("")) {
					throw new DDTFrameworkException(WFNLogin.class, "UAUser Password is not set in LoginProfile");
				} else {
					currentUserPwd = currentProfile.getUAUserCredential().getPassword();
				}

				if (currentProfile.getSellingRegion() == null || currentProfile.getSellingRegion().equals("")) {
				} else {
					GlobalVariables.setRuntimeSellingRegion(currentProfile.getSellingRegion());
				}

				if (currentProfile.getVPDKey() == null || currentProfile.getVPDKey().equals("")) {
				} else {
					GlobalVariables.setRuntimeVPDKey(currentProfile.getVPDKey());
				}
			}

			ArcotLogin(GlobalVariables.getRuntimeClientID(), "UA", currentUserID, currentUserPwd, "NO");
		}
		return;
	}

	@Component(Name = "login to WFN as Employee User", Params = { "Login Profile|*^*|Optional", "Company Code|*^*|Required!", "Client Type|*^*|Required! Valid Values: US, NAPR,AUTOPAY_US,AUTOPAY_XB,AUTOPAY_NAPR" })
	public void EmployeeUserLogin(ParamManager p_pm_login) throws DDTFrameworkException {
		if (!p_pm_login.Parameter("Company Code").equals("") && !p_pm_login.Parameter("Client Type").equals("")) {
			String currentUserID;
			String currentUserPwd = "adpadp10";
			GlobalVariables.initialize(p_pm_login.Parameter("Client Type").toUpperCase());
			GlobalVariables.setRuntimeClientID(GlobalVariables.getClientPrefix() + p_pm_login.Parameter("Company Code").toUpperCase());
			currentUserID = "autoemployee@" + GlobalVariables.getRuntimeClientID();

			LoginProfile currentProfile = null;
			if (!p_pm_login.Parameter("Login Profile").equals("") && !p_pm_login.Parameter("Login Profile").toUpperCase().equals("DEFAULT")) {
				currentProfile = DDTController.getLoginProfile(p_pm_login.Parameter("Login Profile"));
			} // Required for DIT and FIT environments.
				// Set Runtime variables from Login Profile
			if (!(currentProfile == null)) {
				// URL is optional, default will be set by EnvID from
				// GlobalVariables
				if (currentProfile.getURL() == null || currentProfile.getURL().equals("")) {
				} else {
					GlobalVariables.setRuntimeURL(currentProfile.getURL());
				}

				if ((currentProfile.getClientID() == null) || currentProfile.getClientID().equals("")) {
					throw new DDTFrameworkException(WFNLogin.class, "ClientID is not set in LoginProfile");
				} else {
					GlobalVariables.setRuntimeClientID(currentProfile.getClientID());
				}

				if ((currentProfile.getEEUserCredential().getUserID() == null) || currentProfile.getEEUserCredential().getUserID().equals("")) {
					throw new DDTFrameworkException(WFNLogin.class, "EEUser UserID is not set in LoginProfile");
				} else {
					currentUserID = currentProfile.getEEUserCredential().getUserID();
				}

				if ((currentProfile.getEEUserCredential().getPassword() == null) || currentProfile.getEEUserCredential().getPassword().equals("")) {
					throw new DDTFrameworkException(WFNLogin.class, "EEUser Password is not set in LoginProfile");
				} else {
					currentUserPwd = currentProfile.getEEUserCredential().getPassword();
				}

				if (currentProfile.getSellingRegion() == null || currentProfile.getSellingRegion().equals("")) {
				} else {
					GlobalVariables.setRuntimeSellingRegion(currentProfile.getSellingRegion());
				}

				if (currentProfile.getVPDKey() == null || currentProfile.getVPDKey().equals("")) {
				} else {
					GlobalVariables.setRuntimeVPDKey(currentProfile.getVPDKey());
				}
			}

			ArcotLogin(GlobalVariables.getRuntimeClientID(), "EMPLOYEE", currentUserID, currentUserPwd, "NO");
		}
		return;
	}

	@Component(Name = "login to WFN as Manager User", Params = { "Login Profile|*^*|Optional", "Company Code|*^*|Required!", "Client Type|*^*|Required! Valid Values: US, NAPR,AUTOPAY_US,AUTOPAY_XB,AUTOPAY_NAPR" })
	public void ManagerUserLogin(ParamManager p_pm_login) throws DDTFrameworkException {
		if (!p_pm_login.Parameter("Company Code").equals("") && !p_pm_login.Parameter("Client Type").equals("")) {
			String currentUserID;
			String currentUserPwd = "adpadp10";
			GlobalVariables.initialize(p_pm_login.Parameter("Client Type").toUpperCase());
			GlobalVariables.setRuntimeClientID(GlobalVariables.getClientPrefix() + p_pm_login.Parameter("Company Code").toUpperCase());
			currentUserID = "automanager@" + GlobalVariables.getRuntimeClientID();

			LoginProfile currentProfile = null;
			if (!p_pm_login.Parameter("Login Profile").equals("") && !p_pm_login.Parameter("Login Profile").toUpperCase().equals("DEFAULT")) {
				currentProfile = DDTController.getLoginProfile(p_pm_login.Parameter("Login Profile"));
			} // Required for DIT and FIT environments.
				// Set Runtime variables from Login Profile
			if (!(currentProfile == null)) {
				// URL is optional, default will be set by EnvID from
				// GlobalVariables
				if (currentProfile.getURL() == null || currentProfile.getURL().equals("")) {
				} else {
					GlobalVariables.setRuntimeURL(currentProfile.getURL());
				}

				if ((currentProfile.getClientID() == null) || currentProfile.getClientID().equals("")) {
					throw new DDTFrameworkException(WFNLogin.class, "ClientID is not set in LoginProfile");
				} else {
					GlobalVariables.setRuntimeClientID(currentProfile.getClientID());
				}

				if ((currentProfile.getMgrUserCredential().getUserID() == null) || currentProfile.getMgrUserCredential().getUserID().equals("")) {
					throw new DDTFrameworkException(WFNLogin.class, "MgrUser UserID is not set in LoginProfile");
				} else {
					currentUserID = currentProfile.getMgrUserCredential().getUserID();
				}

				if ((currentProfile.getMgrUserCredential().getPassword() == null) || currentProfile.getMgrUserCredential().getPassword().equals("")) {
					throw new DDTFrameworkException(WFNLogin.class, "MgrUser Password is not set in LoginProfile");
				} else {
					currentUserPwd = currentProfile.getMgrUserCredential().getPassword();
				}

				if (currentProfile.getSellingRegion() == null || currentProfile.getSellingRegion().equals("")) {
				} else {
					GlobalVariables.setRuntimeSellingRegion(currentProfile.getSellingRegion());
				}

				if (currentProfile.getVPDKey() == null || currentProfile.getVPDKey().equals("")) {
				} else {
					GlobalVariables.setRuntimeVPDKey(currentProfile.getVPDKey());
				}
			}

			ArcotLogin(GlobalVariables.getRuntimeClientID(), "MANAGER", currentUserID, currentUserPwd, "NO");

		}
		return;
	}

	@Component(Name = "login to WFN as New Hire", Params = { "Login Profile|*^*|Optional", "Company Code|*^*|Required!", "Client Type|*^*|Required! Valid Values: US, NAPR,AUTOPAY_US,AUTOPAY_XB,AUTOPAY_NAPR" })
	public void NewHireLogin(ParamManager p_pm_login) throws DDTFrameworkException {
		if (!p_pm_login.Parameter("Company Code").equals("") && !p_pm_login.Parameter("Client Type").equals("")) {
			String currentUserID;
			String currentUserPwd = "adpadp10";
			GlobalVariables.initialize(p_pm_login.Parameter("Client Type").toUpperCase());
			GlobalVariables.setRuntimeClientID(GlobalVariables.getClientPrefix() + p_pm_login.Parameter("Company Code").toUpperCase());
			currentUserID = "autoemployee@" + GlobalVariables.getRuntimeClientID();

			LoginProfile currentProfile = null;
			if (!p_pm_login.Parameter("Login Profile").equals("") && !p_pm_login.Parameter("Login Profile").toUpperCase().equals("DEFAULT")) {
				currentProfile = DDTController.getLoginProfile(p_pm_login.Parameter("Login Profile"));
			} // Required for DIT and FIT environments.
				// Set Runtime variables from Login Profile
			if (!(currentProfile == null)) {
				// URL is optional, default will be set by EnvID from
				// GlobalVariables
				if (currentProfile.getURL() == null || currentProfile.getURL().equals("")) {
				} else {
					GlobalVariables.setRuntimeURL(currentProfile.getURL());
				}

				if ((currentProfile.getClientID() == null) || currentProfile.getClientID().equals("")) {
					throw new DDTFrameworkException(WFNLogin.class, "ClientID is not set in LoginProfile");
				} else {
					GlobalVariables.setRuntimeClientID(currentProfile.getClientID());
				}

				if ((currentProfile.getEEUserCredential().getUserID() == null) || currentProfile.getEEUserCredential().getUserID().equals("")) {
					throw new DDTFrameworkException(WFNLogin.class, "EEUser UserID is not set in LoginProfile");
				} else {
					currentUserID = currentProfile.getEEUserCredential().getUserID();
				}

				if ((currentProfile.getEEUserCredential().getPassword() == null) || currentProfile.getEEUserCredential().getPassword().equals("")) {
					throw new DDTFrameworkException(WFNLogin.class, "EEUser Password is not set in LoginProfile");
				} else {
					currentUserPwd = currentProfile.getEEUserCredential().getPassword();
				}

				if (currentProfile.getSellingRegion() == null || currentProfile.getSellingRegion().equals("")) {
				} else {
					GlobalVariables.setRuntimeSellingRegion(currentProfile.getSellingRegion());
				}

				if (currentProfile.getVPDKey() == null || currentProfile.getVPDKey().equals("")) {
				} else {
					GlobalVariables.setRuntimeVPDKey(currentProfile.getVPDKey());
				}
			}

			ArcotLogin(GlobalVariables.getRuntimeClientID(), "NEWHIRE", currentUserID, currentUserPwd, "NO");
		}
		return;
	}

	// The check for the login profile as DEFAULT should not be rolled up to
	// subsequent branches. Instead the DEFAULT has to be cleared out in the
	// feature files
	@Component(Name = "login to WFN Admin Tool", Params = { "Login Profile|*^*|Optional", "Client Type|*^*|Required! Valid Values: US, NAPR,AUTOPAY_US,AUTOPAY_XB,AUTOPAY_NAPR" })
	public void AdminToolLogin(ParamManager p_pm_login) throws DDTFrameworkException {
		String currentUserID = "autoipe@adp";
		String currentUserPwd = "adpadp10";
		if (!p_pm_login.Parameter("Client Type").equals("")) {
			GlobalVariables.initialize(p_pm_login.Parameter("Client Type").toUpperCase());
			if (p_pm_login.Parameter("Client Type").equals("NAPR") || p_pm_login.Parameter("Client Type").equals("AUTOPAY_NAPR")) {
				currentUserID = "AUTOCA@ADP";
			}

			LoginProfile currentProfile = null;
			if (!p_pm_login.Parameter("Login Profile").equals("") && !p_pm_login.Parameter("Login Profile").toUpperCase().equals("DEFAULT")) {
				currentProfile = DDTController.getLoginProfile(p_pm_login.Parameter("Login Profile"));
			} // Required for DIT and FIT environments.
				// Set Runtime variables from Login Profile
			if (!(currentProfile == null)) {
				// URL is optional, default will be set by EnvID from
				// GlobalVariables
				if (currentProfile.getURL() == null || currentProfile.getURL().equals("")) {
				} else {
					GlobalVariables.setRuntimeURL(currentProfile.getURL());
				}

				if ((currentProfile.getUAUserCredential().getUserID() == null) || currentProfile.getUAUserCredential().getUserID().equals("")) {
					throw new DDTFrameworkException(WFNLogin.class, "UAUser UserID is not set in LoginProfile");
				} else {
					currentUserID = currentProfile.getUAUserCredential().getUserID();
				}

				if ((currentProfile.getUAUserCredential().getPassword() == null) || currentProfile.getUAUserCredential().getPassword().equals("")) {
					throw new DDTFrameworkException(WFNLogin.class, "UAUser Password is not set in LoginProfile");
				} else {
					currentUserPwd = currentProfile.getUAUserCredential().getPassword();
				}

				if (currentProfile.getSellingRegion() == null || currentProfile.getSellingRegion().equals("")) {
				} else {
					GlobalVariables.setRuntimeSellingRegion(currentProfile.getSellingRegion());
				}

				if (currentProfile.getVPDKey() == null || currentProfile.getVPDKey().equals("")) {
				} else {
					GlobalVariables.setRuntimeVPDKey(currentProfile.getVPDKey());
				}
			}
			GlobalVariables.setRuntimeClientID("");
			ArcotLogin(GlobalVariables.getRuntimeClientID(), "UA", currentUserID, currentUserPwd, "YES");
		}
		return;
	}

	@Component(Name = "login to myADP as Employee User", Params = { "Login Profile", "Company Code", "Client Type" })
	public void myADPEmployeeUserLogin(ParamManager p_pm_login) throws DDTFrameworkException {
		if (!p_pm_login.Parameter("Company Code").equals("") && !p_pm_login.Parameter("Client Type").equals("")) {
			String currentUserID;
			String currentUserPwd = "adpadp10";
			GlobalVariables.initialize(p_pm_login.Parameter("Client Type").toUpperCase());
			GlobalVariables.setRuntimeClientID(GlobalVariables.getClientPrefix() + p_pm_login.Parameter("Company Code").toUpperCase());
			currentUserID = "autoemployee@" + GlobalVariables.getRuntimeClientID();

			LoginProfile currentProfile = DDTController.getLoginProfile(p_pm_login.Parameter("Login Profile"));
			// Set Runtime variables from Login Profile
			if (!(currentProfile == null)) {
				// URL is optional, default will be set by EnvID from
				// GlobalVariables
				if (currentProfile.getURL() == null || currentProfile.getURL().equals("")) {
				} else {
					GlobalVariables.setRuntimeURL(currentProfile.getURL());
				}

				if ((currentProfile.getClientID() == null) || currentProfile.getClientID().equals("")) {
					throw new DDTFrameworkException(WFNLogin.class, "ClientID is not set in LoginProfile");
				} else {
					GlobalVariables.setRuntimeClientID(currentProfile.getClientID());
				}

				if ((currentProfile.getEEUserCredential().getUserID() == null) || currentProfile.getEEUserCredential().getUserID().equals("")) {
					throw new DDTFrameworkException(WFNLogin.class, "EEUser UserID is not set in LoginProfile");
				} else {
					currentUserID = currentProfile.getEEUserCredential().getUserID();
				}

				if ((currentProfile.getEEUserCredential().getPassword() == null) || currentProfile.getEEUserCredential().getPassword().equals("")) {
					throw new DDTFrameworkException(WFNLogin.class, "EEUser Password is not set in LoginProfile");
				} else {
					currentUserPwd = currentProfile.getEEUserCredential().getPassword();
				}
			}

			ArcotLogin(GlobalVariables.getRuntimeClientID(), "myADP-EMPLOYEE", currentUserID, currentUserPwd, "NO");
		}
		return;
	}

	@Component(Name = "map a user to Automation TLM client using Tax ID", Params = { "User Type|*^*|Valid Values: EMPLOYEE, MANAGER, PRACTITIONER", "Tax ID" })
	public void userMappingTLM_TaxID(ParamManager p_pm) throws DDTFrameworkException {
		if (!p_pm.Parameter("User Type").equals("") && !p_pm.Parameter("Tax ID").equals("") && !(GlobalVariables.getRuntimeClientID() == null)) {
			String userID = "";
			switch (p_pm.Parameter("User Type").toUpperCase()) {
			case "EMPLOYEE":
				userID = "AUTOEMPLOYEE@" + GlobalVariables.getRuntimeClientID();
				break;
			case "MANAGER":
				userID = "AUTOMANAGER@" + GlobalVariables.getRuntimeClientID();
				break;
			case "PRACTITIONER":
				userID = "AUTOPRACTITIONER@" + GlobalVariables.getRuntimeClientID();
				break;
			}

			userMapping(userID, p_pm.Parameter("Tax ID"), "", E_Mode.EZLM);
		} else {
			m_logger.debug("***Warning, skipping user mapping due to missing parameters");
		}

		return;
	}

	@Component(Name = "map a user to Automation Talent client using Tax ID", Params = { "User Type|*^*|Valid Values: EMPLOYEE, MANAGER, PRACTITIONER", "Tax ID" })
	public void userMappingTalent_TaxID(ParamManager p_pm) throws DDTFrameworkException {
		if (!p_pm.Parameter("User Type").equals("") && !p_pm.Parameter("Tax ID").equals("") && !(GlobalVariables.getRuntimeClientID() == null)) {
			String userID = "";
			switch (p_pm.Parameter("User Type").toUpperCase()) {
			case "EMPLOYEE":
				userID = "AUTOEMPLOYEE@" + GlobalVariables.getRuntimeClientID();
				break;
			case "MANAGER":
				userID = "AUTOMANAGER@" + GlobalVariables.getRuntimeClientID();
				break;
			case "PRACTITIONER":
				userID = "AUTOPRACTITIONER@" + GlobalVariables.getRuntimeClientID();
				break;
			}

			userMapping(userID, p_pm.Parameter("Tax ID"), "", E_Mode.Talent);
		} else {
			m_logger.debug("***Warning, skipping user mapping due to missing parameters");
		}
		return;
	}

	@Component(Name = "map a user to Automation client using Tax ID", Params = { "User Type|*^*|Valid Values: EMPLOYEE, MANAGER, PRACTITIONER", "Tax ID" })
	public void userMapping_TaxID(ParamManager p_pm) throws DDTFrameworkException {
		if (!p_pm.Parameter("User Type").equals("") && !p_pm.Parameter("Tax ID").equals("") && !(GlobalVariables.getRuntimeClientID() == null)) {
			String userID = "";
			switch (p_pm.Parameter("User Type").toUpperCase()) {
			case "EMPLOYEE":
				userID = "AUTOEMPLOYEE@" + GlobalVariables.getRuntimeClientID();
				break;
			case "MANAGER":
				userID = "AUTOMANAGER@" + GlobalVariables.getRuntimeClientID();
				break;
			case "PRACTITIONER":
				userID = "AUTOPRACTITIONER@" + GlobalVariables.getRuntimeClientID();
				break;
			}

			userMapping(userID, p_pm.Parameter("Tax ID"), "", E_Mode.Normal);
		} else {
			m_logger.debug("***Warning, skipping user mapping due to missing parameters");
		}
		return;
	}

	@Component(Name = "map a user to Automation client using Associate ID", Params = { "User Type|*^*|Valid Values: EMPLOYEE, MANAGER, PRACTITIONER", "Associate ID", "Company Code" })
	public void userMapping_AssociateID(ParamManager p_pm) throws DDTFrameworkException {
		if (!p_pm.Parameter("User Type").equals("") && !p_pm.Parameter("Associate ID").equals("") && !(GlobalVariables.getRuntimeClientID() == null)) {
			String userID = "";
			switch (p_pm.Parameter("User Type").toUpperCase()) {
			case "EMPLOYEE":
				userID = "AUTOEMPLOYEE@" + GlobalVariables.getRuntimeClientID();
				break;
			case "MANAGER":
				userID = "AUTOMANAGER@" + GlobalVariables.getRuntimeClientID();
				break;
			case "PRACTITIONER":
				userID = "AUTOPRACTITIONER@" + GlobalVariables.getRuntimeClientID();
				break;
			}

			userMapping(userID, "", p_pm.Parameter("Associate ID").toUpperCase(), E_Mode.Normal);
		} else {
			m_logger.debug("***Warning, skipping user mapping due to missing parameters");
		}
		return;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////////////
	private void ArcotLogin(String p_clientID, String p_UserType, String p_userID, String p_pwd, String p_admintoolLogin) throws DDTFrameworkException {

		try {

			m_webDriver = BrowserManager.setupWebDriver();
			m_webDriver.get(GlobalVariables.getRuntimeURL());

			String m_CurrentBuildNumber = "";
			WebObject m_adminLink = null;

			// First switch case for WFNEnvID: DIT1,
			// DIT2,FIT1,FIT2,AUTO1,AUTO2,IPEFULL,IPESLIM,IAT
			switch (DDTController.getWfnEnvironment()) {
			case "AUTO1":
			case "AUTO2":
				// DDTController.getWebDriverWait().until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class,'admin-login')]//i[contains(text(),'Administrator Sign In')]")));
				// DDTController.getWebDriverWait().until(ExpectedConditions.presenceOfElementLocated(By.id("adminLogin")));

				Thread.sleep(1000);

				if (m_webDriver.findElements(By.xpath("//a[@class='popover-trigger ng-binding']")).size() > 0) {
					WebObject dropdown = new WebObject("XPATH://a[@class='popover-trigger ng-binding']");
					if (GlobalVariables.getLanguagePreference().equals("CA")) {
						dropdown.click();
						General.sleep(1);
						DDTController.getWebDriver().findElement(By.xpath("//*[contains(text(),'English (CA)')]")).click();
					} else {
						dropdown.click();
						General.sleep(1);
						DDTController.getWebDriver().findElement(By.xpath("//*[contains(text(),'English (US)')]")).click();
					}

				} else {

					Select dropdown = new Select(m_webDriver.findElement(By.id("langChooser")));
					Thread.sleep(5000);
					if (GlobalVariables.getLanguagePreference().equals("CA")) {
						dropdown.selectByVisibleText("English (CA)");
					} else {
						dropdown.selectByVisibleText("English (US)");
					}
					General.sleep(1);
				}

				if (m_webDriver.findElements(By.xpath("//i[@class='ng-scope']")).size() > 0) {
					m_adminLink = new WebObject("XPATH://i[@class='ng-scope']");
				} else {
					WebElement webElem = m_webDriver.findElement(By.id("adminLogin"));
					m_adminLink = new WebObject(webElem);
				}

				// m_webDriver.findElement(By.xpath("//div[@class='row language-popover']//a[@class='popover-trigger ng-binding']/i[@class='fa fa-caret-down']")).click();
				//
				// if (GlobalVariables.getLanguagePreference().equals("CA")) {
				// DDTController.getWebDriverWait().until(ExpectedConditions.presenceOfElementLocated(By.xpath("//li[@class='ng-scope']//a[contains(text(),'English (CA)')]")));
				// m_webDriver.findElement(By.xpath("//li[@class='ng-scope']//a[contains(text(),'English (CA)')]")).click();
				// } else {
				// DDTController.getWebDriverWait().until(ExpectedConditions.presenceOfElementLocated(By.xpath("//li[@class='ng-scope']//a[contains(text(),'English (US)')]")));
				// m_webDriver.findElement(By.xpath("//li[@class='ng-scope']//a[contains(text(),'English (US)')]")).click();
				// }
				// General.sleep(1);
				switch (p_UserType) {
				case "PRACTITIONER":
					// m_webDriver.findElement(By.xpath("//div[contains(@class,'admin-login')]//i[contains(text(),'Administrator Sign In')]")).click();
					// m_webDriver.findElement(By.id("adminLogin")).click();
					m_adminLink.click();

					DDTController.getWebDriverWait().until(ExpectedConditions.visibilityOfElementLocated(By.name("USER")));
					m_webDriver.findElement(By.name("USER")).sendKeys(p_userID);
					m_webDriver.findElement(By.name("PASSWORD")).sendKeys(p_pwd);
					m_webDriver.findElement(By.xpath("//input[@type='button' and @value='Login']")).click();
					DDTController.getWebDriverWait().until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='masthead']")));
					if (!DDTController.getOS().equals(E_OSs.MacOSX))
						BrowserManager.maximizeWindow();
					break;
				case "EMPLOYEE":
				case "MANAGER":
					m_webDriver.findElement(By.xpath("//*[@id='user_id']")).sendKeys(p_userID);
					m_webDriver.findElement(By.xpath(".//*[@id='password']")).sendKeys(p_pwd);
					Thread.sleep(1000);
					m_webDriver.findElement(By.xpath(".//*[@id='subBtn']")).click();
					DDTController.getWebDriverWait().until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='masthead']")));
					if (!DDTController.getOS().equals(E_OSs.MacOSX))
						BrowserManager.maximizeWindow();
					break;
				case "UA":
					// m_webDriver.findElement(By.xpath("//div[contains(@class,'admin-login')]//i[contains(text(),'Administrator Sign In')]")).click();
					// m_webDriver.findElement(By.id("adminLogin")).click();
					m_adminLink.click();
					Thread.sleep(1000);
					m_webDriver.findElement(By.name("USER")).sendKeys(p_userID);
					m_webDriver.findElement(By.name("PASSWORD")).sendKeys(p_pwd);
					m_webDriver.findElement(By.xpath("//input[@type='button' and @value='Login']")).click();
					// DDTController.getWebDriverWait().until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[contains(@id,'toolbarQuickSearch') or @id='searchBox']")));
					if (!DDTController.getOS().equals(E_OSs.MacOSX))
						BrowserManager.maximizeWindow();
					Thread.sleep(3000);
					// Remove IE Warning
					if (new WebButton("XPATH://button[@class='primary' and text()='ok']").exists(5))
						new WebButton("XPATH://button[@class='primary' and text()='ok']").actionClick();// Remove IE Dialog
					com.adp.wfnddt.commonmethods.General.waitForGridSpinnerToComplete();
					if (!p_admintoolLogin.equals("YES")) {
						m_webDriver.findElement(By.xpath("//input[contains(@id,'toolbarQuickSearch') or @id='searchBox']")).click();
						Thread.sleep(1000);
						m_webDriver.findElement(By.xpath("//input[contains(@id,'toolbarQuickSearch') or @id='searchBox']")).sendKeys(p_clientID);
						Thread.sleep(3000);
						if (m_webDriver.findElements(By.xpath(".//a/span[text()='" + p_clientID.toLowerCase() + "']")).size() != 0) {
							m_webDriver.findElement(By.xpath(".//a/span[text()='" + p_clientID.toLowerCase() + "']")).click();
						} else {
							m_webDriver.findElement(By.xpath("//a[@class='uaClientId' and text() ='" + p_clientID.toLowerCase() + "']")).click();
						}
						Thread.sleep(3000);
						m_webDriver.findElement(By.xpath("//a[text()='Practitioner Access']")).click();
						com.adp.wfnddt.commonmethods.General.waitForGridSpinnerToComplete();
						DDTController.getWebDriverWait().until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='masthead']")));
						break;
					} else {
						break;
					}
				default:
					DDTAssertionError.fail("Unknow Login User Type " + p_UserType, "Environment issue");
				}

				// Set Company code to Result Reporter
				if (!GlobalVariables.getRuntimeClientID().equals("")) {
					String p_CoCode = GlobalVariables.getRuntimeClientID().replace(GlobalVariables.getClientPrefix(), "");
					if (!p_CoCode.equals(""))
						DDTController.getResultsReporter().setCompanyCode(p_CoCode);
				}
				// // dismiss Bridge Popup
				// if
				// (DDTController.getWebDriver().findElements(By.xpath("//span[@id='ssoBridgeGotItButton']"))
				// .size() != 0) {
				// DDTController.getWebDriver().findElement(By.xpath("//span[@id='ssoBridgeGotItButton']")).click();
				// }
				// //output login info
				// DDTController.getResultsReporter().addTestStep("Login Info - URL : " + GlobalVariables.getRuntimeURL());
				// DDTController.getResultsReporter().endTestStep(StatusType.DONE);
				// DDTController.getResultsReporter().addTestStep("Login Info - User/Pwd : " + p_userID+"/"+p_pwd);
				// DDTController.getResultsReporter().endTestStep(StatusType.DONE);

				break;
			case "FIT1":
			case "FIT2":
			case "FIT4":
			case "DIT2":
			case "IAT":
			case "AWS_PREDIT":
			case "AWS_FIT1":
			case "PROD":
				// DDTController.getWebDriverWait()
				// .until(ExpectedConditions.presenceOfElementLocated(By.id("adminLogin")));
				Thread.sleep(1000);
				if (!p_UserType.startsWith("myADP")) {

					if (m_webDriver.findElements(By.xpath("//a[@class='popover-trigger ng-binding']")).size() > 0) {
						WebObject dropdown = new WebObject("XPATH://a[@class='popover-trigger ng-binding']");
						if (GlobalVariables.getLanguagePreference().equals("CA")) {
							dropdown.click();
							General.sleep(1);
							DDTController.getWebDriver().findElement(By.xpath("//*[contains(text(),'English (CA)')]")).click();
						} else {
							dropdown.click();
							General.sleep(1);
							if (m_webDriver.findElements(By.xpath("//*[contains(text(),'English (US)')]")).size() > 0) {
								DDTController.getWebDriver().findElement(By.xpath("//*[contains(text(),'English (US)')]")).click();
							} else {
								DDTController.getWebDriver().findElement(By.xpath("//*[contains(text(),'English')]")).click();
							}
						}

					} else {

						Select dropdown = new Select(m_webDriver.findElement(By.id("langChooser")));
						Thread.sleep(5000);
						if (GlobalVariables.getLanguagePreference().equals("CA")) {
							dropdown.selectByVisibleText("English (CA)");
						} else {
							dropdown.selectByVisibleText("English (US)");
						}
						General.sleep(1);
					}

					if (m_webDriver.findElements(By.xpath("//i[@class='ng-scope']")).size() > 0) {
						m_adminLink = new WebObject("XPATH://i[@class='ng-scope']");
					} else {
						WebElement webElem = m_webDriver.findElement(By.id("adminLogin"));
						m_adminLink = new WebObject(webElem);
					}
				}

				switch (p_UserType) {
				case "PRACTITIONER":
					// m_webDriver.findElement(By.id("adminLogin")).click();
					m_adminLink.click();
					General.sleep(3);
					String[] elements = { "CSS:#USER", "XPATH://label[text()='User ID']/../../following-sibling::div//input" };
					if (General.getFoundElementIndex(elements, 30) == 0) {
						m_webDriver.findElement(By.name("USER")).sendKeys(p_userID);
						m_webDriver.findElement(By.xpath(".//div[@class='buttonMid' and text()='Submit']")).click();
						m_webDriver.findElement(By.name("passwordForm:password")).sendKeys(p_pwd);
						m_webDriver.findElement(By.xpath(".//div[@class='buttonMid' and text()='Submit']")).click();
					} else {
						// New Login
						DDTController.getWebDriverWait().until(ExpectedConditions.presenceOfElementLocated(By.xpath("//label[text()='User ID']/../../following-sibling::div//input"))).sendKeys(p_userID);
						General.sleep(3);
						// new WebDriverWait(m_webDriver,60).until(ExpectedConditions.elementToBeClickable(By.xpath("//label[text()='User ID']/../../following-sibling::div//input"))).click();
						// m_webDriver.findElement(By.xpath("//label[text()='User ID']/../../following-sibling::div//input")).sendKeys(p_userID);
						DDTController.getWebDriverWait().until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@class='vdl-button__container' and text()='Next']/parent::button"))).click();
						General.sleep(3);
						DDTController.getWebDriverWait().until(ExpectedConditions.elementToBeClickable(By.xpath("//label[text()='Password (case sensitive)']/following-sibling::div//input"))).click();
						m_webDriver.findElement(By.xpath("//label[text()='Password (case sensitive)']/following-sibling::div//input")).sendKeys(p_pwd);
						m_webDriver.findElement(By.xpath("//span[@class='vdl-button__container' and text()='Sign In']/parent::button")).click();
					}
					DDTController.getWebDriverWait().until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='masthead']")));
					// BrowserManager.maximizeWindow();
					if (!DDTController.getOS().equals(E_OSs.MacOSX))
						BrowserManager.maximizeWindow();
					break;
				case "EMPLOYEE":
				case "MANAGER":
					m_webDriver.findElement(By.name("user")).sendKeys(p_userID);
					m_webDriver.findElement(By.name("password")).sendKeys(p_pwd);
					Thread.sleep(1000);
					m_webDriver.findElement(By.xpath("//button[@id='subBtn']")).click();
					DDTController.getWebDriverWait().until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='masthead']")));
					if (!DDTController.getOS().equals(E_OSs.MacOSX))
						BrowserManager.maximizeWindow();
					break;
				case "NEWHIRE":
					m_webDriver.findElement(By.xpath("//*[@id='user_id']")).sendKeys(p_userID);
					m_webDriver.findElement(By.xpath(".//*[@id='password']")).sendKeys(p_pwd);
					Thread.sleep(1000);
					m_webDriver.findElement(By.xpath(".//*[@id='subBtn']")).click();
					DDTController.getWebDriverWait().until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ONBOARDING-WELCOME-STEP-CONTAINER")));
					if (!DDTController.getOS().equals(E_OSs.MacOSX))
						BrowserManager.maximizeWindow();
					break;
				case "UA":
					// m_webDriver.findElement(By.id("adminLogin")).click();
					m_adminLink.click();
					General.sleep(3);
					m_webDriver.findElement(By.xpath("//label[text()='User ID']/../../following-sibling::div//input")).sendKeys(p_userID);
					m_webDriver.findElement(By.xpath("//span[@class='vdl-button__container' and text()='Next']/parent::button")).click();					
					// Wait until the password field is displayed in the screen, and not a fixed amount of time.
					DDTController.getWebDriverWait().until(ExpectedConditions.visibilityOfElementLocated( By.xpath("//label[text()='Password (case sensitive)']/following-sibling::div//input") ));					
					m_webDriver.findElement(By.xpath("//label[text()='Password (case sensitive)']/following-sibling::div//input")).sendKeys(p_pwd);
					General.sleep(2);
					m_webDriver.findElement(By.xpath("//span[@class='vdl-button__container' and text()='Sign In']/parent::button")).click();
					DDTController.getWebDriverWait().until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[contains(@id,'toolbarQuickSearch') or @id='searchBox']")));
					if (!DDTController.getOS().equals(E_OSs.MacOSX))
						BrowserManager.maximizeWindow();
					// Remove IE Warning
					if (new WebButton("XPATH://button[@class='primary' and text()='ok']").exists(5))
						new WebButton("XPATH://button[@class='primary' and text()='ok']").actionClick();// Remove IE Dialog
					if (!p_admintoolLogin.equals("YES")) {
						m_webDriver.findElement(By.xpath("//input[contains(@id,'toolbarQuickSearch') or @id='searchBox']")).click();
						Thread.sleep(1000);
						m_webDriver.findElement(By.xpath("//input[contains(@id,'toolbarQuickSearch') or @id='searchBox']")).sendKeys(p_clientID);
						Thread.sleep(3000);
						// m_webDriver.findElement(By.xpath(".//a/span[text()='" + p_clientID.toLowerCase() + "']")).click();
						if (m_webDriver.findElements(By.xpath(".//a/span[text()='" + p_clientID.toLowerCase() + "']")).size() != 0) {
							m_webDriver.findElement(By.xpath(".//a/span[text()='" + p_clientID.toLowerCase() + "']")).click();
						} else {
							m_webDriver.findElement(By.xpath("//a[@class='uaClientId' and text() ='" + p_clientID.toLowerCase() + "']")).click();
						}
						Thread.sleep(3000);
						m_webDriver.findElement(By.xpath("//a[text()='Practitioner Access']")).click();
						DDTController.getWebDriverWait().until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='masthead']")));

					}
					break;
				case "myADP-EMPLOYEE":
				case "myADP-MANAGER":

					boolean useAppDriver = DDTController.isMobile() || DDTController.isTablet();

					if (useAppDriver) {
						DDTController.getMobileDriver().context("NATIVE_APP");
						DDTController.setUseAppDriver(true);

						DDTController.getMobileDriver().findElement(By.xpath("//android.widget.EditText[@id='user']")).sendKeys(p_userID);
						DDTController.getMobileDriver().findElement(By.xpath("//android.widget.EditText[@id='password']")).sendKeys(p_pwd);
						DDTController.getMobileDriver().findElement(By.xpath("//android.widget.Button[@id='login']")).click();

						DDTController.getMobileDriverWait().until(ExpectedConditions.visibilityOfElementLocated(By.id("side-toggle")));
					} else {
						m_webDriver.findElement(By.id("user")).sendKeys(p_userID);
						m_webDriver.findElement(By.id("password")).sendKeys(p_pwd);
						m_webDriver.findElement(By.id("login")).click();

						DDTController.getWebDriverWait().until(ExpectedConditions.visibilityOfElementLocated(By.id("side-toggle")));
					}

					break;
				default:
					DDTAssertionError.fail("Unknow Login User Type " + p_UserType, "Environment issue");
				}
				break;
			case "DIT1":
				// DDTController.getWebDriverWait()
				// .until(ExpectedConditions.presenceOfElementLocated(By.id("adminLogin")));
				Thread.sleep(1000);
				if (!p_UserType.startsWith("myADP")) {

					if (m_webDriver.findElements(By.xpath("//a[@class='popover-trigger ng-binding']")).size() > 0) {
						WebObject dropdown = new WebObject("XPATH://a[@class='popover-trigger ng-binding']");
						if (GlobalVariables.getLanguagePreference().equals("CA")) {
							dropdown.click();
							General.sleep(1);
							DDTController.getWebDriver().findElement(By.xpath("//*[contains(text(),'English (CA)')]")).click();
						} else {
							dropdown.click();
							General.sleep(1);
							if (m_webDriver.findElements(By.xpath("//*[contains(text(),'English (US)')]")).size() > 0) {
								DDTController.getWebDriver().findElement(By.xpath("//*[contains(text(),'English (US)')]")).click();
							} else {
								DDTController.getWebDriver().findElement(By.xpath("//*[contains(text(),'English')]")).click();
							}

						}

					} else {

						Select dropdown = new Select(m_webDriver.findElement(By.id("langChooser")));
						Thread.sleep(5000);
						if (GlobalVariables.getLanguagePreference().equals("CA")) {
							dropdown.selectByVisibleText("English (CA)");
						} else {
							dropdown.selectByVisibleText("English (US)");
						}
						General.sleep(1);
					}

					if (m_webDriver.findElements(By.xpath("//i[@class='ng-scope']")).size() > 0) {
						m_adminLink = new WebObject("XPATH://i[@class='ng-scope']");
					} else {
						WebElement webElem = m_webDriver.findElement(By.id("adminLogin"));
						m_adminLink = new WebObject(webElem);
					}
				}

				switch (p_UserType) {
				case "PRACTITIONER":
					// m_webDriver.findElement(By.id("adminLogin")).click();
					m_adminLink.click();
					DDTController.getWebDriverWait().until(ExpectedConditions.visibilityOfElementLocated(By.name("USER")));
					m_webDriver.findElement(By.name("USER")).sendKeys(p_userID);
					m_webDriver.findElement(By.xpath(".//div[@class='buttonMid' and text()='Submit']")).click();
					m_webDriver.findElement(By.name("passwordForm:password")).sendKeys(p_pwd);
					m_webDriver.findElement(By.xpath(".//div[@class='buttonMid' and text()='Submit']")).click();
					// DDTController.getWebDriverWait().until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='masthead']")));
					if (!DDTController.getOS().equals(E_OSs.MacOSX))
						BrowserManager.maximizeWindow();
					break;
				case "EMPLOYEE":
				case "MANAGER":
					m_webDriver.findElement(By.name("user")).sendKeys(p_userID);
					m_webDriver.findElement(By.name("password")).sendKeys(p_pwd);
					Thread.sleep(1000);
					m_webDriver.findElement(By.xpath("//button[@id='subBtn']")).click();
					DDTController.getWebDriverWait().until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='masthead']")));
					if (!DDTController.getOS().equals(E_OSs.MacOSX))
						BrowserManager.maximizeWindow();
					break;
				case "UA":
					// m_webDriver.findElement(By.id("adminLogin")).click();
					m_adminLink.click();
					m_webDriver.findElement(By.name("USER")).sendKeys(p_userID);
					m_webDriver.findElement(By.xpath(".//div[@class='buttonMid' and text()='Submit']")).click();
					m_webDriver.findElement(By.name("passwordForm:password")).sendKeys(p_pwd);
					m_webDriver.findElement(By.xpath(".//div[@class='buttonMid' and text()='Submit']")).click();
					DDTController.getWebDriverWait().until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[contains(@id,'toolbarQuickSearch') or @id='searchBox']")));
					if (!DDTController.getOS().equals(E_OSs.MacOSX))
						BrowserManager.maximizeWindow();
					// Remove IE Warning
					if (new WebButton("XPATH://button[@class='primary' and text()='ok']").exists(5))
						new WebButton("XPATH://button[@class='primary' and text()='ok']").actionClick();// Remove IE Dialog
					if (!p_admintoolLogin.equals("YES")) {
						m_webDriver.findElement(By.xpath("//input[contains(@id,'toolbarQuickSearch') or @id='searchBox']")).click();
						Thread.sleep(1000);
						m_webDriver.findElement(By.xpath("//input[contains(@id,'toolbarQuickSearch') or @id='searchBox']")).sendKeys(p_clientID);
						Thread.sleep(3000);
						m_webDriver.findElement(By.xpath(".//a/span[text()='" + p_clientID.toLowerCase() + "']")).click();
						Thread.sleep(3000);
						m_webDriver.findElement(By.xpath("//a[text()='Practitioner Access']")).click();
						DDTController.getWebDriverWait().until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='masthead']")));

					}
					break;
				case "myADP-EMPLOYEE":
				case "myADP-MANAGER":
					boolean useAppDriver = DDTController.isMobile() || DDTController.isTablet();

					if (useAppDriver) {
						DDTController.getMobileDriver().context("NATIVE_APP");
						DDTController.setUseAppDriver(true);

						DDTController.getMobileDriver().findElement(By.xpath("//android.widget.EditText[@id='user']")).sendKeys(p_userID);
						DDTController.getMobileDriver().findElement(By.xpath("//android.widget.EditText[@id='password']")).sendKeys(p_pwd);
						DDTController.getMobileDriver().findElement(By.xpath("//android.widget.Button[@id='login']")).click();

						DDTController.getMobileDriverWait().until(ExpectedConditions.visibilityOfElementLocated(By.id("side-toggle")));
					} else {
						m_webDriver.findElement(By.id("user")).sendKeys(p_userID);
						m_webDriver.findElement(By.id("password")).sendKeys(p_pwd);
						m_webDriver.findElement(By.id("login")).click();

						DDTController.getWebDriverWait().until(ExpectedConditions.visibilityOfElementLocated(By.id("side-toggle")));
					}

					break;
				default:
					DDTAssertionError.fail("Unknow Login User Type " + p_UserType, "Environment issue");
				}
				break;
			default:
				DDTAssertionError.fail("Unknow WFN Environment ID: " + DDTController.getWfnEnvironment(), "Environment issue");
			}
			General.sleep(3);
			// output login info
			DDTController.getResultsReporter().addTestStep(" Environment info : " + DDTController.getWfnEnvironment() + " && Login Info -  URL : " + GlobalVariables.getRuntimeURL());
			DDTController.getResultsReporter().endTestStep(StatusType.DONE);
			DDTController.getResultsReporter().addTestStep("CLIENT ID : " + GlobalVariables.getRuntimeClientID() + " && Login Info -  User/Pwd : " + p_userID + "/" + p_pwd);
			DDTController.getResultsReporter().endTestStep(StatusType.DONE);

			// dismiss wlakme Popup
			if (DDTController.getWebDriver().findElements(By.xpath("//div[@class='wm-close-button walkme-x-button']")).size() != 0) {
				if (DDTController.getWebDriver().findElement(By.xpath("//div[@class='wm-close-button walkme-x-button']")).isDisplayed()) {
					DDTController.getWebDriver().findElement(By.xpath("//div[@class='wm-close-button walkme-x-button']")).click();
				}
			}

			// dismiss Bridge Popup
			if (DDTController.getWebDriver().findElements(By.xpath("//span[@id='ssoBridgeGotItButton']")).size() != 0) {
				if (DDTController.getWebDriver().findElement(By.xpath("//span[@id='ssoBridgeGotItButton']")).isDisplayed()) {
					;
					DDTController.getWebDriver().findElement(By.xpath("//span[@id='ssoBridgeGotItButton']")).click();
				}
			}
			// dismiss Benefit Enrollment Popup
			if (DDTController.getWebDriver().findElements(By.xpath("//span[@title='Cancel']")).size() != 0) {
				if (DDTController.getWebDriver().findElement(By.xpath("//span[@title='Cancel']")).isDisplayed()) {
					DDTController.getWebDriver().findElement(By.xpath("//span[@title='Cancel']")).click();
				}
			}

			// Remove IE Warning
			if (new WebButton("XPATH://button[@class='primary' and text()='ok']").exists(3))
				new WebButton("XPATH://button[@class='primary' and text()='ok']").actionClick();// Remove IE Dialog

			// Get Build Number
			if (DDTController.getWebDriver().findElements(By.xpath("//span[contains(@class,'revitFooterContainer')]//span[text()='About']/parent::span")).size() != 0) {
				m_webDriver.findElement(By.xpath("//span[contains(@class,'revitFooterContainer')]//span[text()='About']/parent::span")).click();
				DDTController.getWebDriverWait().until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//strong[contains(text(),'Build Number')]/parent::td")));
				m_CurrentBuildNumber = m_webDriver.findElement(By.xpath("//strong[contains(text(),'Build Number')]/parent::td")).getText();
				m_webDriver.findElement(By.xpath("//*[@class='dijitDialogTitle' and text()='About']/following-sibling::span[@title='Cancel']")).click();
				m_CurrentBuildNumber = m_CurrentBuildNumber.replace("Build Number: ", "").trim();
				GlobalVariables.setBuildNumber(m_CurrentBuildNumber);
				DDTController.getResultsReporter().setBuildNumber(m_CurrentBuildNumber);
				DDTController.getResultsReporter().addTestStep("Build Number :" + GlobalVariables.getRuntimeBuildNumber());
				DDTController.getResultsReporter().endTestStep(StatusType.DONE);
				WebElement webElem = m_webDriver.findElement(By.xpath("//div[@id='masthead']"));
				WebObject adpHome = new WebObject(webElem);
				adpHome.scrollIntoView();
			}

			// Run gemfire
			if (!p_admintoolLogin.equals("YES")) {
				boolean bGemFireNotAvailable = false;
				DDTController.getResultsReporter().addTestStep("Update GemFire Cache");
				GemFireServices genFireSvc = new GemFireServices();
				GemFireUpdateFeaturesParms gfUpdFeatureParms = genFireSvc.new GemFireUpdateFeaturesParms();

				// GemFire service is accessible and returned a valid response.
				GemFireUpdateFeaturesResponse gfRespond;
				gfUpdFeatureParms.setClientId(GlobalVariables.getRuntimeClientID());
				try {
					for (int igfloop = 1; igfloop < 4; igfloop = igfloop + 1) {
						gfUpdFeatureParms.setIdBar("DISABLED");
						gfRespond = genFireSvc.updateFeatures(gfUpdFeatureParms);

						if (gfRespond != null) {
							gfUpdFeatureParms.setIdBar("ENABLED");
							gfRespond = genFireSvc.updateFeatures(gfUpdFeatureParms);

							if (gfRespond != null) {
								m_logger.debug(gfRespond.getStatus());

								if (gfRespond.getStatus().equals("success")) {
									DDTController.getResultsReporter().endTestStep(StatusType.PASSED);
									bGemFireNotAvailable = false;
									break;
								} else {
									bGemFireNotAvailable = true;
								}
							} else {
								bGemFireNotAvailable = true;
							}
						} else {
							bGemFireNotAvailable = true;
						}
					}
				} catch (DDTFrameworkException jsEx) {
					throw jsEx;
				}

				if (bGemFireNotAvailable) {
					DDTController.getResultsReporter().endTestStep(StatusType.DONE);
				}
			}

		} catch (DDTFrameworkException dfEx) {
			GlobalVariables.setResultCode(105);
			throw dfEx;
		} catch (TimeoutException tEx) {
			GlobalVariables.setResultCode(105);
			throw new DDTFrameworkException(WFNLogin.class, "WFN Login timeout error: ", tEx);
		} catch (Exception ex) {
			GlobalVariables.setResultCode(105);
			throw new DDTFrameworkException(WFNLogin.class, "WFN Login error: ", ex.getCause());
		}

		return;
	}

	@Component(Name = "Exit Walkme Popup")
	public void exitWlakmePopup(ParamManager pm) throws DDTFrameworkException {
		DDTController.getWebDriverWait().until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='wm-close-button walkme-x-button']")));
		// dismiss wlakme Popup
		if (DDTController.getWebDriver().findElements(By.xpath("//div[@class='wm-close-button walkme-x-button']")).size() != 0) {
			if (DDTController.getWebDriver().findElement(By.xpath("//div[@class='wm-close-button walkme-x-button']")).isDisplayed()) {
				DDTController.getWebDriver().findElement(By.xpath("//div[@class='wm-close-button walkme-x-button']")).click();
			}
		}
		return;
	}

	// user mapping
	// E_Mode: {Normal, Talent, EZLM}
	private void userMapping(String m_userID, String m_ssn, String m_associateID, E_Mode m_mode) throws DDTFrameworkException {
		String response;
		// FOR NOW ONLY SUPPORT AUTO1/2, IPE full and IPE SLIM
		if (DDTController.getWfnEnvironment().startsWith("AUTO") || DDTController.getWfnEnvironment().startsWith("IPE")) {
			// Calling WebService User Mapping Script
			OracleScriptServicesProxy userMappingOracleScript = new OracleScriptServicesProxy();

			if (!m_ssn.isEmpty()) {
				// SSN
				UserMappingBySSNParams cusermappingSSNParams = userMappingOracleScript.new UserMappingBySSNParams();
				cusermappingSSNParams.setEnvironmentID(GlobalVariables.getDBEnvID());
				cusermappingSSNParams.setChrSecUserID(m_userID);
				cusermappingSSNParams.setSSN(m_ssn);
				cusermappingSSNParams.setMode(m_mode);
				response = userMappingOracleScript.userMappingBySSN(cusermappingSSNParams); // response
																							// is
																							// "SUCCESS"
																							// or
																							// "FAILED";
			} else {
				// Associate ID
				UserMappingByAssocIDParams cusermappingAssociateIDParams = userMappingOracleScript.new UserMappingByAssocIDParams();
				cusermappingAssociateIDParams.setEnvironmentID(GlobalVariables.getDBEnvID());
				cusermappingAssociateIDParams.setChrSecUserID(m_userID);
				cusermappingAssociateIDParams.setAssociateID(m_associateID);
				response = userMappingOracleScript.userMappingByAssociateID(cusermappingAssociateIDParams); // response
																											// is
																											// "SUCCESS"
																											// or
																											// "FAILED";
			}

			if (response.equalsIgnoreCase("FAILED")) {
				DDTAssertionError.fail("User Mapping Failed!", "Environment issue");
			}
		}

		return;

	}

	@Component(Name = "logout of WFN")
	public void Logout(ParamManager p_pm_logout) throws DDTFrameworkException {
		BrowserManager.closeBrowser();
		return;
	}

	@Component(Name = "WFN Page Refresh")
	public void pageRefresh(ParamManager p_pm_refresh) throws DDTFrameworkException {
		if (DDTController.getWebDriver() != null) {
			DDTController.getWebDriver().navigate().refresh();
		}
		DDTController.getWebDriverWait().until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class,'dijitReset dijitInline revitMastheadLogo') or contains(@class,'wfn-masthead')]")));
		return;
	}

	@Component(Name = "Verify Performance Goals Email Content", Params = { "To Email; From Email ; Body Content ; Table_KeyValue; Table_OldValue ; Table_NewValue; Subject" })
	public void verifyPerformanceGoalsEmailContent(ParamManager pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException, MessagingException, IOException {
		String keyValue = pm.Parameter("Table_KeyValue");
		String oldValue = pm.Parameter("Table_OldValue");
		String actualNewValue = pm.Parameter("Table_NewValue");
		String fromEmail = pm.Parameter("From Email");
		String toEmail = pm.Parameter("To Email");
		String folderToLookup = "Inbox/GMail";
		MailBox mailBox = MailBox.ADP_MAIL;
		String bodyContent = pm.Parameter("Body Content");
		String subject = pm.Parameter("Subject");
		FromStringTerm fromStringTerm = new FromStringTerm(fromEmail);
		RecipientStringTerm recipientStringTerm = new RecipientStringTerm(RecipientType.TO, toEmail);
		// FlagTerm unseenFlag = new FlagTerm(new Flags(Flags.Flag.SEEN), true);
		ReceivedDateTerm dateTerm = new ReceivedDateTerm(ComparisonTerm.EQ, new Date());
		SearchTerm[] searchTerms = new SearchTerm[] { fromStringTerm, dateTerm, recipientStringTerm };
		boolean isToMailMatched = false;
		EmailSearcher emailSearch = new EmailSearcher();
		String failedMessage = "Not Matched with Given data";
		Message[] messages = emailSearch.searchMailBox(mailBox, folderToLookup, searchTerms);

		int nMsgs = messages.length;

		if (messages.length != 0) {

			for (int index = nMsgs - 1; index >= 0; index--) {
				Message eMail = messages[index];
				new EmailUtil().dispalyEmailMessage(eMail);
				if (!bodyContent.isEmpty()) {
					if (eMail.getContent().toString().toUpperCase().contains(bodyContent.toString().toUpperCase())) {
						isToMailMatched = true;
						if (!keyValue.isEmpty()) {
							Document reportHTML = Jsoup.parse(eMail.getContent().toString());
							List<Element> keyValues = reportHTML.select("#goal-notification > tbody > tr > td:eq(0)");
							List<Element> OldValues = reportHTML.select("#goal-notification > tbody > tr > td:eq(1)");
							List<Element> newValues = reportHTML.select("#goal-notification > tbody > tr > td:eq(2)");
							Map<String, Map<String, String>> key = new HashMap<>();

							for (Element ele : keyValues) {
								int i = 0;
								Map<String, String> values = new HashMap<>();
								values.put(OldValues.get(i).toString().replace("<td>", "").replace("</td>", ""), newValues.get(i).toString().replace("<td>", "").replace("</td>", ""));
								key.put(ele.toString().replace("</td>", "").replace("<td>", ""), values);
								i++;
							}
							for (String actualCheck : key.keySet()) {

								if (actualCheck.equalsIgnoreCase(keyValue)) {

									Map<String, String> obj = key.get(actualCheck);
									if (obj.keySet().contains(oldValue)) {
										if (obj.get(oldValue).toString().toUpperCase().equals(actualNewValue.toString().toUpperCase())) {
											isToMailMatched = true;
											break;
										}
									} else {
										isToMailMatched = false;
										failedMessage = "Given oldValue is not matched or doesn't exits in Email table";
										break;

									}
								}
							}
							/*
							 * if (!isToMailMatched) { break; }
							 */

						} else {
							break;
						}
					
					}
				} else {
					DDTAssertionError.fail("Email Body is empty");

				}

			}
			if (!isToMailMatched) {
				
				if (failedMessage.isEmpty()) {
					failedMessage = "Email Body NOT matched";
				}

				DDTAssertionError.fail("Email Content is NOT matched, following is the reason:- " + failedMessage);
			}
			// Disconnect
			emailSearch.disconectMailBox();

		} else {
			DDTAssertionError.fail("Email NOT Found with given filter criteria ");

		}
	}

}

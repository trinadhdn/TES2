import java.io.IOException;

import javax.xml.datatype.DatatypeConfigurationException;

import com.adp.wfnddt.aspects.Component;
import com.adp.wfnddt.core.DDTComponentBase;
import com.adp.wfnddt.core.DDTController;
import com.adp.wfnddt.core.DDTFrameworkException;
import com.adp.wfnddt.objectmanager.*;
import com.adp.wfnddt.parammanager.ParamManager;
import com.adp.wfnddt.results.DDTResultsReporter;

public class TableComponents extends DDTComponentBase {
	private DDTResultsReporter results = DDTController.getResultsReporter();
	private ObjectMap objectMap = new ObjectMap();

	public TableComponents() throws DDTFrameworkException {
		loadObjectRepository("Specify OR Path");
		setObjectMap(); // HashMap object required for EnterTableRowData, VerifyTableCellObjectProperties components Only
	}

	// HashMap object required for EnterTableRowData, VerifyTableCellObjectProperties components Only
	// Create HashMap object to pass multiple ActionObjects simultaneously against each column
	private void setObjectMap() {
		objectMap.clearMap();
		objectMap.addObject("Column 1", new WebCheckBox("Specify XPATH here"));
		objectMap.addObject("Column 2", new WebLink("Specify XPATH here"));
		objectMap.addObject("Column n", new WebRadioButton("Specify XPATH here"));
	}

	// Component to simply click link in a table
	@Component(Name = "Click Table Link on [PAGE NAME] page", Params = { "RowToFind_Column 1", "RowToFind_Column n", "Col_Name", "Row_Instance", "Actions", "Row_Number" })
	public void ClickTableLinkOnPAGENAMEPage(ParamManager pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException, InterruptedException {
		ObjectTypes Page = Browser.Page("..."); // Specify page object here - Browser.Page("Benefit Providers Page");
		Page.WebTable("...").clickObjectInTable(pm, new WebLink("XPATH:.//.....")); // Specify object to click with XPATH selector(Use .// at starting of the XPATH)
		
		if (!pm.Parameter("Actions").contentEquals("")) {
			new WebLink("XPATH://A[.='" + pm.Parameter("Actions") + "']").actionClick();
		}
	}

	// Component to enter table row data in a table
	@Component(Name = "Enter Table Row Data on [PAGE NAME] page", Params = { "RowToFind_Column 1", "RowToFind_Column n", "Row_Instance", "RowData_Column 1", "RowData_Column n", "Row_Number" })
	public void EnterTableRowDataonPAGENAMEPage(ParamManager pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException, InterruptedException {
		ObjectTypes Page = Browser.Page("..."); // Specify page object here - Browser.Page("Benefit Providers Page");
		results.startVerificationLogStep();
		Page.WebTable("...").enterDataInTable(pm, objectMap);
		results.endVerificationLogStep();
	}

	// Component to verify Row instance in a table
	@Component(Name = "Verify Table Row Data Instances on [PAGE_NAME] Page", Params = { "RowToFind_Column 1", "RowToFind_Column n", "Number_Of_Instances_To_Find", "Row_Number" })
	public void VerifyTableRowInstanceonPAGENAMEPage(ParamManager pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException, InterruptedException {
		ObjectTypes Page = Browser.Page("..."); // Specify page object here - Browser.Page("Benefit Providers Page");
		results.startVerificationLogStep();
		Page.WebTable("...").verifyRowInstancesInTable(pm);
		results.endVerificationLogStep();
	}

	// Component to verify table cell object properties in a table
	// Parameters Column_Column 1, Column_Column n....are required to verify cell objects in these columns....check for EXISTS/ENABLED/DOESNOTEXIST
	@Component(Name = "Verify Table Cell Object Properties on [PAGE_NAME] Page", Params = { "RowToFind_Column 1", "RowToFind_Column n", "Row_Instance", "Column_Column 1", "Column_Column n" })
	public void VerifyTableCellObjectPropertiesonPAGENAMEPage(ParamManager pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException, InterruptedException {
		ObjectTypes Page = Browser.Page("..."); // Specify page object here - Browser.Page("Benefit Providers Page");
		results.startVerificationLogStep();
		Page.WebTable("...").verifyTableCellObjectProperties(pm, objectMap);
		results.endVerificationLogStep();
	}

	// Component to verify list box contents of a cell in a table
	@Component(Name = "Verify Table List Box Contents on [PAGE_NAME] Page", Params = { "RowToFind_Column 1", "RowToFind_Column n", "Row_Instance", "Col_Name", "Type_Of_Test", "LB_Contents", "Row_Number" })
	public void VerifyTableListBoxContentsonPAGENAMEPage(ParamManager pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException, InterruptedException {
		ObjectTypes Page = Browser.Page("..."); // Specify page object here - Browser.Page("Benefit Providers Page");
		results.startVerificationLogStep();
		Page.WebTable("...").verifyRowDataListBoxContentsInTable(pm, new WebComboBox("XPATH:.//..."));
		results.endVerificationLogStep();
	}

}

package com.adp.wfnddt.components.general;

import java.awt.Color;
import java.io.IOException;
import java.util.List;

import javax.xml.datatype.DatatypeConfigurationException;

import com.adp.wfnddt.aspects.Component;
import com.adp.wfnddt.core.DDTComponentBase;
import com.adp.wfnddt.core.DDTController;
import com.adp.wfnddt.core.DDTFrameworkException;
import com.adp.wfnddt.parammanager.ParamManager;
import com.adp.wfnddt.pdfcomparison.PDFCompareUtil;
import com.adp.wfnddt.pdfcomparison.PDFCompareUtil.CompareMode;
import com.adp.wfnddt.pdfcomparison.PDFImageCompareResult;
import com.adp.wfnddt.pdfcomparison.PDFTextCompareResult;
import com.adp.wfnddt.results.DDTResultsReporter;
import com.adp.wfnddt.results.jaxb.StatusType;

public class PDFValidations extends DDTComponentBase {

	private DDTResultsReporter	m_results	= DDTController.getResultsReporter();
	private PDFCompareUtil		pdfUtil		= new PDFCompareUtil();

	@Component(Name = "Verify Pdf File Content of Application downloaded from AQV Page", Params = { "BASE_FILE_PATH |*^*| Provide valid file path for base pdf",
			"RESULT_FILE_PATH |*^*| Provide valid path of pdf to be compared with" })
	public void verifyPDFFileContentOnAQVPage(ParamManager pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		verifyPDFFileContent(pm.Parameter("BASE_FILE_PATH"), pm.Parameter("RESULT_FILE_PATH"), new String[] { "(Viewed: )[^&]*( Page)" });
	}

	@Component(Name = "Verify Pdf File Content of Application Drop Rate", Params = { "BASE_FILE_PATH |*^*| Provide valid file path for base pdf",
			"RESULT_FILE_PATH |*^*| Provide valid path of pdf to be compared with" })
	public void verifyPDFFileContentonDropRatePage(ParamManager pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		verifyPDFFileContent(pm.Parameter("BASE_FILE_PATH"), pm.Parameter("RESULT_FILE_PATH"), new String[] {});
	}

	public void verifyPDFFileContent(String p_baseFilePath, String p_resultFilePath, String[] regExToIgnore) throws IOException, DatatypeConfigurationException, DDTFrameworkException {

		// pdfUtil.enableLog(); // For Debugging

		m_results.startVerificationLogStep();

		/** TEXT MODE Comparison **/
		pdfUtil.setCompareMode(CompareMode.TEXT_MODE);
		pdfUtil.excludeText(regExToIgnore);

		boolean bFileContentMatched = pdfUtil.comparePDFFileLineByLine(p_baseFilePath, p_resultFilePath);
		List<PDFTextCompareResult> resultList = pdfUtil.getResultsTextCompare();

		if (bFileContentMatched)
			m_results.addEntryToVerificationLog("PDF Comparision - Base File Vs Result File", StatusType.PASSED, "File content matches", "File content matches");
		else {
			for (PDFTextCompareResult result : resultList) {
				if (!result.isCompareStatus())
					m_results.addEntryToVerificationLog(" [ " + result.getLocationOfText() + " ] ", StatusType.FAILED, result.getExpectedText(), result.getActualText());
			}
		}

		/** VISUAL MODE Comparison ( PIXEL Comparison ) **/
		if (!bFileContentMatched) {
			pdfUtil.setImageDestinationPath(DDTController.getScreenshotPath());
			pdfUtil.setCompareMode(CompareMode.VISUAL_MODE);
			pdfUtil.compareAllPages(true);
			pdfUtil.highlightPdfDifference(true);
			pdfUtil.highlightPdfDifference(new Color(255, 0, 0)); 
			pdfUtil.compare(p_baseFilePath, p_resultFilePath);
			if (pdfUtil.getPageMatch()){
				List<PDFImageCompareResult> imgResultList = pdfUtil.getImageCompareResultList();
				for (PDFImageCompareResult imgResult : imgResultList) {
					m_results.addScreenshotCaptureStep(imgResult.getCompareDiffImageFileName());
				}
			}
		}

		m_results.endVerificationLogStep();
	}

}

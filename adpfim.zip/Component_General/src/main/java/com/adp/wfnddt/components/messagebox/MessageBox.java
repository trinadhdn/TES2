package com.adp.wfnddt.components.messagebox;

import static com.adp.wfnddt.commonmethods.General.waitForGridSpinnerToComplete;
import static com.adp.wfnddt.commonmethods.MessageBoxMethods.verifyConfirmActionMessages;

import java.io.IOException;

import javax.xml.datatype.DatatypeConfigurationException;

import com.adp.wfnddt.aspects.Component;
import com.adp.wfnddt.commonmethods.General;
import com.adp.wfnddt.commonmethods.MessageBoxMethods;
import com.adp.wfnddt.core.DDTComponentBase;
import com.adp.wfnddt.core.DDTController;
import com.adp.wfnddt.core.DDTFrameworkException;
import com.adp.wfnddt.objectmanager.WebButton;
import com.adp.wfnddt.objectmanager.WebStatic;
import com.adp.wfnddt.objectmanager.WebTextBox;
import com.adp.wfnddt.parammanager.ParamManager;
import com.adp.wfnddt.results.DDTResultsReporter;
import com.adp.wfnddt.results.jaxb.StatusType;

public class MessageBox extends DDTComponentBase {
	private DDTResultsReporter m_results = DDTController.getResultsReporter();

	@Component(Name = "Verify Popup Message", Params = { "Expected|*^*|Enter expected message", "Exists|*^*|Required!! Valid Values: Yes or No" })
	public void verifyPopupMessage(ParamManager pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		DDTResultsReporter results = DDTController.getResultsReporter();
		// NOTE: For other dialog types just add your class into an or statement in the XPATH
		WebStatic popupMessage = new WebStatic("XPATH://DIV[contains(@class,'dijitDialog') or contains(@class,'vdl-modal-body')]//*[text()=\""+pm.Parameter("Expected")+"\"]");
		popupMessage.setObjectName("Expected");
		popupMessage.waitForVisibility();
		General.sleep(1);
		if (popupMessage.exists())
			popupMessage.getObject();
		String strMessageExists = pm.Parameter("Exists").equalsIgnoreCase("YES") ? "[EXISTS]" : "[DOES_NOT_EXIST]";

		results.startVerificationLogStep();
		popupMessage.verifyObjectProperties(strMessageExists);
		results.endVerificationLogStep();

		return;
	}

	@Component(Name = "Click Button on Message Box", Params = { "Button_To_Click|*^*|Valid Values: OK, CANCEL", "Keys_To_Type|*^*|Keys To ype if needed (Obsolete?)" })
	public void clickButtonOnMessageBox(ParamManager pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		if (pm.Parameter("Button_To_Click").isEmpty()) return;
		WebButton popupButton = new WebButton("XPATH://*[contains(@class,'revitButton') or contains(@class,'vdl-button') or contains(@class,'reactVDL reactButton') or contains(@class,'closeButton')]//*[translate(text(),'abcdefghijklmnopqrstuvwxyz','ABCDEFGHIJKLMNOPQRSTUVWXYZ')='" + pm.Parameter("Button_To_Click").toUpperCase() + "']");

		popupButton.actionClick(); // Click on the pop-up button
		return;
	}

	@Component(Name = "Verify Confirm Action Message", Params = { "Expected", "Reason" })
	public void verifyConfirmActionMessage(ParamManager pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		waitForGridSpinnerToComplete();
		verifyConfirmActionMessages(pm.Parameter("Expected"));
	}

	@Component(Name = "Confirm Action Popup Message Box", Params = { "Button_To_Click|*^*|Valid Values:Yes,No,Close,OK,Confirm", "Reason" })
	public void confirmActionPopupMessageBox(ParamManager pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		waitForGridSpinnerToComplete();
		if (!pm.Parameter("Reason").contentEquals(""))
			General.sleep(3);
		new WebTextBox("XPATH://textarea[@class='dijitTextArea revolutionNoMsClearReveal' and not(ancestor::*[contains(@style,'display: none;')])]").set(pm.Parameter("Reason"));
		if (pm.Parameter("Button_To_Click").contentEquals(""))
			return;
		General.sleep(3);
		if (new WebButton("XPATH://div[(@class='dijitDialogPaneContent' or @class='revitDialogContents') and not ( ancestor::div[contains(@style,'display: none')])]//div[@class='revitButtonBox']//span[text() = '" + pm.Parameter("Button_To_Click") + "']").exists()) {
			new WebButton("XPATH://div[(@class='dijitDialogPaneContent' or @class='revitDialogContents') and not ( ancestor::div[contains(@style,'display: none')])]//div[@class='revitButtonBox']//span[text() = '" + pm.Parameter("Button_To_Click") + "']").actionClick();
		} else if (new WebButton("XPATH://button[. = '" + pm.Parameter("Button_To_Click") + "' or .='" + pm.Parameter("Button_To_Click").toUpperCase() + "' and not (ancestor::*[contains(@style,'display: none')])]").exists()) {
			new WebButton("XPATH://button[. = '" + pm.Parameter("Button_To_Click") + "' or .='" + pm.Parameter("Button_To_Click").toUpperCase() + "' and not (ancestor::*[contains(@style,'display: none')])]").actionClick();
		}
		General.sleep(2);
	}

	@Component(Name = "Click Button on Message Box if Exists", Params = { "Button_To_Click|*^*| Yes, No, Cancel, Leave, SKIP, Save & Exit, SUBMIT" })
	public void clickButtononMessageBoxifExists(ParamManager pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException {

		MessageBoxMethods msgBox = new MessageBoxMethods();
		msgBox.clickOnMessageBoxButtonIfExists(pm.Parameter("Button_To_Click"));
		waitForGridSpinnerToComplete();
	}

	/**
	 * Dismiss Windows Pop Up will dismiss the Windows type pop-up only. Works on MACs too
	 * 
	 * @param None
	 */
	@Component(Name = "Dismiss Windows Pop Up")
	public void dismissPopUp(ParamManager pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		DDTController.getWebDriver().switchTo().alert().dismiss();
	}

	/**
	 * Accept Windows Pop Up will dismiss the Windows type pop-up only. Works on MACs too
	 * 
	 * @param None
	 */
	@Component(Name = "Accept Windows Pop Up")
	public void acceptPopUp(ParamManager pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		DDTController.getWebDriver().switchTo().alert().accept();
	}

	/**
	 * Verify Windows Pop Up Message will verify text on the Windows type pop-up only. Works on MACs too
	 * 
	 * @param Message Text
	 */
	@Component(Name = "Verify Windows Pop Up Message", Params = { "Message Text|*^*| Text of the message to verify"} )
	public void verifyPopUpText(ParamManager pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		String strText = DDTController.getWebDriver().switchTo().alert().getText();
		m_results.startVerificationLogStep();
		if (!strText.equalsIgnoreCase(pm.Parameter("Message Text"))) {
			m_results.addEntryToVerificationLog("Verify Windows Pop Up Message", StatusType.FAILED, pm.Parameter("Message Text"), strText);
		} else {
			m_results.addEntryToVerificationLog("Verify Windows Pop Up Message", StatusType.PASSED, pm.Parameter("Message Text"), strText);
		}
		m_results.endVerificationLogStep();
	}
}

package com.adp.wfnddt.components.general;

import static com.adp.wfnddt.commonmethods.General.switchToChildWindow;
import static com.adp.wfnddt.commonmethods.General.closeChildWindow;
import static com.adp.wfnddt.commonmethods.General.switchToMainWindow;
import javax.xml.datatype.DatatypeConfigurationException;

import com.adp.wfnddt.aspects.Component;
import com.adp.wfnddt.core.DDTComponentBase;
import com.adp.wfnddt.core.DDTFrameworkException;
import com.adp.wfnddt.parammanager.ParamManager;

public class Window extends DDTComponentBase {

	@Component(Name = "Switch to Child Window", Params = {
			"ChildWindow_Title|Child Window Title to which the control will shift to|" })
	public void switchToChildWindowHavingTitle(ParamManager pm)
			throws DatatypeConfigurationException, DDTFrameworkException {
		switchToChildWindow(pm.Parameter("ChildWindow_Title"));
	}

	@Component(Name = "Close Child Window", Params = {
			"ChildWindow_Title|Child Window Title which needs to be closed|" })
	public void closeChildWindowHavingTitle(ParamManager pm)
			throws DatatypeConfigurationException, DDTFrameworkException {
		closeChildWindow(pm.Parameter("ChildWindow_Title"));
	}

	@Component(Name = "Switch to Main Window", Params = {
			"MainWindow_Title|Main Window Title to which the control will shift to|" })
	public void switchToMainWindowHavingTitle(ParamManager pm)
			throws DatatypeConfigurationException, DDTFrameworkException {
		switchToMainWindow(pm.Parameter("MainWindow_Title"));
	}

}

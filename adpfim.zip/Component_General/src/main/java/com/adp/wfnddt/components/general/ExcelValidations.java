package com.adp.wfnddt.components.general;

import com.adp.wfnddt.aspects.Component;
import com.adp.wfnddt.excelcomparison.ExcelCompare;
import com.adp.wfnddt.parammanager.ParamManager;

public class ExcelValidations {

    @Component(Name = "Verify Excel File Contents", Params = { 
	"BASE_FILE_PATH   |*^*| Provide valid file path for baseline spreadsheet",
        "RESULT_FILE_PATH |*^*| Provide valid file path for spreadsheet to be compared with", 
        "SHEET_INDEXES    |*^*| (Optional) Provide Sheet Index(es) to compare",
        "CELL_DATEFORMAT  |*^*| (Optional) Valid values:MM/dd/yyyy, MM/dd/yyyy h:mm" })
    public void verifySpreadSheetContent(ParamManager pm) throws Exception {

	String excelFile1 = pm.Parameter("BASE_FILE_PATH");
	String excelFile2 = pm.Parameter("RESULT_FILE_PATH");
	// remove space before and after each word
	String arrSheetIndex[] = pm.Parameter("SHEET_INDEXES").trim().split("\\s*,\\s*");
	String dateFormatToReadExcelCell = pm.Parameter("CELL_DATEFORMAT").trim();
	dateFormatToReadExcelCell = dateFormatToReadExcelCell.equals("") ? "MM/dd/yyyy" : dateFormatToReadExcelCell;
	String[] strArrayToIgnore = new String[] { "[IGNORE]" };

	ExcelCompare.compareTwoSpreadSheets(excelFile1, excelFile2, arrSheetIndex, dateFormatToReadExcelCell, strArrayToIgnore);

    }

}

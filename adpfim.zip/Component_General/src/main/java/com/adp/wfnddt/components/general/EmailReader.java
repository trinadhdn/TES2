package com.adp.wfnddt.components.general;

import java.io.IOException;
import java.text.ParseException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Flags.Flag;
import javax.mail.search.SearchTerm;
import javax.xml.datatype.DatatypeConfigurationException;

import org.apache.log4j.Logger;

import com.adp.wfnddt.aspects.Component;
import com.adp.wfnddt.core.DDTController.MailBox;
import com.adp.wfnddt.core.DDTComponentBase;
import com.adp.wfnddt.core.DDTController;
import com.adp.wfnddt.core.DDTFrameworkException;
import com.adp.wfnddt.core.DDTLoggerManager;
import com.adp.wfnddt.mailverification.EmailConfig;
import com.adp.wfnddt.mailverification.EmailSearcher;
import com.adp.wfnddt.mailverification.EmailUtil;
import com.adp.wfnddt.parammanager.ParamManager;;

/**
 * @author UbbaraHa Date: 11/13/2018
 * 
 */

public class EmailReader {
    private static Logger m_logger		  = DDTLoggerManager.getLogger(EmailReader.class);
    private EmailSearcher emailSearch		  = new EmailSearcher();
    private static String	  autoXpertFolderToLookup = "Inbox/GMail";
    private static EmailConfig	  autoXpertMailConfig	  = DDTController.getMailConfigAdp();

    @Component(Name = "Fetch and Display Email Content", Params = { "MAILBOX", "MAILFOLDER", "FILTER_SUBJECT", "FILTER_BODY", "FILTER_FROM", "FILTER_RECIPIENT", "RECIPIENT_TYPE",
        "FILTER_RECEIVED_DATE", "FILTER_SENT_DATE", "FILTER_SEEN" })
    public void displayEmailContent(ParamManager pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException, MessagingException, ParseException {

	try {

	    MailBox mailBox = pm.Parameter("MAILBOX").toUpperCase().equals("POCROOT") ? MailBox.POCROOT_MAIL : MailBox.ADP_MAIL;
	    
	    String mailFolder = pm.Parameter("MAILFOLDER");
	    SearchTerm[] searchTerms = emailSearch.prepareSearchTermArray(pm, "FILTER_");

	    Message[] mails = emailSearch.searchMailBox(mailBox, mailFolder, searchTerms);

	    m_logger.debug("No.of Messages:" + mails.length);

	    new EmailUtil().displayEmailMessagesNewestOnTop(mails);

	} finally {
	    // Close the connection to the mail box.
	    emailSearch.disconectMailBox();
	}

    }
    
    
    public  static String getTextFromAutoXpert(SearchTerm[] filterCondidtions, String regEx) throws MessagingException, IOException{
	EmailSearcher emailSearch = new EmailSearcher();
	Message[] messages = emailSearch.searchMailBox(autoXpertMailConfig, autoXpertFolderToLookup, filterCondidtions);
	int nMsgs = messages.length;
	String strReturn = null;
	
	searchForText: 
	if (messages.length != 0) {
	    for (int index = nMsgs - 1; index >= 0; index--) {
		Message eMail = messages[index];
		String mailBody = new EmailUtil().getTextFromMessage(eMail);

		if(regEx.equals(""))
		    return mailBody;
		
		// Subject in English
		Pattern pattern = Pattern.compile(regEx);
		Matcher matcher = pattern.matcher(mailBody);
		while (matcher.find()) {
		    strReturn = matcher.group(1);
		    eMail.setFlag(Flag.SEEN, true);
		    break searchForText;
		}
	    }
	}
	return strReturn;
    }
}
package com.adp.wfnddt.components.general;

import static com.adp.wfnddt.commonmethods.General.verifyOnScreenMessageOrExistanceOnPage;

import java.io.IOException;

import javax.xml.datatype.DatatypeConfigurationException;

import com.adp.wfnddt.aspects.Component;
import com.adp.wfnddt.core.DDTComponentBase;
import com.adp.wfnddt.core.DDTFrameworkException;
import com.adp.wfnddt.parammanager.ParamManager;

public class VerifyOnScreenMessages extends DDTComponentBase {

	@Component(Name = "Verify Onscreen Message on the page", Params = { "Expected_Message|*^*|Required! Valid Values:[ERROR_MESSAGE_DOES_NOT_EXIST] or Specify actual message text", "Is_Error|*^*|Optional! Valid Values:True,False" })
	public void verifyOnscreenMessageOnThePage(ParamManager pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		if (!pm.Parameter("Is_Error").equalsIgnoreCase("")) {
			boolean errorMsg = false;
			if (pm.Parameter("Is_Error").equalsIgnoreCase("true")) {
				errorMsg = true;
			}
			verifyOnScreenMessageOrExistanceOnPage(pm.Parameter("Expected_Message"), errorMsg);
		} else {
			verifyOnScreenMessageOrExistanceOnPage(pm.Parameter("Expected_Message"));
		}
	}

}

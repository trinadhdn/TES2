/**
 * 
 */
package com.adp.wfnddt.components.general;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.text.ParseException;

import javax.xml.datatype.DatatypeConfigurationException;

import org.apache.log4j.Logger;

import com.adp.wfnddt.aspects.Component;
import com.adp.wfnddt.commonmethods.General;
import com.adp.wfnddt.core.DBInteractions;
import com.adp.wfnddt.core.DDTAssertionError;
import com.adp.wfnddt.core.DDTComponentBase;
import com.adp.wfnddt.core.DDTController;
import com.adp.wfnddt.core.DDTFrameworkException;
import com.adp.wfnddt.core.DDTLoggerManager;
import com.adp.wfnddt.core.DDTUtilityFunctions;
import com.adp.wfnddt.core.GlobalVariables;
//import com.adp.wfnddt.core.OutputStream;
import com.adp.wfnddt.core.WFNClientDBDMLServicesProxy;
import com.adp.wfnddt.parammanager.ParamManager;
import com.adp.wfnddt.results.DDTResultsReporter;
import com.adp.wfnddt.results.jaxb.StatusType;
import com.adp.wfnddt.utilities.dmlinfo.DMLEnvInfo;

/**
 * @author Wiermanp
 *
 */
public class WFNClientDDBDMLTest extends DDTComponentBase {
	private static final String JSON_Path = "/RunScript/RunScript.json";
	private static Logger m_logger = DDTLoggerManager.getLogger(WFNClientDDBDMLTest.class);
	// private String m_Environment = "";
	private String m_Instance = "";
	private String m_Schema = "";
	private String m_Password = "";
	private String m_UseSkipVPD = "";

	public void setVariables(String p_DBTopic, String p_DBName) throws DDTFrameworkException {
		try {
			// m_Environment = DDTController.getWfnEnvironment().toUpperCase();
			m_Instance = DMLEnvInfo.loadDMLEnvInfo(WFNClientDDBDMLTest.class, JSON_Path, p_DBTopic, p_DBName, "DB Instance");
			m_Schema = DMLEnvInfo.loadDMLEnvInfo(WFNClientDDBDMLTest.class, JSON_Path, p_DBTopic, p_DBName, "Schema");
			m_Password = DMLEnvInfo.loadDMLEnvInfo(WFNClientDDBDMLTest.class, JSON_Path, p_DBTopic, p_DBName, "Password");
			m_UseSkipVPD = DMLEnvInfo.loadDMLEnvInfo(WFNClientDDBDMLTest.class, JSON_Path, p_DBTopic, p_DBName, "UseSkipVPD");
			return;
		} catch (Exception ex) {
			throw new DDTFrameworkException(WFNClientDDBDMLTest.class, "Exception at setVariables for Run Script", ex);
		}
	}

	@Component(Name = "Run Script", Params = { "SQLFile|*^*|SQL file located in Eclipse starting with /", "ResultFile|*^*|Result file located in Eclipse starting with /. If blank no verification is done", "DBTopic|*^*|Database Topic in JSON file which is below the DMLDatabaseInfo", "DBName|*^*|Name or Environment ID in JSON file which is above Instance. Use [ENV_ID] to default to environment", "VPD_KEY|*^*|Not required!! Use [VPD_KEY] to use the data from refresh WFN client" })
	public void runDML(ParamManager p_pm) throws DDTFrameworkException, DatatypeConfigurationException {
		String strVPDKey = p_pm.Parameter("VPD_KEY");
		String strDBName = p_pm.Parameter("DBName");

		if (strVPDKey.equalsIgnoreCase("[VPD_KEY]"))
			strVPDKey = GlobalVariables.getRuntimeVPDKey();
		if (strDBName.equalsIgnoreCase("[ENV_ID]"))
			strDBName = GlobalVariables.getDBEnvID();
		setVariables(p_pm.Parameter("DBTopic"), strDBName);

		WFNClientDBDMLServicesProxy wcdds = new WFNClientDBDMLServicesProxy() {
			// Process DML results.
			@Override
			public void processResponse(BufferedReader p_RespReader) throws IOException {

				verifyResponse(p_RespReader, p_pm.Parameter("ResultFile"));

				return;
			}
		};

		// Where does this info come from if component needs to be environment
		// neutral?
		// String dbInstanceTns = "wfc28y_svc1";
		// String dbSchema = "WFN10SCH00028";
		// String password = "pxtadpadp";
		// String vpdKey = "1WFN14AUTO1415HBP"; // "1WFN12AUTO0719IQP"; //
		// optional, not null set context.
		// String useSKIPVPD = "No"; // "No" or "Yes";

		// Submit DML command resource. (vpdKey can be null)
		// Will throw a DDTFrameworkException if the script cannot be processed
		// by client
		// proxy or there is a severe server error.
		wcdds.submitDMLCommands(m_Instance, m_Schema, m_Password, strVPDKey, m_UseSkipVPD, p_pm.Parameter("SQLFile")); // "/DMLScripts/DMLCommands.sql");
		return;
	}

	@Component(Name = "Run Script JDBC", Params = { "SQLFile|*^*|SQL file located in Eclipse starting with /. Leave blank if query is given in SQLQuery Parameter", 
			"SQLQuery|*^*|Single Line SQL Querie with out ; at the end, VPD Context execution is taken care. Leave blank if SQLFile Parameter is passed",
			"ResultFile|*^*|Result file located in Eclipse starting with /. If blank no verification is done", 
			"Results|*^*|Result file located in Eclipse starting with /. If blank no verification is done", 
			"DBTopic|*^*|Database Topic in JSON file which is below the DMLDatabaseInfo. If blank will be defaulted to Snapshot Client DB", 
			"DBName|*^*|Name or Environment ID in JSON file which is above Instance. Use [ENV_ID] or leave blank to default to environment", 
			"VPD_KEY|*^*|Optional!! If blank will be defaulted to Client VPD KEY",
			"SkipVPD|*^*|Optional!! Use this to connect as skip vpd user"})
	public void runDMLJDBC(ParamManager p_pm) throws DDTFrameworkException, DatatypeConfigurationException, SQLException, IOException, ParseException {
		String strVPDKey = p_pm.Parameter("VPD_KEY");
		String strResult = p_pm.Parameter("Results");
		String sqlResultExcel = p_pm.Parameter("ResultFile");
		String strDBName = p_pm.Parameter("DBName");
		String strDBToppic = p_pm.Parameter("DBTopic");
		String strSkipVPD = p_pm.Parameter("SkipVPD");
		String sqlstmt = "";
		
		//Failing the test if both SQLQuery and SQLFile are provided
		if (!p_pm.Parameter("SQLQuery").contentEquals("") && !p_pm.Parameter("SQLFile").contentEquals(""))
			DDTAssertionError.fail("Run Script JDBC", "SQLFile or SQLQuery paramater is Manadatory, but not both. Please remove data from any one of the paramater");
		
		if (!p_pm.Parameter("SQLFile").contentEquals("")){
			InputStream dmlInStrm = getClass().getResourceAsStream(p_pm.Parameter("SQLFile"));
			sqlstmt = org.apache.commons.io.IOUtils.toString(dmlInStrm, "UTF-8");
		} else if (!p_pm.Parameter("SQLQuery").contentEquals("")){
			sqlstmt = p_pm.Parameter("SQLQuery");
		}
		
		//Replace Key Words like [VPD_KEY],[ENV_ID],[ORG_ID],[CLIENT_ID]
		sqlstmt = General.replaceParameterKeyWords(sqlstmt);
		
		//Failing the test if any one SQLQuery and SQLFile are not provided
		if (sqlstmt.contentEquals(""))
			DDTAssertionError.fail("Run Script JDBC", "SQLFile or SQLQuery paramater is Manadatory, but not both. Please give data in any one of the paramater");
		//Failing the test if both ResultFile and Results are provided
		if (!strResult.contentEquals("") && !sqlResultExcel.contentEquals(""))
			DDTAssertionError.fail("Run Script JDBC", "Any one of Results Parameter or ResultFile Paramater should be provided, but not both. Please remove data from any one of the paramater");

		if (strDBName.equalsIgnoreCase("[ENV_ID]") || strDBName.equals(""))
			strDBName = GlobalVariables.getDBEnvID();
		if (strDBToppic.equals(""))
			strDBToppic = "Snapshot Client DB";
		if (strSkipVPD.equals(""))
			strSkipVPD = "No";
		if (strVPDKey.equalsIgnoreCase("[VPD_KEY]") || (strDBToppic.equalsIgnoreCase("Snapshot Client DB") && strVPDKey.contentEquals("")))
			strVPDKey = GlobalVariables.getRuntimeVPDKey();

		setVariables(strDBToppic, strDBName);

		DBInteractions dbInteractions = new DBInteractions();
		if (strResult.contentEquals("") && sqlResultExcel.contentEquals(""))
			dbInteractions.runScriptExecutor(sqlstmt, strVPDKey, m_Instance, m_Schema, m_Password, strSkipVPD);
		if (!p_pm.Parameter("Results").contentEquals(""))
			dbInteractions.runScriptVerifySimpleData(sqlstmt, strResult, strVPDKey, m_Instance, m_Schema, m_Password, strSkipVPD);
		if (!p_pm.Parameter("ResultFile").contentEquals("")){
			//Create File to Directory from class Path
			Files.deleteIfExists(Paths.get("c:/temp/SourceData.xlsx"));
			Files.deleteIfExists(Paths.get("c:/temp/destination.xlsx"));
			InputStream xlStream = getClass().getResourceAsStream(p_pm.Parameter("ResultFile"));
			CreateFileFromClassPath(xlStream,new File("c:/temp/SourceData.xlsx"));
			dbInteractions.runScriptVerifyData(sqlstmt, "c:/temp/SourceData.xlsx", strVPDKey, m_Instance, m_Schema, m_Password, strSkipVPD);
		}
	}
	
	private static void CreateFileFromClassPath(InputStream source, File dest) throws IOException {
	    InputStream is = null;
	    OutputStream os = null;
	    try {
	        is = source;
	        os = new FileOutputStream(dest);
	        byte[] buffer = new byte[1024];
	        int length;
	        while ((length = is.read(buffer)) > 0) {
	            os.write(buffer, 0, length);
	        }
	    } finally {
	        is.close();
	        os.close();
	    }
	}


	public void runDMLReturnResponse(ParamManager p_pm) throws DDTFrameworkException, DatatypeConfigurationException {
		String strVPDKey = p_pm.Parameter("VPD_KEY");
		String strDBName = p_pm.Parameter("DBName");

		if (strVPDKey.equalsIgnoreCase("[VPD_KEY]"))
			strVPDKey = GlobalVariables.getRuntimeVPDKey();
		if (strDBName.equalsIgnoreCase("[ENV_ID]"))
			strDBName = GlobalVariables.getDBEnvID();
		setVariables(p_pm.Parameter("DBTopic"), strDBName);

		WFNClientDBDMLServicesProxy wcdds = new WFNClientDBDMLServicesProxy() {
			// Process DML results.
			@Override
			public void processResponse(BufferedReader p_RespReader) throws IOException {

				verifyResponse(p_RespReader, p_pm.Parameter("ResultFile"));

				return;
			}
		};

		wcdds.submitDMLCommands(m_Instance, m_Schema, m_Password, strVPDKey, m_UseSkipVPD, p_pm.Parameter("SQLFile")); // "/DMLScripts/DMLCommands.sql");
		return;
	}

	public BufferedReader returnResponse(String p_ExpLocation) {
		InputStream inpStream = null;
		BufferedReader respStrm = null;

		if (p_ExpLocation.trim().contentEquals(""))
			return respStrm;

		DDTResultsReporter m_results = DDTController.getResultsReporter();

		try {
			inpStream = this.getClass().getResourceAsStream(p_ExpLocation);

			if (inpStream != null) {
				long lLen = DDTUtilityFunctions.getResourceLength(inpStream);
				inpStream.close();
				inpStream = null;

				if (lLen > 0) {
					inpStream = this.getClass().getResourceAsStream(p_ExpLocation);
					respStrm = new BufferedReader(new InputStreamReader(inpStream, "UTF-8"));
				} else {
					m_results.addTestStep("VERIFY DML");
					m_results.startVerificationLogStep();
					m_results.addEntryToVerificationLog("Verification of DML File", StatusType.DONE, "Expected Result File Existence", "Result File Not Found or Length was 0");
					m_results.endVerificationLogStep(StatusType.DONE);
					m_results.endTestStep(StatusType.DONE);
				}
			} else { // no Expected Response File
				m_results.addEntryToVerificationLog("Verification of RunDML", StatusType.FAILED, "Missing ResultFile Parameter", "Missing ResultFile Parameter");
				m_results.endVerificationLogStep(StatusType.FAILED);
				m_results.endTestStep(StatusType.FAILED);
			}
		} catch (Exception e) {
			m_logger.error("Failed on verifyResponse for DML", e);
		}

		return respStrm;
	}

	private void verifyResponse(BufferedReader p_Response, String p_ExpLocation) {
		if (p_ExpLocation.trim().contentEquals(""))
			return; // mallelak returning without verifying if response file
					// path is blank or not provided
		DDTResultsReporter m_results = DDTController.getResultsReporter();
		InputStream inpStream = null;
		BufferedReader respStrm = null;
		boolean bEOF = false;
		boolean blnPassed = true;

		try {
			inpStream = this.getClass().getResourceAsStream(p_ExpLocation);

			if (inpStream != null) {
				long lLen = DDTUtilityFunctions.getResourceLength(inpStream);
				inpStream.close();
				inpStream = null;

				if (lLen > 0) {
					inpStream = this.getClass().getResourceAsStream(p_ExpLocation);
					respStrm = new BufferedReader(new InputStreamReader(inpStream, "UTF-8"));
				} else {
					m_results.addTestStep("VERIFY DML");
					m_results.startVerificationLogStep();
					m_results.addEntryToVerificationLog("Verification of DML File", StatusType.DONE, "Expected Result File Existence", "Result File Not Found or Length was 0");
					m_results.endVerificationLogStep(StatusType.DONE);
					m_results.endTestStep(StatusType.DONE);
				}

				m_results.addTestStep("VERIFY DML");
				m_results.startVerificationLogStep();
				while (!bEOF) {
					String strActual = p_Response.readLine();
					String strExpected = respStrm.readLine();
					if (strActual == null && strExpected == null) { // check for
																	// EOF on
																	// both
																	// files
						bEOF = true;
						break;
					} else if (strExpected == null) { // One side has null - not
														// allowed!
						bEOF = true;
						blnPassed = false;
						strExpected = "Result file does not have enough lines";
					} else if (strActual == null) { // One side has null - not
													// allowed!
						bEOF = true;
						blnPassed = false;
						strActual = "Actual file does not have enough lines - check Results file for extra blank lines";
					} else if (strExpected.contentEquals(strActual)) {
						blnPassed = true;
					} else {
						blnPassed = false;
					}
					if (blnPassed) {
						m_results.addEntryToVerificationLog("Verification of DML Line", StatusType.PASSED, strExpected, strActual);
					} else {
						m_results.addEntryToVerificationLog("Verification of DML Line", StatusType.FAILED, strExpected, strActual);
					}
				}
				if (blnPassed) {
					m_results.endVerificationLogStep(StatusType.PASSED);
					m_results.endTestStep(StatusType.PASSED);
				} else {
					m_results.endVerificationLogStep(StatusType.FAILED);
					m_results.endTestStep(StatusType.FAILED);
				}
			} else { // no Expected Response File
				m_results.addEntryToVerificationLog("Verification of RunDML", StatusType.FAILED, "Missing ResultFile Parameter", "Missing ResultFile Parameter");
				m_results.endVerificationLogStep(StatusType.FAILED);
				m_results.endTestStep(StatusType.FAILED);
			}
		} catch (Exception e) {
			m_logger.error("Failed on verifyResponse for DML", e);
		} finally {
			if (inpStream != null) {
				try {
					if (inpStream != null) {
						inpStream.close();
					}
				} catch (IOException e) {
					m_logger.error(String.format("Failed to close the %1$s resource.", p_ExpLocation), e);
				}
			}
		}

		return;
	}

}

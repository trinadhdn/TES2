import java.io.IOException;

import javax.xml.datatype.DatatypeConfigurationException;

import com.adp.wfnddt.aspects.Component;
import com.adp.wfnddt.core.DDTComponentBase;
import com.adp.wfnddt.core.DDTController;
import com.adp.wfnddt.core.DDTFrameworkException;
import com.adp.wfnddt.objectmanager.*;
import com.adp.wfnddt.objectmanager.BaseObject.ClickType;
import com.adp.wfnddt.parammanager.ParamManager;
import com.adp.wfnddt.results.DDTResultsReporter;


public class CardComponents extends DDTComponentBase {
	private DDTResultsReporter results = DDTController.getResultsReporter();
	
	public CardComponents() throws DDTFrameworkException {
		loadObjectRepository("Specify OR Path");
	}

	private ObjectMap getStandardEmployeeActivityMap() {// Example - Setup->Approval Process->Activity Configuration
		// Define ObjectMap for Standard Employee Activity
		ObjectMap standardEmployeeActivityDataMap = new ObjectMap();
		standardEmployeeActivityDataMap.addObject("STANDARD ACTIVITY NAME", new WebObject("XPATH:.//div[@id='ellipse']"));
		standardEmployeeActivityDataMap.addObject("EDIT", new WebObject("XPATH:.//I[@class='fa fa-pencil-square-o fa-stack-1x fa-inverse']"));
		standardEmployeeActivityDataMap.addObject("COPY", new WebObject("XPATH:.//I[@class='fa fa-files-o fa-stack-1x fa-inverse']"));
		return standardEmployeeActivityDataMap;
	}

	private ObjectMap getEnrollmentMap() {// Example - People->Benefits->Enrollments
		// Define Enrollment ObjectMap
		ObjectMap getEnrollmentMap = new ObjectMap();
		getEnrollmentMap.addObject("Plan", new WebButton("XPATH:.//td[3]/div[contains(@class,'BPEEllipsis BPE')]"));
		getEnrollmentMap.addObject("Coverage level", new WebButton("XPATH:.//td[4]/div[contains(@class,'BPEEllipsis BPE')]/span"));
		getEnrollmentMap.addObject("Effective Date", new WebButton("XPATH:.//td[5]"));
		getEnrollmentMap.addObject("COL_6", new WebButton("XPATH:.//td[6]/a[contains(@class,'BPEActionLink')]"));
		return getEnrollmentMap;
	}
	
	
	private ObjectMap getSelectedOEPeriodMap() {//Example - Setup->Benefits->Open Enrollment Center
		// Define ObjectMap for OE Period
		ObjectMap selectedOEPeriodMap = new ObjectMap();
		selectedOEPeriodMap.addObject("Enrollment_Name", new WebObject("XPATH:.//div[contains(@id,'.EnrollmentName.wrapper')]"));
		selectedOEPeriodMap.addObject("Delete", new WebButton("CSS:span.fa.fa-trash-o"));
		selectedOEPeriodMap.addObject("Edit", new WebButton("CSS:span.fa.fa-pencil, i.fa.fa-pencil"));
		selectedOEPeriodMap.addObject("Coverage_Start_Date",new WebObject("XPATH:.//DIV[contains(@id,'.CoverageStartDate')]"));
		selectedOEPeriodMap.addObject("Enrollment_Start_Date",new WebObject("XPATH:.//DIV[contains(@id,'.EnrollmentStartDate.wrapper')]"));
		selectedOEPeriodMap.addObject("Enrollment_End_Date", new WebObject("XPATH:.//DIV[contains(@id,'.EnrollmentEndDate.wrapper')]"));
		selectedOEPeriodMap.addObject("Enrollment_Status", new WebObject("XPATH:.//DIV[contains(@id,'.Status.wrapper')]"));
		selectedOEPeriodMap.addObject("Continue Setup", new WebButton("XPATH:.//*[text()='CONTINUE SETUP' and contains(@id,'.StartEnrollmentBtn.label')]"));
		selectedOEPeriodMap.addObject("View Setup", new WebButton("XPATH:.//*[text()='VIEW SETUP' and contains(@id,'.StartEnrollmentBtn.label')]"));		
		selectedOEPeriodMap.addObject("Expand",new WebButton("XPATH:.//span[contains(@id,'.oe_metric_expand.iconWrapper')]"));
		return selectedOEPeriodMap;
	}
	
	private ObjectMap listObjectMap() {// Example - 
		ObjectMap listObjectMap = new ObjectMap();
		listObjectMap.addObject("STANDARD ACTIVITY NAME", new WebObject("XPATH:.//div[@id='ellipse']"));
		listObjectMap.addObject("EDIT", new WebObject("XPATH:.//I[@class='fa fa-pencil-square-o fa-stack-1x fa-inverse']"));
		listObjectMap.addObject("COPY", new WebObject("XPATH:.//I[@class='fa fa-files-o fa-stack-1x fa-inverse']"));
		return listObjectMap;
	}
	
	
	//***Working with CARD Objects***These are standard objects & to be taken care before creating all the CARD components
	//String cardSelector --> Specify the XPATH of each CARD/ROW to be identified
	//Browser.Page.WebCard("...") --> WebCard added in JSON/OR should be parent object & should identify all the CARDs with in that parent object.
	

	// This Component is to simply click on the object in a card or to Enter some data in the CARD
	@Component(Name = "Enter Card Data on [PAGE NAME] Page", Params = { "CardToFind_Field 1", "CardToFind_Field n", "Card_Instance", "CardData_Field 1", "CardData_Field n", "Button_To_Click", "Actions" })
	public void EnterCardDataOnPAGENAMEPage(ParamManager pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException, InterruptedException {
		String cardSelector = "XPATH:.//div[@class='col-xs-12 col-sm-6 col-md-4 card ng-scope']"; // Specify the XPATH for each CARD/ROW to be identified
		Browser.Page("...").WebCard("Employee Activities").enterDataInCard(pm, cardSelector, getStandardEmployeeActivityMap(), ClickType.Actions);
	}

	// This Component is for CARDs that looks similar to WebTables on the UI. The Parameter "Button_To_Click" should have <Column Name> as the value.
	// Case where an object under the specified column needs to be clicked
	@Component(Name = "Enter Card Data on Benefit Enrollments Page", Params = { "CardToFind_Plan", "CardToFind_Coverage Level", "CardToFind_Effective Date", "Card_Instance", "CardData_Plan", "Button_To_Click", "Actions" })
	public void enterCardDataonBenefitEnrollmentsPage(ParamManager pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException, InterruptedException {
		String cardSelector = "XPATH:.//tr[contains(@class,'BPEDetailedPlanGridRow')]"; // Specify the XPATH for each CARD/ROW to be identified
		Browser.Page("Benefit Providers Page").WebCard("Benefit Enrollments Card").enterDataInCard(pm, cardSelector, getEnrollmentMap());
		if (pm.Parameter("Actions") != null) {
			new WebLink("XPATH://*[text() = '" + (pm.Parameter("Actions")) + "']").actionClick();
		}
	}
	

	// This Component is to Verify CARD/ROW Instance on the Page
	@Component(Name = "Verify Card Data on Benefit Enrollments Page", Params = { "CardToFind_Plan, CardToFind_Coverage Level, CardToFind_Effective Date, Number_Of_Instances_To_Find" })
	public void verifyCardDataonBenefitEnrollmentsPage(ParamManager pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		String cardSelector = "XPATH:.//tr[contains(@class,'BPEDetailedPlanGridRow')]";
		results.startVerificationLogStep();
		Browser.Page("Benefit Providers Page").WebCard("Benefit Enrollments Card").verifyCardInstances(pm, cardSelector, getEnrollmentMap());
		results.endVerificationLogStep();
	}

	
	// This Component is to Verify Card Object properties on the Page
	@Component(Name = "Verify CARD Object Properties on OE Periods Page", Params = { "CardToFind_Open Enrollment Name|*^*|Required!!! Enter Unique Period Name for Row to Find",
				"CardToFind_Coverage Effective Date|*^*|Valid Value: Enter Valid Coverage Start Date for Row to Find",
				"CardToFind_OE Start Date|*^*|Valid Values: Enter Valid Enrollment Start Date for Row to Find",
				"CardToFind_OE End Date|*^*|Valid Values: Enter Valid Enrollment End Date for Row to Find",
				"Card_Instance|*^*| Valid Values: Numeric Value",
				"CardObject_Edit|*^*| Valid Values: [EXISTS],[DOESNOTEXIST],[ENABLED],[DISABLED]",
				"CardObject_Delete|*^*| Valid Values: [EXISTS],[DOESNOTEXIST],[ENABLED],[DISABLED]",
				"CardObject_Continue Setup|*^*| Valid Values: [EXISTS],[DOESNOTEXIST],[ENABLED],[DISABLED]",
				"CardObject_View Setup|*^*| Valid Values: [EXISTS],[DOESNOTEXIST],[ENABLED],[DISABLED]", })
	public void VerifyCARDObjectPropertiesonOEPeriodsPage(ParamManager pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		String cardSelector = "XPATH:.//div[contains(@id,'OEPlanning.OEPeriods_0.OEPeriod_') and contains(@id,'_VIEWMULTIWRAPPER')]";
		results.startVerificationLogStep();
		Browser.Page("Open Enrollment Center").WebCard("OpenEnrollment").verifyObjectPropertiesInCard(pm, cardSelector, getSelectedOEPeriodMap());
		results.endVerificationLogStep();
	}
	
	//This Component is to Verify CARD List Box Contents on the Page
	@Component(Name = "Verify Card List Box Contents on [PAGE_NAME] Page", Params = { "CardToFind_Field 1", "CardToFind_Field n", "Card_Instance", "CardObject_Field", "Type_Of_Test", "LB_Contents"})
	public void VerifyCardListBoxContentsOnPAGENAMEPage(ParamManager pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException, InterruptedException {
		String cardSelector = "XPATH:.//..."; // Specify the XPATH for each CARD/ROW to be identified
		results.startVerificationLogStep();
		Browser.Page("...").WebCard("...").verifyListBoxContentsInCard(pm, cardSelector, listObjectMap());
		results.endVerificationLogStep();
	}
	
	
	//Following example of Drag and Drop item using WebCard method
	private ObjectMap ManagerDirectReport() {
		ObjectMap m_objectMap = new ObjectMap();
		m_objectMap.clearMap();
		m_objectMap.addObject("Source", new WebObject("XPATH:.//div[contains(@class,'name-wrapper')]"));
		m_objectMap.addObject("Target", new WebObject("XPATH:.//div[contains(@class,'name-wrapper')]"));
		m_objectMap.addObject("EmployeeList", new WebComboMultiSelect("XPATH:.//div[contains(@class,'term-employee-list-wrapper')]"));
		return m_objectMap;
	}
	@Component(Name = "Enter Data on Assigning Direct Report",Params = { "Source","Target","ItemsToMove|*^*|[MOVEALL], item1;item2..etc" })
	public void Test_DragDrop(ParamManager pm)throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		String cardSelector = "XPATH:.//div[@class='term-avatar-card']";
		new WebCard ("XPATH://div[@class='term-team-reassignment-manager-cards']").DragAndDrop(cardSelector, ManagerDirectReport(),pm.Parameter("Source"), pm.Parameter("Target"), pm.Parameter("ItemsToMove"));
	}
	
	//Verify draggable employee list.
	@Component(Name = "Verify Data on Manager direct report employee list",Params = { "Name of Manager","EmployeesToVerify|*^*|item1;item2..etc" })
	public void TestVerifyDraggablelist(ParamManager pm)throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		results.startVerificationLogStep();
		String cardSelector = "XPATH:.//div[@class='term-avatar-card']";
		pm.setRunTimeMap(true);
		pm.setParameter("CardTOFIND_SOURCE", pm.Parameter("Name of Manager"));
		pm.setParameter("CARDOBJECT_EMPLOYEELIST", "EMPLOYEELIST");
		pm.setParameter("LB_CONTENTS", pm.Parameter("EmployeesToVerify"));
		pm.setParameter("TYPEOFTEST", "[EXACT]");
		new WebCard ("XPATH://div[@class='term-team-reassignment-manager-cards']").verifyListBoxContentsInCard(pm, cardSelector, ManagerDirectReport());
		results.endVerificationLogStep();
	}
}

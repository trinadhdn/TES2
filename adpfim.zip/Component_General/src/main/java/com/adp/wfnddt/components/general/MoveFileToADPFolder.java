package com.adp.wfnddt.components.general;

import static com.adp.wfnddt.commonmethods.General.sleep;
import static com.adp.wfnddt.commonmethods.General.waitForGridSpinnerToComplete;
import static com.adp.wfnddt.commonmethods.General.replaceParameterKeyWords;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.datatype.DatatypeConfigurationException;

import org.openqa.selenium.WebDriver;

import com.adp.wfnddt.aspects.Component;
import com.adp.wfnddt.commonmethods.DialogMethods;
import com.adp.wfnddt.commonmethods.General;
import com.adp.wfnddt.commonmethods.Navigation;
import com.adp.wfnddt.core.DDTComponentBase;
import com.adp.wfnddt.core.DDTController;
import com.adp.wfnddt.core.DDTFrameworkException;
import com.adp.wfnddt.core.GlobalVariables;
import com.adp.wfnddt.objectmanager.BaseObject.ClickType;
import com.adp.wfnddt.objectmanager.ObjectTypes;
import com.adp.wfnddt.objectmanager.WebButton;
import com.adp.wfnddt.parammanager.ParamManager;
//import com.adp.wfnddt.results.DDTResultsReporter;

public class MoveFileToADPFolder extends DDTComponentBase {

	protected static WebDriver m_webdriver = DDTController.getWebDriver();
	private static final String OR_Path = "/Objects/Utilities/Process_Utilities.json";
	//private DDTResultsReporter m_results = DDTController.getResultsReporter();

	public MoveFileToADPFolder() throws DDTFrameworkException {
		loadObjectRepository(OR_Path);
	}

	@Component(Name = "Move File To ADP Folder", Params = { "CoCode|*^*|Required! Must match with company code from StartBPT", "OriginalFileLocationAndName|*^*|Required! file must be in automation shared drive . Ex: ", "FileIsEncrypted", "DestinationPath|*^*|specify path here, must end with a  use   for client DB location", "Import_Category|*^*|Leave it blank for Employee Import, Valid Value: Benefit Plan,Time Off Accruals, Paydata, Validation Tables, Partner Access, ADPDATA ADPDATA: is direct copy file to adpdata folder" })
	public void moveFileToADPFolder(ParamManager pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException, InterruptedException, ParseException {

		General.sleep(10);

		String destinationPath;
		String renameFile;
		String overwriteCoCode;
		String originalFileLocationAndName = pm.Parameter("OriginalFileLocationAndName").toUpperCase();
		String importCategory = pm.Parameter("Import_Category").toUpperCase();
		String localTempFolder = "C:/QC_Temp/";
		String companyCode = pm.Parameter("CoCode");
		String newCompanyCode;
		String originalFileName;
		String originalCoCode;
		String loadFilesPath = GlobalVariables.getLoadFileUNCDrive();
		String sellingRegion = GlobalVariables.getSellingRegion();
		String vPDKey = GlobalVariables.getRuntimeVPDKey();
		String companyCodeFilePath;
		String filePath;
		String automationDrive = "\\\\cdlisilon01-cifs.cdl.rose.us.adp\\wfn\\Automation";

		Navigation nav = new Navigation();
		ObjectTypes Page;

		// Create Temp Folder if not exists
		File directory = new File(localTempFolder);
		if (!directory.exists()) {
			directory.mkdirs();
		}

		// Need to recreate logic of GetEnviInfo
		newCompanyCode = companyCode;

		String originalFileNameArray[] = originalFileLocationAndName.split("\\\\");
		originalFileName = originalFileNameArray[originalFileNameArray.length - 1];

		if (importCategory.contentEquals("TIME OFF ACCRUALS") || companyCode.length() == 4) {
			originalCoCode = newCompanyCode;
		} else if (importCategory.contentEquals("VALIDATION TABLES")) {
			if (!originalFileName.substring(5, 6).contentEquals("_")) {
				if (newCompanyCode.contentEquals(companyCode)) {
					originalCoCode = companyCode;
				} else {
					originalCoCode = originalFileName.substring(3, 5);
				}
			} else if (originalFileName.substring(3, 5).contentEquals("___")) {
				originalCoCode = companyCode;
			} else {
				originalCoCode = originalFileName.substring(3, 4);
			}
		} else {
			if (originalFileName.substring(0, 3).contentEquals("EMP") || originalFileName.substring(0, 3).contentEquals("EPI") || originalFileName.substring(0, 3).contentEquals("VAL")) {
				originalCoCode = originalFileName.substring(3, 6);
			} else if (originalFileName.substring(0, 4).contentEquals("PLAN") || originalFileName.substring(0, 3).contentEquals("BPI")) {
				originalCoCode = originalFileName.substring(4, 7);
			} else {
				originalCoCode = originalFileName.substring(2, 5);
			}
		}

		// Rename the File
		if (newCompanyCode.length() == 2) {
			renameFile = originalFileName.replace(originalCoCode, newCompanyCode + "_");
			overwriteCoCode = newCompanyCode + " ";
		} else {
			renameFile = originalFileName.replace(originalCoCode, newCompanyCode);
			overwriteCoCode = newCompanyCode;
		}

		// Load File Path
		companyCodeFilePath = loadFilesPath + "\\" + sellingRegion + "\\" + vPDKey + "\\" + newCompanyCode;
		filePath = companyCodeFilePath + "\\AdpData";
		directory = new File(localTempFolder + "/Temp/");
		if (!directory.exists()) {
			directory.mkdirs();
		}

		// Copy File to Local
		Files.copy(Paths.get(automationDrive + originalFileLocationAndName), Paths.get(localTempFolder + "Temp/" + renameFile), StandardCopyOption.REPLACE_EXISTING);

		// decrypt file if needed
		// TODO

		// Modify Contents of File
		File newFile = new File(localTempFolder + renameFile);
		newFile.deleteOnExit();
		newFile.createNewFile();
		newFile.setWritable(true);

		File readerFile = new File(localTempFolder + "Temp/" + renameFile);
		readerFile.setReadable(true);
		List<String> lines = Files.readAllLines(readerFile.toPath(), StandardCharsets.UTF_8);

		String convertedLine,convertedCol;
		List<String> convertedLines = new ArrayList<>();
		List<String> convertedCols = new ArrayList<>();
		for (String line : lines) {
            convertedLine = line.replace("<", "[").replace(">", "]");
            for (String col: convertedLine.split(",")){
               convertedCol = replaceParameterKeyWords(col.replace(originalCoCode, overwriteCoCode));
               convertedCols.add(convertedCol);
            }
            convertedLine = String.join(",",convertedCols); 
            convertedCols.clear();
            convertedLines.add(convertedLine);
		}
		Files.write(newFile.toPath(), convertedLines);

		// Files.copy(Paths.get(automationDrive + originalFileLocationAndName),Paths.get(localTempFolder + renameFile),StandardCopyOption.REPLACE_EXISTING);

		switch (importCategory) {
		case "TIME OFF ACCRUALS":
			nav.navigateToPage("Process", "Import");
			Page = Browser.Page("Import - Employees");
			Page.WebButton("TimeOffAccurals_LefNav").click("CLICK", "CLICK", ClickType.Actions);
			Page.WebButton("Add").click("Add", "Add", ClickType.Actions);
			new WebButton("XPATH://SPAN[@id='show_upload_form_label']").actionClick();
			waitForGridSpinnerToComplete();
			sleep(2);
			new WebButton("XPATH://DIV[@class='uploaderInsideNode']").actionClick();
			DialogMethods.uploadFile(localTempFolder.replace("/", "\\") + renameFile);
			waitForGridSpinnerToComplete();
			sleep(2);
			new WebButton("XPATH://SPAN[@id='import_file_upload_hSubmit_label']").actionClick();
			waitForGridSpinnerToComplete();
			sleep(2);
			new WebButton("XPATH://SPAN[@id='aeSaveDetailButton_label']").actionClick();
			break;
		case "VALIDATION TABLES":
			break;
		case "PAYDATA":
			nav.navigateToPage("Process", "Import");
			Page = Browser.Page("Import - Employees");
			Page.WebButton("Paydata_LefNav").click("CLICK", "CLICK", ClickType.Actions);
			Page.WebButton("Add").click("Add", "Add", ClickType.Actions);
			new WebButton("XPATH://SPAN[@id='show_upload_form_label']").actionClick();
			waitForGridSpinnerToComplete();
			sleep(2);
			new WebButton("XPATH://DIV[@class='uploaderInsideNode']").actionClick();

			DialogMethods.uploadFile(localTempFolder.replace("/", "\\") + renameFile);
			waitForGridSpinnerToComplete();
			sleep(2);
			new WebButton("XPATH://SPAN[@id='import_file_upload_hSubmit_label']").actionClick();
			waitForGridSpinnerToComplete();
			sleep(2);
			new WebButton("XPATH://SPAN[@id='aeSaveDetailButton_label']").actionClick();
			break;
		case "BENEFIT PLAN":
			break;
		case "PARTNER ACCESS":
			break;
		default:
			if (originalFileLocationAndName.contains(".DET") || originalFileLocationAndName.contains(".DCS") || originalFileLocationAndName.contains(".ESS") || originalFileLocationAndName.contains(".LDF") || originalFileLocationAndName.contains(".DBA") || originalFileLocationAndName.contains(".YE2") || originalFileLocationAndName.contains(".YEP") || importCategory.contentEquals("ADPDATA")) {
				if (pm.Parameter("DestinationPath").contentEquals("[CLIENTDATABASE]")) {
					destinationPath = filePath + "\\" + renameFile;
				} else {
					destinationPath = pm.Parameter("DestinationPath") + renameFile;
				}
				Files.copy(Paths.get(localTempFolder + renameFile), Paths.get(destinationPath), StandardCopyOption.REPLACE_EXISTING);
			} else {
				// EE Import Logic
				nav.navigateToPage("Process", "Import");
				Page = Browser.Page("Import - Employees");
				Page.WebButton("EmployeeData_LefNav").click("Employees", "Employees", ClickType.Actions);
				Page.WebButton("Add").click("Add", "Add", ClickType.Actions);
				new WebButton("XPATH://SPAN[@id='show_upload_form_label']").actionClick();
				waitForGridSpinnerToComplete();
				sleep(2);
				new WebButton("XPATH://DIV[@class='uploaderInsideNode']").actionClick();
				DialogMethods.uploadFile(localTempFolder.replace("/", "\\") + renameFile);
				waitForGridSpinnerToComplete();
				sleep(2);
				new WebButton("XPATH://SPAN[@id='import_file_upload_hSubmit_label']").actionClick();
				waitForGridSpinnerToComplete();
				sleep(2);
				new WebButton("XPATH://SPAN[@id='aeSaveDetailButton_label']").actionClick();
			}
			break;
		}
	}
}

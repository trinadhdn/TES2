package com.adp.wfnddt.utilities.dmlinfo;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import com.adp.wfnddt.core.DDTFrameworkException;
import com.adp.wfnddt.webapi.rest.TestRestAPI;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class DMLEnvInfo {

	public static String loadDMLEnvInfo(Class<?> classObj, String p_RunScriptJSON_Path, String p_DBInfo, String p_Instance, String p_Property) throws DDTFrameworkException{
		BufferedReader br;
		JsonObject object = null;
		JsonArray jsonEnvInfo = null;
		JsonArray jsonFeature = null;
		String jsonPrimitiveValue = null;

		try {
			InputStream in = classObj.getResourceAsStream(p_RunScriptJSON_Path);
			br = new BufferedReader(new InputStreamReader(in));
			JsonParser parser = new JsonParser();
			object = parser.parse(br).getAsJsonObject();
			jsonEnvInfo = object.getAsJsonArray("DMLDatabaseInfo");
			jsonFeature = jsonEnvInfo.get(0).getAsJsonObject().getAsJsonArray(p_DBInfo); //Get DB Name jsonObject first
			jsonPrimitiveValue = jsonFeature.get(0).getAsJsonObject().get(p_Instance).getAsJsonObject().getAsJsonPrimitive(p_Property).getAsString();			

			br.close();
			in.close();
			return jsonPrimitiveValue;
		} catch (Exception e) {
			throw new DDTFrameworkException(TestRestAPI.class, "Unable to process JSON object file: " + p_RunScriptJSON_Path, e);  
		}
	}
}

package com.adp.wfnddt.components.general;
//testing - pan
import static com.adp.wfnddt.commonmethods.General.sleep;
import static com.adp.wfnddt.commonmethods.General.waitForGridSpinnerToComplete;
import static com.adp.wfnddt.commonmethods.General.captureScreenshot;
import static com.adp.wfnddt.commonmethods.General.replaceParameterKeyWords;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.xml.datatype.DatatypeConfigurationException;
import org.openqa.selenium.By;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.adp.wfnddt.aspects.Component;
import com.adp.wfnddt.commonmethods.DialogMethods;
import com.adp.wfnddt.commonmethods.Navigation;
import com.adp.wfnddt.core.DDTComponentBase;
import com.adp.wfnddt.core.DDTController;
import com.adp.wfnddt.core.DDTFrameworkException;
import com.adp.wfnddt.core.GlobalVariables;
import com.adp.wfnddt.core.DDTController.BrowserType;
import com.adp.wfnddt.excelcomparison.ExcelCompare;
import com.adp.wfnddt.objectmanager.ObjectTypes;
import com.adp.wfnddt.objectmanager.WebButton;
import com.adp.wfnddt.objectmanager.WebComboBox;
import com.adp.wfnddt.objectmanager.WebLink;
import com.adp.wfnddt.objectmanager.WebObject;
import com.adp.wfnddt.objectmanager.WebTextBox;
import com.adp.wfnddt.parammanager.ParamManager;
import com.adp.wfnddt.results.DDTResultsReporter;
import com.adp.wfnddt.results.jaxb.StatusType;

import jcifs.smb.SmbFile;

public class General extends DDTComponentBase {
	protected WebDriver m_webdriver = DDTController.getWebDriver();
	private String OR_Path = "/Objects/Employee Search/Advanced Search.json";
	DDTResultsReporter m_results = DDTController.getResultsReporter();
	private DDTResultsReporter results = DDTController.getResultsReporter();
	PDFValidations pdfValidations = new PDFValidations();

	//None function component, just for informational only
	@Component(Name = "Test Case Information", Params = { "TestCase_Name", "TestCase_Number|*^*|Required: Rally Test Case ID", "User_Story", "Pre_Conditions", "Validation_Input", "Expected_Results",
			//Do not use the following parameters just for compatible with older group iteration
			"ITERATION_OBJECTIVE","ITERATION_NOTES","AGILE_TEST_CASE_NUMBER","ITERATION_PRIORITY","BFULL_RECOVERY","START_ITERATION_DIRECTIVES"})
	public void testCaseInformation(ParamManager pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		// Do Nothing
		return;
	}
	@Component(Name = "Manage Grouped Iterations")
	public void ManageGroupIteration(ParamManager pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		// Do Nothing
		return;
	}

	
	@Component(Name = "Copy File to ADPDATA Folder", Params = { "FilePathAndName", "CompanyCode" })
	// FilePathAndName: Mandatory! use absolutely path like \\myfolder\\myfile.ext
	// CompanyCode: Mandatory!
	public void copyFileToADPDataFolder(ParamManager pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		// Parse file name
		String[] aParsedFilePath = (pm.Parameter("FilePathAndName").replaceAll("\\\\", "\\/")).split("\\/");
		String sFileName = aParsedFilePath[aParsedFilePath.length - 1];
		String sFilePath = pm.Parameter("FilePathAndName").replace(sFileName, "");

		copyADPFile(sFileName, "[AUTOMATIONDRIVE]\\" + sFilePath, "[ADPDATA]", pm.Parameter("CompanyCode"), "");

		return;
	}

	@Component(Name = "Copy File From ADPDATA Folder to Local Drive", Params = { "FileName", "CompanyCode", "Decrypt" })
	// FileName: Mandatory! Just File Name only ex: PRABC.PAY, PRABC.ESS
	// CompanyCode: Mandatory!
	// Decrypt: optional if you want decrypt file
	public void copyFileFromADPDataFolder(ParamManager pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		copyADPFile(pm.Parameter("FileName"), "[ADPDATA]", DDTController.getSysProperty("report.path"), pm.Parameter("CompanyCode"), "Yes");

		return;
	}

	@Component(Name = "Copy File From Net Drive to Net Drive", Params = {"FileName","SourceFilePath", "DestinationFilePath" })
	public void copyFileFromNetToNet(ParamManager pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		copyADPFile(pm.Parameter("FileName"), pm.Parameter("SourceFilePath"), pm.Parameter("DestinationFilePath"),"", "No");

		return;
	}
	
	
	@Component(Name = "Check Reports Comparison Log", Params = { "ReportFileName" })
	public void checkReportComparisonLog(ParamManager pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		boolean bFoundLog = false;
		String sFailedLog = "";
		String sPassedLog = "";
		m_results.startVerificationLogStep();
		
		String strReportFileName = pm.Parameter("ReportFileName");
		if (strReportFileName.contains("---")) {
			strReportFileName = strReportFileName.split("\\---")[0];
		} else {
			strReportFileName = strReportFileName.split("\\.")[0];
		}

		for (int iloop = 1; iloop < 30; iloop++) {
			bFoundLog = false;
			sFailedLog = "smb://es.ad.adp.com;autoxpert:adpadp@Cdlisilon01-cifs.cdl.rose.us.adp/wfn/Automation/Reports/All Reports/Log/Failed_" + strReportFileName + ".log";
			sPassedLog = "smb://es.ad.adp.com;autoxpert:adpadp@Cdlisilon01-cifs.cdl.rose.us.adp/wfn/Automation/Reports/All Reports/Log/Passed_" + strReportFileName + ".log";
			SmbFile PassedLogFile = new SmbFile(sPassedLog);
			SmbFile FailedLogFile = new SmbFile(sFailedLog);

			if (PassedLogFile.exists()) {
				m_results.addEntryToVerificationLog("Check Reports Comparison Log", StatusType.PASSED, "Passed Status Log file found", "Passed Status Log file found");
//				DDTController.getResultsReporter().addTestStep("Check Reports Comparison Log", "Passed Status Log file found");
//				DDTController.getResultsReporter().endTestStep(StatusType.PASSED);
				PassedLogFile.delete();
				bFoundLog = true;
				break;
			} else {
				if (FailedLogFile.exists()) {
					m_results.addEntryToVerificationLog("Check Reports Comparison Log", StatusType.FAILED, "Failed Status Log file found", "Verification Log is availble at " + sFailedLog.replace("smb://es.ad.adp.com;autoxpert:adpadp@", "//"));
//					DDTController.getResultsReporter().addTestStep("Check Reports Comparison Log", "Failed Status Log file found - Verification Log is availble at " + sFailedLog.replace("smb://es.ad.adp.com;autoxpert:adpadp@", "//"));
//					DDTController.getResultsReporter().endTestStep(StatusType.FAILED);
					bFoundLog = true;
					break;
				}
			}

			try {
				Thread.sleep(60000);
			} catch (InterruptedException e) {
				throw new DDTFrameworkException(General.class, e.getMessage(), e);
			}
		}

		if (bFoundLog == false) {
			m_results.addEntryToVerificationLog("Check Reports Comparison Log", StatusType.FAILED, "Verification Log file is missing for this report", "Verification Log is NOT availble at " + sFailedLog.replace("smb://es.ad.adp.com;autoxpert:adpadp@", "//"));
//			DDTController.getResultsReporter().addTestStep("Check Reports Comparison Log", "Verification Log file is missing for this report : " + sFailedLog.replace("smb://es.ad.adp.com;autoxpert:adpadp@", "//"));
//			DDTController.getResultsReporter().endTestStep(StatusType.FAILED);
		}

		m_results.endVerificationLogStep();
	}

	// FileNameExtOnly: name of file and extension only like prxyz.pay, myOR.json
	// CopyFileFromPath: the path/folder name copying from ex: [ADPDATA],[ADPSAVE],[ADPLOG],[AUTOMATIONDRIVE],C:\\QC_TEMP\\
	// CopyFileToPath: the path/folder name coping to ex: [ADPDATA],[ADPSAVE],[ADPLOG],[AUTOMATIONDRIVE],C:\\QC_TEMP\\
	// CompanyCode: This only required if you want to copy file From/To Load File Server
	// DecryptFile: Valid Values: Yes. Optional if want to decrypt a file
	public void copyADPFile(String FileNameExtOnly, String CopyFileFromPath, String CopyFileToPath, String CompanyCode, String DecryptFile) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		SmbFile m_targetfile = null;
		SmbFile m_sourcefile = null;
		String m_sourcename = "";
		String m_targetname = "";
		String m_LocalTempFile = DDTController.getSysProperty("report.path") + "/" + FileNameExtOnly;
		String m_AutomationDrive = GlobalVariables.getAutomationUNCDrive();
		m_results.startVerificationLogStep();
		
		CopyFileFromPath = CopyFileFromPath.replace("[AUTOMATIONDRIVE]", m_AutomationDrive);
		CopyFileFromPath = CopyFileFromPath.replace("C:", "//localhost/C$");
		CopyFileToPath = CopyFileToPath.replace("[AUTOMATIONDRIVE]", m_AutomationDrive);
		CopyFileToPath = CopyFileToPath.replace("C:", "//localhost/C$");
		m_sourcename = "smb:" + CopyFileFromPath + "/" + FileNameExtOnly;
		m_targetname = "smb:" + CopyFileToPath + "/" + FileNameExtOnly;

		if (CopyFileFromPath.equalsIgnoreCase("[ADPDATA]")) {
			m_sourcename = "smb:" + GlobalVariables.getLoadFileUNCDrive() + "/" + GlobalVariables.getSellingRegion() + "/" + GlobalVariables.getRuntimeVPDKey() + "/" + CompanyCode + "/AdpData/" + FileNameExtOnly;
		}
		if (CopyFileFromPath.equalsIgnoreCase("[ADPSAVE]")) {
			m_sourcename = "smb:" + GlobalVariables.getLoadFileUNCDrive() + "/" + GlobalVariables.getSellingRegion() + "/" + GlobalVariables.getRuntimeVPDKey() + "/" + CompanyCode + "/AdpSave/" + FileNameExtOnly;
		}
		if (CopyFileFromPath.equalsIgnoreCase("[ADPLOG]")) {
			m_sourcename = "smb:" + GlobalVariables.getLoadFileUNCDrive() + "/" + GlobalVariables.getSellingRegion() + "/" + GlobalVariables.getRuntimeVPDKey() + "/" + CompanyCode + "/AdpLog/" + FileNameExtOnly;
		}

		if (CopyFileToPath.equalsIgnoreCase("[ADPDATA]")) {
			m_targetname = "smb:" + GlobalVariables.getLoadFileUNCDrive() + "/" + GlobalVariables.getSellingRegion() + "/" + GlobalVariables.getRuntimeVPDKey() + "/" + CompanyCode + "/AdpData/" + FileNameExtOnly;
		}
		if (CopyFileToPath.equalsIgnoreCase("[ADPSAVE]")) {
			m_targetname = "smb:" + GlobalVariables.getLoadFileUNCDrive() + "/" + GlobalVariables.getSellingRegion() + "/" + GlobalVariables.getRuntimeVPDKey() + "/" + CompanyCode + "/AdpSave/" + FileNameExtOnly;
		}
		if (CopyFileToPath.equalsIgnoreCase("[ADPLOG]")) {
			m_targetname = "smb:" + GlobalVariables.getLoadFileUNCDrive() + "/" + GlobalVariables.getSellingRegion() + "/" + GlobalVariables.getRuntimeVPDKey() + "/" + CompanyCode + "/AdpLog/" + FileNameExtOnly;
		}

		m_sourcename = m_sourcename.replaceAll("\\\\", "\\/");
		m_targetname = m_targetname.replaceAll("\\\\", "\\/");

		m_sourcename = m_sourcename.replace("smb://", "smb://es.ad.adp.com;autoxpert:adpadp@");
		m_targetname = m_targetname.replace("smb://", "smb://es.ad.adp.com;autoxpert:adpadp@");
		m_targetfile = new SmbFile(m_targetname);
		m_sourcefile = new SmbFile(m_sourcename);

		if (m_sourcename.contains("null") || m_targetname.contains("null")) {
			m_results.addEntryToVerificationLog("Skipping Copy File", StatusType.FAILED, "Copy File From Path or To File not found", m_sourcename + " > " + m_targetname);
//			DDTController.getResultsReporter().addTestStep("Skipping Copy File", "Copy File From Path or To File not found " + m_sourcename + " > " + m_targetname);
//			DDTController.getResultsReporter().endTestStep(StatusType.FAILED);
			m_results.endVerificationLogStep();
			return;
		}

		if (m_sourcefile.exists()) {
			m_sourcefile.copyTo(m_targetfile);
			m_results.addEntryToVerificationLog("File Copied",StatusType.DONE,"File Copy From: "+m_sourcename,"File Copy To: "+m_targetname);
//			DDTController.getResultsReporter().addTestStep("File Copy From: ", m_sourcename);
//			DDTController.getResultsReporter().endTestStep(StatusType.DONE);
//			DDTController.getResultsReporter().addTestStep("File Copy To: ", m_targetname);
//			DDTController.getResultsReporter().endTestStep(StatusType.DONE);
		} else {
			m_results.addEntryToVerificationLog("Skipping Copy File", StatusType.FAILED, "Copy File From Path not found", m_sourcename);
//			DDTController.getResultsReporter().addTestStep("Skipping Copy File", "Copy File From Path File not found " + m_sourcename);
//			DDTController.getResultsReporter().endTestStep(StatusType.FAILED);
			m_results.endVerificationLogStep();
			return;
		}

		// Decrypt file ONLY work with file located at local drive c:\qc_temp
		if (DecryptFile.equalsIgnoreCase("YES")) {
			if (m_targetfile.exists()) {
				Process p = Runtime.getRuntime().exec("cmd /c start \\\\cdlisilon01-cifs.cdl.rose.us.adp\\wfn\\Automation\\utilities\\DECRYPT.exe " + m_LocalTempFile);
				try {
					p.waitFor();
					Thread.sleep(3000);

				} catch (InterruptedException e) {
					throw new DDTFrameworkException(General.class, e.getMessage(), e);
				}
			}
		}
		
		m_results.endVerificationLogStep();
		return;
	}

	@Component(Name = "Verify CPF Record", Params = { "PayFile", "FileNumber", "RecordType", "Position", "Value", "OutputToFile", "RecordFound_OnOutPutFileLineNumber" })
	public void verifyCPFRecord(ParamManager pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		Date todaysDate = new Date();
		String sCoCode = "";
		String sFileNo = pm.Parameter("FileNumber");
		String sPayFile = DDTController.getSysProperty("report.path") + "/" + pm.Parameter("PayFile");
		String sRecType = pm.Parameter("RecordType").toUpperCase();
		String sExpectedValue = pm.Parameter("Value");
		String sExpectedValue_Part1 = "";
		String sExpectedValue_Part2 = "";
		boolean KeyWordOR_Found = false;
		int iStartPos = 0;
		String StateIndicator = "";
		m_results.startVerificationLogStep();
		
		sExpectedValue = com.adp.wfnddt.commonmethods.General.replaceSpaceKeyWord(sExpectedValue);

		if (pm.Parameter("PayFile").equals("")) {
			m_results.addEntryToVerificationLog("Skipping Verify CPF Record", StatusType.FAILED, "Pay File is missing value", "Pay File is missing value");
			m_results.endVerificationLogStep();
//			DDTController.getResultsReporter().addTestStep("Skipping Verify CPF Record", "Pay File is missing value");
//			DDTController.getResultsReporter().endTestStep(StatusType.DONE);
			return;
		}

		sCoCode = pm.Parameter("PayFile").substring(2, 5);
		sCoCode = sCoCode.replace("_", " ");

		// Fetch Parameter VALUE
		SimpleDateFormat currDate = new SimpleDateFormat("MMddyyyy");
		sExpectedValue = sExpectedValue.replace("<SYSTEM DATE>", currDate.format(todaysDate));
		sExpectedValue = sExpectedValue.replace("<SS>", " ");
		KeyWordOR_Found = sExpectedValue.contains("<OR>");
		if (KeyWordOR_Found) {
			String[] aExpectedValue = sExpectedValue.split("<OR>");
			sExpectedValue_Part1 = aExpectedValue[aExpectedValue.length - 1];
			sExpectedValue_Part2 = aExpectedValue[aExpectedValue.length];
		}

		// Get Starting Position
		if (pm.Parameter("Position").startsWith("COL_")) {
			iStartPos = Integer.valueOf((pm.Parameter("Position").replace("COL_", ""))) - 1;
		}

		if (pm.Parameter("Position").startsWith("G")) {
			StateIndicator = pm.Parameter("Position").replace("G_", "");
		}

		boolean bRecordFound = false;
		boolean bKeyFound = false;
		String sType = "";
		String sFirstField = "";
		// String sKeyBlank ="";
		String sCoCode_Line = "";
		String sFileNo_Line = "";
		String sMArea1 = "";
		String sMArea2 = "";
		String sMArea3 = "";
		String sGArea1 = "";
		String sGArea2 = "";
		String sMAreaExt1 = "";
		String sMAreaExt2 = "";
		String sMAreaExt3 = "";
		String sIgnoreAOID = "";
		String sActualValue = "";
		int LineNo = 0;
		String sOutputLine = "";
		String sExpectType = "";

		// Read all line from pay file
		// SmbFile smbPayFile = new SmbFile(sPayFile);
		try (BufferedReader reader = new BufferedReader(new FileReader(sPayFile))) {
			sOutputLine = reader.readLine();

			FileLoop: while (sOutputLine != null) {
				// Debug only
				// System.out.println(sOutputLine);
				// System.out.println(sOutputLine.length());
				LineNo = LineNo + 1;
				bRecordFound = false;
				bKeyFound = false;

				sType = sOutputLine.substring(15, 17);
				sFirstField = sOutputLine.substring(0, 2);
				// sKeyBlank = sOutputLine.substring(12, 21);
				sCoCode_Line = sOutputLine.substring(2, 5);
				sFileNo_Line = sOutputLine.substring(6, 12);
				sMArea1 = sOutputLine.substring(31, 47);
				sMArea2 = sOutputLine.substring(47, 63);
				sMArea3 = sOutputLine.substring(63, 79);
				sGArea1 = sOutputLine.substring(45, 61);
				sGArea2 = sOutputLine.substring(61, 77);
				sMAreaExt1 = sOutputLine.substring(31, 63);
				sMAreaExt2 = sOutputLine.substring(47, 79);
				sMAreaExt3 = sOutputLine.substring(31, 79);
				sIgnoreAOID = sOutputLine.substring(31, 40);

				if (sRecType.equalsIgnoreCase("MF")) {
					// sKeyBlank = "";
					if (sFirstField.equals("01")) {
						if (sCoCode.equals(sCoCode_Line) && sFileNo_Line.equals(sFileNo)) {
							bRecordFound = true;
						}
					}

					if (bRecordFound) {
						if (sExpectedValue.equals("") && pm.Parameter("OutputToFile").equalsIgnoreCase("FALSE")) {
							bKeyFound = true;
						} else {
							if (pm.Parameter("Position").equalsIgnoreCase("MUFF")) {
								if (!sIgnoreAOID.equalsIgnoreCase("AO IDAOID")) {
									if (sMArea1.equals(sExpectedValue) || sMArea2.equals(sExpectedValue) || sMArea3.equals(sExpectedValue)) {
										bKeyFound = true;
									}

									if (KeyWordOR_Found) {
										if (sExpectedValue_Part1.equals(sMArea1) || sExpectedValue_Part1.equals(sMArea2) || sExpectedValue_Part1.equals(sMArea3) || sExpectedValue_Part2.equals(sMArea1) || sExpectedValue_Part2.equals(sMArea2) || sExpectedValue_Part2.equals(sMArea3)) {
											bKeyFound = true;
										}
									}
								}
							} // End of MUFF

							if (pm.Parameter("Position").equalsIgnoreCase("MUFF2")) {
								if (sMAreaExt1.equals(sExpectedValue) || sMAreaExt2.equals(sExpectedValue)) {
									bKeyFound = true;
								}
							} // End of MUFF2

							if (pm.Parameter("Position").equalsIgnoreCase("MUFF3")) {
								if (sMAreaExt3.equals(sExpectedValue)) {
									bKeyFound = true;
								}
							} // End of MUFF3

							if (iStartPos > -1) {
								sActualValue = sOutputLine.substring(iStartPos, iStartPos + sExpectedValue.length());
								if (KeyWordOR_Found) {
									if (sExpectedValue_Part1.equals(sActualValue) || sExpectedValue_Part2.equals(sActualValue)) {
										bKeyFound = true;
										break FileLoop;
									}
								} else {
									if (sExpectedValue.equals(sActualValue)) {
										bKeyFound = true;
										break FileLoop;
									}
								}
							} // End of iStartPos

						}
					}

					if (bKeyFound) {
						break FileLoop;
					}
				} else {
					switch (sRecType) {
					case "21CARD":
						sExpectType = "21";
						break;
					case "5BCARD":
						sExpectType = "5B";
						break;
					case "7ECARD":
						sExpectType = "7E";
						break;
					case "7CARD":
						sExpectType = "7 ";
						break;
					case "UCARD":
						sExpectType = "U ";
						break;
					case "U2CARD":
						sExpectType = "U2";
						break;
					case "U3CARD":
						sExpectType = "U3";
						break;
					case "GCARD":
						if (StateIndicator.equals("")) {
							sExpectType = "G ";
						} else {
							sExpectType = "G " + StateIndicator;
							sType = sOutputLine.substring(15, 19);
						}
						break;
					case "HCARD":
						sType = sOutputLine.substring(16, 17);
						sExpectType = "H";
						sFileNo_Line = sFileNo;
						sMArea1 = sOutputLine.substring(31, 47);
						sMArea2 = sOutputLine.substring(47, 63);
						sMArea3 = sOutputLine.substring(63, 79);
						sMAreaExt1 = sOutputLine.substring(31, 63);
						sMAreaExt2 = sOutputLine.substring(47, 79);
						break;
					case "CCARD":
						sType = sOutputLine.substring(15, 16);
						sExpectType = "C";
						break;
					case "PD":
					case "DP1":
						sType = sOutputLine.substring(0, 2);
						sExpectType = "DP1";
						sCoCode_Line = sOutputLine.substring(11, 14);
						sFileNo_Line = "";
						sFileNo = "";
						break;
					case "12CARD":
						sType = sOutputLine.substring(15, 17);
						sExpectType = "12";
						sFileNo_Line = "";
						sFileNo = "";
						break;
					case "1CARD":
						sType = sOutputLine.substring(15, 17);
						sExpectType = "1 ";
						sFileNo_Line = sFileNo;
						break;
					case "J11CARD":
						sType = sOutputLine.substring(15, 18);
						sExpectType = "J11";
						sFileNo_Line = "";
						sFileNo = "";
						break;
					case "J12CARD":
						sType = sOutputLine.substring(15, 18);
						sExpectType = "J12";
						sFileNo_Line = "";
						sFileNo = "";
						break;
					case "J21CARD":
						sType = sOutputLine.substring(15, 18);
						sExpectType = "J21";
						sFileNo_Line = "";
						sFileNo = "";
						break;
					case "J22CARD":
						sType = sOutputLine.substring(15, 18);
						sExpectType = "J22";
						sFileNo_Line = "";
						sFileNo = "";
						break;
					case "CAP":
						sType = "";
						sExpectType = "";
						break;
					case "C5CARD":
						sType = sOutputLine.substring(15, 16) + sOutputLine.substring(17, 18);
						sExpectType = "C5";
						break;
					case "NCCARD":
						sType = sOutputLine.substring(15, 17);
						sExpectType = "NC";
						sFileNo_Line = "";
						sFileNo = "";
						break;
					}

					if (sType.equals(sExpectType)) {
						if (sCoCode.equals(sCoCode_Line)) {
							if (sFileNo_Line.equals(sFileNo)) {
								bRecordFound = true;
							}
						}
					}

					if (bRecordFound) {
						if (iStartPos > 0) {
							sActualValue = sOutputLine.substring(iStartPos, iStartPos + sExpectedValue.length());
							if (KeyWordOR_Found) {
								if (sExpectedValue_Part1.equals(sActualValue) || sExpectedValue_Part2.equals(sActualValue)) {
									bKeyFound = true;
									break FileLoop;
								}
							} else {
								if (sExpectedValue.equals(sActualValue)) {
									bKeyFound = true;
									break FileLoop;
								}
							}
						} // end of if iStartPos
						else {

							if (pm.Parameter("Position").equalsIgnoreCase("MUFF")) {
								if (sMArea1.equals(sExpectedValue) || sMArea2.equals(sExpectedValue) || sMArea3.equals(sExpectedValue)) {
									bKeyFound = true;
									break FileLoop;
								}
							}
							if (pm.Parameter("Position").equalsIgnoreCase("MUFF2")) {
								if (sMAreaExt1.equals(sExpectedValue) || sMAreaExt2.equals(sExpectedValue)) {
									bKeyFound = true;
									break FileLoop;
								}
							}
							if (pm.Parameter("Position").startsWith("G")) {
								if (sGArea1.equals(sExpectedValue) || sGArea2.equals(sExpectedValue)) {
									bKeyFound = true;
									break FileLoop;
								} else {
									bRecordFound = false;
								}
							}

						}
					}

				}

				sOutputLine = reader.readLine();
			} // End Of File While Loop
			reader.close();
		} // End of Try
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		if (pm.Parameter("OutputToFile").equalsIgnoreCase("TRUE")) {
			if (!sExpectedValue.equals("")) {
				if (bKeyFound) {
					m_results.addEntryToVerificationLog("Verify Create PayFile", StatusType.PASSED, "Pass--- Key/Muff field(" + sExpectedValue + ")  found", "Line #" + Integer.toString(LineNo));
//					DDTController.getResultsReporter().addTestStep("Verify Create PayFile ", "Pass--- Key/Muff field(" + sExpectedValue + ")  found on line# " + Integer.toString(LineNo));
//					DDTController.getResultsReporter().endTestStep(StatusType.PASSED);
				} else {
					m_results.addEntryToVerificationLog("Verify Create PayFile", StatusType.FAILED, "Pass--- Key/Muff field(" + sExpectedValue + ")  found", "Could not be matched to expected results in " + pm.Parameter("PayFile"));
//					DDTController.getResultsReporter().addTestStep("Verify Create PayFile ", "***Error: Key/Muff  fields(" + sExpectedValue + ")  could not be matched to expected results in " + pm.Parameter("PayFile"));
//					DDTController.getResultsReporter().endTestStep(StatusType.FAILED);
				}

				if (!pm.Parameter("RecordFound_OnOutPutFileLineNumber").equals("")) {
					if (pm.Parameter("RecordFound_OnOutPutFileLineNumber").equals(Integer.toString(LineNo))) {
						m_results.addEntryToVerificationLog("Verify Create PayFile", StatusType.PASSED, "Pass--- Expected record  found", "Line #" + Integer.toString(LineNo));
//						DDTController.getResultsReporter().addTestStep("Verify Create PayFile ", "Pass--- Expected record  found on line# " + Integer.toString(LineNo));
//						DDTController.getResultsReporter().endTestStep(StatusType.PASSED);
					} else {
						m_results.addEntryToVerificationLog("Verify Create PayFile", StatusType.FAILED, "***Error: Expected record NOT found on line# " + pm.Parameter("RecordFound_OnOutPutFileLineNumber"),"");
//						DDTController.getResultsReporter().addTestStep("Verify Create PayFile ", "***Error: Expected record NOT found on line# " + pm.Parameter("RecordFound_OnOutPutFileLineNumber"));
//						DDTController.getResultsReporter().endTestStep(StatusType.FAILED);
					}

				}

			} else {
				if (bRecordFound) {
					m_results.addEntryToVerificationLog("Verify Create PayFile", StatusType.PASSED, "Pass---Record Type (" + sRecType + ")  found","Line #" + Integer.toString(LineNo));
//					DDTController.getResultsReporter().addTestStep("Verify Create PayFile ", "Pass---Record Type (" + sRecType + ")  found on line# " + Integer.toString(LineNo));
//					DDTController.getResultsReporter().endTestStep(StatusType.PASSED);
				} else {
					m_results.addEntryToVerificationLog("Verify Create PayFile", StatusType.FAILED, "***Error: Reocord Type  (" + sRecType + ")  not found in " + pm.Parameter("PayFile"),"");
//					DDTController.getResultsReporter().addTestStep("Verify Create PayFile ", "***Error: Reocord Type  (" + sRecType + ")  not found in " + pm.Parameter("PayFile"));
//					DDTController.getResultsReporter().endTestStep(StatusType.FAILED);
				}
			}

		} else {
			if (sExpectedValue.equals("")) {
				if (bRecordFound == false) {
					m_results.addEntryToVerificationLog("Verify Create PayFile", StatusType.PASSED, "Pass---Reocord Type   (" + sRecType + ")  not found in " + pm.Parameter("PayFile"),"");
//					DDTController.getResultsReporter().addTestStep("Verify Create PayFile ", "Pass---Reocord Type   (" + sRecType + ")  not found in " + pm.Parameter("PayFile"));
//					DDTController.getResultsReporter().endTestStep(StatusType.PASSED);
				} else {
					m_results.addEntryToVerificationLog("Verify Create PayFile", StatusType.FAILED, "***Error: Reocord Type (" + sRecType + ")  found on line# " + Integer.toString(LineNo),"");
//					DDTController.getResultsReporter().addTestStep("Verify Create PayFile ", "***Error: Reocord Type (" + sRecType + ")  found on line# " + Integer.toString(LineNo));
//					DDTController.getResultsReporter().endTestStep(StatusType.FAILED);
				}
			} else {
				if (bKeyFound == false) {
					m_results.addEntryToVerificationLog("Verify Create PayFile", StatusType.PASSED, "Pass--- Key/Muff field(" + sExpectedValue + ")  not found " + pm.Parameter("PayFile"),"");
//					DDTController.getResultsReporter().addTestStep("Verify Create PayFile ", "Pass--- Key/Muff field(" + sExpectedValue + ")  not found " + pm.Parameter("PayFile"));
//					DDTController.getResultsReporter().endTestStep(StatusType.PASSED);
				} else {
					m_results.addEntryToVerificationLog("Verify Create PayFile", StatusType.FAILED, "***Error: Key/Muff fields (" + sExpectedValue + ")  found on line# " + Integer.toString(LineNo),"");
//					DDTController.getResultsReporter().addTestStep("Verify Create PayFile ", "***Error: Key/Muff fields (" + sExpectedValue + ")  found on line# " + Integer.toString(LineNo));
//					DDTController.getResultsReporter().endTestStep(StatusType.FAILED);
				}
			}
		}
		
		m_results.endVerificationLogStep();
	}

	@Component(Name = "Verify Create PayFile Exact Match by File Number", Params = { "CompanyCode", "FileNumber", "CPFRecord", "TotalLineCountOfMatchFileNumberInPayFile" })
	public void VerifyCreatePayFileExactMatchByFileNumber(ParamManager pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		String sFileNo = pm.Parameter("FileNumber");
		String sPayFile = DDTController.getSysProperty("report.path");
		String sExpectedValue = pm.Parameter("CPFRecord");
		String sOutputLine;
		String sCoCode_Line;
		String sFileNo_Line;
		String sValue;
		int iFileNumRecord = 0;
		String sMatchRecord = "";
		String sPartMatchRecord;
		m_results.startVerificationLogStep();
		
		if (pm.Parameter("CompanyCode").length() > 2) {
			sPayFile = sPayFile + "/PR" + pm.Parameter("CompanyCode") + ".PAY";
		} else {
			sPayFile = sPayFile + "/PR" + pm.Parameter("CompanyCode") + "_.PAY";
		}

		sExpectedValue = com.adp.wfnddt.commonmethods.General.replaceSpaceKeyWord(sExpectedValue);
		try (BufferedReader reader = new BufferedReader(new FileReader(sPayFile))) {
			sOutputLine = reader.readLine();

			while (sOutputLine != null) {
				sCoCode_Line = sOutputLine.substring(2, 5);
				sFileNo_Line = sOutputLine.substring(6, 12);
				sValue = sOutputLine.substring(12, sOutputLine.length());

				if (sCoCode_Line.equalsIgnoreCase(pm.Parameter("CompanyCode")) && sFileNo_Line.equalsIgnoreCase(sFileNo)) {
					if (!sValue.contains("  AO ID")) {
						sMatchRecord = sMatchRecord + sValue;
						iFileNumRecord = iFileNumRecord + 1;
					}

				}
				sOutputLine = reader.readLine();

			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		String[] AllCPFRecord = sExpectedValue.split("\\[\\+\\]");
		sPartMatchRecord = sMatchRecord;
		for (String CPFRec : AllCPFRecord) {
			if (sMatchRecord.contains(CPFRec)) {
				m_results.addEntryToVerificationLog("Verify CPF Record Found", StatusType.PASSED, "Record Found", CPFRec);
//				DDTController.getResultsReporter().addTestStep("Verify CPF Record Found ", CPFRec);
//				DDTController.getResultsReporter().endTestStep(StatusType.PASSED);
				sPartMatchRecord = sPartMatchRecord.replace(CPFRec, "");
			} else {
				m_results.addEntryToVerificationLog("Verify CPF Record Not Found", StatusType.FAILED, "Record NOT Found", sMatchRecord + ">> " + CPFRec);
//				DDTController.getResultsReporter().addTestStep("Verify CPF Record Not Found ", sMatchRecord + ">> " + CPFRec);
//				DDTController.getResultsReporter().endTestStep(StatusType.FAILED);
			}
		}

		if (!sPartMatchRecord.trim().equals("")) {
			m_results.addEntryToVerificationLog("Verify CPF Record Found", StatusType.FAILED, "Extra Records Found in Pay File", sPartMatchRecord);
//			DDTController.getResultsReporter().addTestStep("Extra Records Found in Pay File ", sPartMatchRecord);
//			DDTController.getResultsReporter().endTestStep(StatusType.FAILED);
		}

		if (!pm.Parameter("TotalLineCountOfMatchFileNumberInPayFile").equals("")) {
			if (pm.Parameter("TotalLineCountOfMatchFileNumberInPayFile").equals(Integer.toString(iFileNumRecord))) {
				m_results.addEntryToVerificationLog("Verify CPF Record Found", StatusType.PASSED, "Verify Total Number of File Number Record In Pay File", pm.Parameter("TotalLineCountOfMatchFileNumberInPayFile"));
//				DDTController.getResultsReporter().addTestStep("Verify Total Number of File Number Record In Pay File", pm.Parameter("TotalLineCountOfMatchFileNumberInPayFile"));
//				DDTController.getResultsReporter().endTestStep(StatusType.PASSED);
			} else {
				m_results.addEntryToVerificationLog("Verify Total Number of File Number Record In Pay File Not Match", StatusType.FAILED, "Expect > " + pm.Parameter("TotalLineCountOfMatchFileNumberInPayFile"), "Actual > " + Integer.toString(iFileNumRecord));
//				DDTController.getResultsReporter().addTestStep("Verify Total Number of File Number Record In Pay File Not Match", "Expect > " + pm.Parameter("TotalLineCountOfMatchFileNumberInPayFile") + " Actual > " + Integer.toString(iFileNumRecord));
//				DDTController.getResultsReporter().endTestStep(StatusType.FAILED);
			}

		}
		m_results.endVerificationLogStep();
	}

	@Component(Name = "Wait For Batch Process to Complete", Params = { "TimeAllowToWait", "RefreshEmployees", "NoneBatchWaitTime" })
	public void waitForBatchProcessToComplete(ParamManager pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException {

		if (!pm.Parameter("TimeAllowToWait").contentEquals("") || !pm.Parameter("RefreshEmployees").contentEquals("") || !pm.Parameter("NoneBatchWaitTime").contentEquals("")) {
			int timeToWait = 0;
			// boolean bBatchStillProcessing = false;
			boolean bNonBatchWaitTime = Boolean.parseBoolean(pm.Parameter("NoneBatchWaitTime"));
			if (Integer.valueOf(pm.Parameter("TimeAllowToWait")) < 180) {
				timeToWait = 180;
			} else {
				timeToWait = Integer.valueOf(pm.Parameter("TimeAllowToWait"));
			}

			if (bNonBatchWaitTime == true) {
				sleep(Integer.valueOf(pm.Parameter("TimeAllowToWait")));
			} else {
				sleep(5);
				for (int i = 1; i <= timeToWait;) {

					if (DDTController.getWebDriver().findElements(By.xpath("//i[contains(@class,'fa-spinner') and ancestor::*[contains(@style,'display: none')]]")).size() == 1) {
						sleep(2);
						break;
					} else {
						i = i + 5;
						sleep(5);
					}

					//
					// if (new WebObject("XPATH://i[contains(@class,'fa-spinner') and not (ancestor::*[contains(@style,'display: none')])]").exists()) {
					// // bBatchStillProcessing = true;
					// i = i + 5;
					// sleep(5);
					// } else {
					// sleep(2);
					// break;
					// }
				}
				if (new WebObject("XPATH://span[@id='close_label' and text()='Close']").exists()) {
					new WebObject("XPATH://span[@id='close_label' and text()='Close']").actionClick();
				}
				if (new WebObject("XPATH://span[@class='dijitDialogCloseIcon' and not (ancestor::*[contains(@style,'display: none')])]").exists()) {
					new WebObject("XPATH://span[@class='dijitDialogCloseIcon' and not (ancestor::*[contains(@style,'display: none')])]").actionClick();
				}
			}

			sleep(5);
			waitForGridSpinnerToComplete();
			sleep(5);
		}
	}

	@Component(Name = "Add Files and Upload - File Upload Dialog", Params = { "FileName" })
	// FileName: all files must be saved in automation shared drive in format of \DDT\EMPLOYEE IMPORT\YOURFILENAME.CSV
	// for multiple files use | ex: \DDT\EMPLOYEE IMPORT\YOURFILENAME_1.CSV;\DDT\EMPLOYEE IMPORT\YOURFILENAME_2.CSV
	public void addFilesFromFileUploadDialog(ParamManager pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException, InterruptedException {
		// copyADPFile(pm.Parameter("FileName"),"[ADPDATA]",DDTController.getSysProperty("report.path"),pm.Parameter("CompanyCode"),"Yes");

		if (pm.Parameter("FileName").equals(""))
			return;

		String[] fileNames = pm.Parameter("FileName").split(";");
		String fullPathFile = "";

		for (int i = 0; i < fileNames.length; i++) {
			fullPathFile = fileNames[i];
			if (!fullPathFile.equals("")) {
				fullPathFile = fullPathFile.replace("/", "\\");
				//Only update to automation share if it starts with \
				if (fullPathFile.startsWith("\\")) fullPathFile = GlobalVariables.getAutomationUNCDrive() + fullPathFile;
				if (new WebButton("XPATH://DIV[@class='uploaderInsideNode']").exists()){
					if (DDTController.getBrowserType()==BrowserType.Edge){
						new WebObject("XPATH://DIV[@class='uploaderInsideNode']").robotClick(85, 85);
					} else {
						new WebObject("XPATH://DIV[@class='uploaderInsideNode']").actionClick();
					}
				}
				sleep(2);
				DialogMethods.uploadFile(fullPathFile);
				waitForGridSpinnerToComplete();
				sleep(10);
			}
		}

		if (new WebButton("XPATH://SPAN[contains(@id,'file_upload_hSubmit_label')]").exists(30)) {
			new WebButton("XPATH://SPAN[contains(@id,'file_upload_hSubmit_label')]").actionClick();
			waitForGridSpinnerToComplete();
			sleep(2);
		}


		// workaround sometime it needs click twice
		if (new WebButton("XPATH://SPAN[contains(@id,'file_upload_hSubmit_label')]").exists(30)) {
			new WebButton("XPATH://SPAN[contains(@id,'file_upload_hSubmit_label')]").actionClick();
			waitForGridSpinnerToComplete();
			sleep(2);
		}

		return;
	}
	
	@Component(Name = "Download File - File Download Dialog", Params = { "FileName" })
	// FileName: all files must be saved in automation shared drive in format of \DDT\EMPLOYEE IMPORT\YOURFILENAME.CSV
	public void downloadFilesFromFileDialog(ParamManager pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException, InterruptedException {
		if (pm.Parameter("FileName").equals(""))
			return;
		String p_FullPathFile = pm.Parameter("FileName");
		p_FullPathFile = p_FullPathFile.replace("/", "\\");
		p_FullPathFile = GlobalVariables.getAutomationUNCDrive() + p_FullPathFile;

		if (!p_FullPathFile.contentEquals("")){
			File file = new File(p_FullPathFile);
			if (file.exists()){
				file.delete();
			}
		}
		sleep(3);
		
		if (DDTController.getBrowserType() == BrowserType.InternetExplorer32 || DDTController.getBrowserType() == BrowserType.InternetExplorer64) {
			DialogMethods.ieSaveAs();
			sleep(3);
		}
		m_results.addTestStep("Download File Path: " + p_FullPathFile);
		m_results.endTestStep(StatusType.DONE);
		p_FullPathFile = p_FullPathFile.replace("\\|", "\\\\");
		DialogMethods.downloadFile(p_FullPathFile);
		m_results.addScreenshotCaptureStep(captureScreenshot("ScreenShot After Download File"));
		waitForGridSpinnerToComplete();
		sleep(10);


		return;
	}
	
	//TODO: add CSV and DOC comparison
	//Baseline_Path and Download_Path should have a format of \\EMPLOYEE IMPORT\\EE Import Deductions\\BPT01\\PRUT4EMP.CSV
    @Component(Name = "Compare Files",
                  Params = { "Baseline_Path|*^*| Required - Specify the path of the baseline file. It should be in the Automation shared folder.",
                               "Download_Path|*^*| Required - Specify the path of the file where it was downloaded to. It should be in the Automation shared folder.",
                               "Remove_Text|*^*| Optional - Specify words (or regex) which you want to remove from the files e.g. RUN DATE[+]AM/PM[+]Don't compare this sentence.[+]Test"})
    public void compareReportFiles(ParamManager pm) throws Exception {
    	String automationUNCDrive = GlobalVariables.getAutomationUNCDrive();
 	   	String baselinePath = automationUNCDrive + pm.Parameter("Baseline_Path");
 	   	String downloadPath = automationUNCDrive + pm.Parameter("Download_Path");
 	   	String fileNameFormat = pm.Parameter("Download_Path").split("\\.")[1].trim();
 	   	List<String> textsToRemoveFromFileList = new ArrayList<String>();
 	   
 	  
		File baselinefile = new File(baselinePath);
		if (!(baselinefile.exists())){
			m_results.startVerificationLogStep();
			m_results.addEntryToVerificationLog ("Compare Files", StatusType.FAILED,"Baseline File NOT Found!",baselinePath);
			m_results.endVerificationLogStep();
			return;
		}

		File downloadfile = new File(downloadPath);
		if (!(downloadfile.exists())){
			m_results.startVerificationLogStep();
			m_results.addEntryToVerificationLog ("Compare Files", StatusType.FAILED,"Downloaded File NOT Found!",downloadPath);
			m_results.endVerificationLogStep();
			return;
		}
		
 	   	
 	   	if (!pm.Parameter("Remove_Text").trim().equalsIgnoreCase("")) {
 	   		String[] textsToBeAddedToArray = pm.Parameter("Remove_Text").split("[+]");
 	   		for (int ctr = 0; ctr < textsToBeAddedToArray.length; ctr++) {
 	   			textsToRemoveFromFileList.add(textsToBeAddedToArray[ctr]);
 	   		}
 	   	}
 	   	else { 
 	   		textsToRemoveFromFileList.add("Run Date ?: ?\\d{2}/\\d{2}/\\d{4} \\d{2}:\\d{2}");
 	   		textsToRemoveFromFileList.add("as of \\d{2}/\\d{2}/\\d{4}");
 	   		textsToRemoveFromFileList.add("(AM|PM) (EST|EDT)");
 	   		textsToRemoveFromFileList.add("(in|for) Report ?:");
 	   		textsToRemoveFromFileList.add("As of Date: \\d{2}/\\d{2}/\\d{4}");
 	   		textsToRemoveFromFileList.add("Count of Employees ?:");
 	   		textsToRemoveFromFileList.add("Count (of|Of) Employees In Report ?: ?");
 	   		textsToRemoveFromFileList.add("Records ?:");
 	   		textsToRemoveFromFileList.add("Run Date ?: ?\\d{2}/\\d{2}/\\d{4} \\d{2}:\\d{2} (AM|PM) (EST|EDT|UTC)");
 	   		textsToRemoveFromFileList.add("Created on ?: ?\\d{2}/\\d{2}/\\d{4}");
 	   		textsToRemoveFromFileList.add("Run Date: \\d{2}/\\d{2}/\\d{4}\\s\\d{2}:\\d{2}\\s(AM|PM)\\s[A-Z]{3}");
 	   	}
 	   	String [] textsToRemoveFromFileArr = new String[textsToRemoveFromFileList.size()];
 	   
 	   	sleep(5);
 	   	if (fileNameFormat.equalsIgnoreCase("PDF")) {
 	   		pdfValidations.verifyPDFFileContent(baselinePath, downloadPath, textsToRemoveFromFileList.toArray(textsToRemoveFromFileArr));
 	   	}
 	   	else if (fileNameFormat.equalsIgnoreCase("XLSX") || fileNameFormat.equalsIgnoreCase("XLS") || fileNameFormat.equalsIgnoreCase("CSV")) {
 	   		ExcelCompare.compareTwoSpreadSheets(baselinePath, downloadPath, "MM/dd/yyyy", textsToRemoveFromFileList.toArray(textsToRemoveFromFileArr));
 	   	}
    }

	@Component(Name = "Client UA Access and Return to Admin", Params = { "Navigation_Type|*^*|Valid Values: UA Access, Return to Admin", "ClientID|*^*|Any valid clientID. Required for UA Access" })
	public void clientUAAccessandReturntoAdmin(ParamManager pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException {

		//m_webDriver = DDTController.getWebDriver();

		if (pm.Parameter("Navigation_Type").toUpperCase().contentEquals("UA ACCESS")) {
			if (m_webdriver.findElements(By.xpath("//*[@id='mastheadSearchForm']//input[contains(@id,'toolbarQuickSearch')]")).size() != 0) {
				m_webdriver.findElement(By.xpath("//*[@id='mastheadSearchForm']//input[contains(@id,'toolbarQuickSearch')]")).click();
				sleep(1000);
				m_webdriver.findElement(By.xpath("//*[@id='mastheadSearchForm']//input[contains(@id,'toolbarQuickSearch')]")).sendKeys(pm.Parameter("ClientID"));
				sleep(3000);
				m_webdriver.findElement(By.xpath(".//a/span[contains(text(),'" + pm.Parameter("ClientID").toLowerCase() + "')]")).click();
				sleep(3000);
				m_webdriver.findElement(By.xpath("//a[text()='Practitioner Access']")).click();
				DDTController.getWebDriverWait().until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='masthead']")));
			}
		} else if (pm.Parameter("Navigation_Type").toUpperCase().contentEquals("RETURN TO ADMIN")) {
			if (m_webdriver.findElements(By.xpath("//*[@id='adpUserGoBackToSupport']")).size() != 0) {
				m_webdriver.findElement(By.xpath("//*[@id='adpUserGoBackToSupport']")).click();
				sleep(3000);
				DDTController.getWebDriverWait().until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='masthead']//input[@id='searchBox']")));
			}
		}
	}
	
	@Component(Name = "Partner Return to Admin", Params = { "Navigation_Type|*^*|Valid Values: UA Access, Return to Admin", "ClientID|*^*|Any valid clientID. Required for UA Access" })
	public void partnerReturntoAdmin(ParamManager pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException {

		m_webdriver = DDTController.getWebDriver();

		 if (pm.Parameter("Navigation_Type").toUpperCase().contentEquals("RETURN TO ADMIN")) {
			if (m_webdriver.findElements(By.xpath("//*[@id='adpUserGoBackToSupport']")).size() != 0) {
				m_webdriver.findElement(By.xpath("//*[@id='adpUserGoBackToSupport']")).click();
				DDTController.getWebDriverWait().until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//DIV[@id='wfnnav_top_item_Partner']")));
			}
		}
	}
	
	@Component(Name = "Verify Employee Existence", 
			Params = { "CoCode|*^*|Optional - Company Code only. [BLANK] allowed",
					   "EmployeeName|*^*|Optional. Expecting Last Name, First Name", 
					   "FileNumber", 
					   "NumberOfEmployeeFound|*^*|Required - number of employees found", 
					   "WorkedInCountry|*^*|Optional (iHCM clients only)", 
					   "PositionID", 
					   "Status" })
	public void verifyEmployeeExistence(ParamManager pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		loadObjectRepository(OR_Path);
		WebDriverWait m_webDriverWait = DDTController.getWebDriverWait();
		ObjectTypes Page = Browser.Page("All Employees Search Option");
		Navigation navigation = new Navigation();
		navigation.navigateToPage("People", "Personal Profile");
		
		
		//New employee IDBar
		if (new WebLink ("XPATH://div[@class='empidbar-midsection vdl-hidden-lg-down']//button[@id='empidbar-empsearch-link']").exists()){
			new WebLink ("XPATH://div[@class='empidbar-midsection vdl-hidden-lg-down']//button[@id='empidbar-empsearch-link']").click();
			sleep(1);
			m_webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='vdl-slide-in-body']//span[contains(text(),'Advanced Search')]")));
			m_webdriver.findElement(By.xpath("//div[@class='vdl-slide-in-body']//span[contains(text(),'Advanced Search')]")).click();
			m_webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='ID Position ID']//input")));
			new WebTextBox ("XPATH://div[@id='ID Last Name']//input").clearText();
			new WebTextBox ("XPATH://div[@id='ID Position ID']//input").clearText();
			new WebTextBox ("XPATH://div[@id='ID File #']//input").clearText();
			//new WebComboBox ("XPATH://span[@title='Company Code']/following-sibling::div//div[contains(@class,'MDFSelectBox__control')]").select("[BLANK]");
			new WebComboBox ("XPATH://span[@title='Status']/following-sibling::div//div[contains(@class,'MDFSelectBox__control')]").select("[BLANK]");
			
			new WebTextBox ("XPATH://div[@id='ID File #']//input").set(pm.Parameter("FileNumber"),false);
			new WebComboBox ("XPATH://span[@title='Company Code']/following-sibling::div//div[contains(@class,'MDFSelectBox__control')]").select(pm.Parameter("CoCode"));
			new WebComboBox ("XPATH://span[@title='Status']/following-sibling::div//div[contains(@class,'MDFSelectBox__control')]").select(pm.Parameter("Status"));
			new WebTextBox ("XPATH://div[@id='ID Last Name']//input").set(pm.Parameter("EmployeeName").split("\\,")[0]);
			new WebTextBox ("XPATH://div[@id='ID Position ID']//input").set(pm.Parameter("PositionID"));
			
			//new WebObject ("XPATH://div[@id='ID Home Department']//span[@class='mdf-searchbox-searchicon fa fa-search']").actionClick();
			sleep(1);
			
			m_webdriver.findElement(By.xpath("//button[@id='advmode-searchall']")).click();
			sleep(3);
			
			Integer totalCount = m_webdriver.findElements(By.xpath("//div[@aria-label='grid' and @role='rowgroup']//div[@role='row']")).size();
			Integer expCount = Integer.valueOf(pm.Parameter("NumberOfEmployeeFound"));
			m_results.startVerificationLogStep();
			if (expCount.equals(totalCount)) {
				m_results.addEntryToVerificationLog("Verify Employee Existence", StatusType.PASSED, expCount.toString(), totalCount.toString());
			} else {
				m_results.addEntryToVerificationLog("Verify Employee Existence", StatusType.FAILED, expCount.toString(), totalCount.toString());
			}		
			m_results.endVerificationLogStep();
			m_results.addScreenshotCaptureStep(com.adp.wfnddt.commonmethods.General.captureScreenshot("Verify Employee Existence"));
			m_webdriver.findElement(By.xpath("//div[@class='vdl-slide-in-header']//span[text()='Back']")).click();
			sleep(3);
			
			return;
		}
		
		new WebButton("XPATH://span[@id='employeeIdBarEmpListTooltipBtn']").actionClick();
		new WebButton("XPATH://span[@id='advSearchLink']").actionClick();
		new WebObject("XPATH://div[@id='advancedSearchTabContainer_tablist_searchOptions']").actionClick();

		//Clear the values first in case it was cached
		Page.WebTextBox("Last Name").set("[BLANK]");
		Page.WebTextBox("Position ID").set("[BLANK]");
		Page.WebComboBox("Company Code").select("[BLANK]");
		Page.WebTextBox("File #").set("[BLANK]");
		Page.WebComboBox("Status").select("[BLANK]");

		Page.WebTextBox("Last Name").set(pm.Parameter("EmployeeName").split("\\,")[0]);
		Page.WebTextBox("Position ID").set(pm.Parameter("PositionID"));
		Page.WebComboBox("Company Code").select("[PARTIAL]"+pm.Parameter("CoCode"));
		Page.WebTextBox("File #").set(pm.Parameter("FileNumber"));
		Page.WebComboBox("Status").select(pm.Parameter("Status"));
		Page.WebButton("SEARCH").actionClick();
		waitForGridSpinnerToComplete();
		sleep(1);
		//Page.WebComboBox("Show").select(pm.Parameter("Show"));

		Integer totalCount = DDTController.getWebDriver().findElements(By.xpath("//table[@id='advancedSearchResultsGrid_rows_table']//tr[contains(@id,advancedSearchResultsGrid_row) and @id!='advancedSearchResultsGrid_row_column_sizes']")).size();
		Integer expCount = Integer.valueOf(pm.Parameter("NumberOfEmployeeFound"));
		m_results.startVerificationLogStep();
		if (expCount.equals(totalCount)) {
			m_results.addEntryToVerificationLog("Verify Employee Existence", StatusType.PASSED, expCount.toString(), totalCount.toString());
		} else {
			m_results.addEntryToVerificationLog("Verify Employee Existence", StatusType.FAILED, expCount.toString(), totalCount.toString());
		}		
		m_results.endVerificationLogStep();
		m_results.addScreenshotCaptureStep(com.adp.wfnddt.commonmethods.General.captureScreenshot("Verify Employee Existence"));
		Page.WebButton("CANCEL").actionClick();		
	}
	
	@Component(Name = "Run Java Script", Params = { "JavaScript|*^*|Optional - Script to excute at browser level"})
	public void runJavaScript(ParamManager pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		
		if (pm.Parameter("JavaScript").contentEquals("")) {return;}
		JavascriptExecutor js = (JavascriptExecutor) m_webdriver;
		String script = pm.Parameter("JavaScript");
		js.executeScript(script);
		
	}
	
	@Component(Name = "Verify Cookie Value", Params = { "Cookie_Key_Value|*^*|Valid Values :Enter the key values as displayed.Note : Use delimeter as : to seperate cookie key and value" })
	public void verifyCookieValue(ParamManager pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException {

		m_webdriver = DDTController.getWebDriver();
        results.startVerificationLogStep();
        
        waitForGridSpinnerToComplete();
		sleep(5);
		
      //Get the cookie which name is “cookie” with getName() method and print its value.
		String Cookie_Name = pm.Parameter("Cookie_Key_Value").split(":")[0];
		String Cookie_Value = pm.Parameter("Cookie_Key_Value").split(":")[1];

        Cookie cookie = m_webdriver.manage().getCookieNamed(Cookie_Name);
		String cookieValue = cookie.getValue().toString().trim();
        
		if (cookieValue.contains(Cookie_Value.trim()))
			results.addEntryToVerificationLog("Background color of the configuration theme matched", StatusType.PASSED,
					Cookie_Value, cookieValue);
		else {
			results.addEntryToVerificationLog("Background color of the configuration theme did not matched", StatusType.FAILED,
					Cookie_Value, cookieValue);
		}

		results.endVerificationLogStep();	
	}
	
	@Component(Name = "Stop On Failure Setting", Params = { "Flag|*^*|Valid Values: Yes or No. Used to set if you want to stop or continue execution on failures" })
	public void stopOnFailureSetting(ParamManager pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		
		if (pm.Parameter("Flag").equalsIgnoreCase("YES")) {
			DDTController.setStopExecution(true);
			DDTController.setStopExecutionOnException(true);
		} else if (pm.Parameter("Flag").equalsIgnoreCase("NO")) {
			DDTController.setStopExecution(false);
			DDTController.setStopExecutionOnException(false);			
		}
		return;			
	}
	@Component(Name = "Copy File and Replace Keywords", Params = { "OriginalFileLocationAndName|*^*|Required! file must be in automation shared drive. i.e. \\EMPLOYEE IMPORT\\JIM.CSV", "FileIsEncrypted|*^*|Valid Values: No or Yes", "DestinationFileName|*^*|specify path only. i.e. EMP41101.CSV" })
	public void copyFileAndReplaceKeywords(ParamManager pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException, InterruptedException, ParseException {

		sleep(5);
		String originalFileLocationAndName = pm.Parameter("OriginalFileLocationAndName").toUpperCase();
		String localTempFolder = "C:/QC_Temp/Temp/";
		String automationDrive = "\\\\cdlisilon01-cifs.cdl.rose.us.adp\\wfn\\Automation";
		String destFileName = pm.Parameter("DestinationFileName");

		// Create Temp Folder if not exists
		File directory = new File(localTempFolder);
		if (!directory.exists()) {
			directory.mkdirs();
		}

		// Copy File to local area
		Files.copy(Paths.get(automationDrive + originalFileLocationAndName), Paths.get(localTempFolder + destFileName), StandardCopyOption.REPLACE_EXISTING);

		// decrypt file if needed
		// TODO

		// Modify Contents of File
		File newFile = new File(localTempFolder + destFileName);
		newFile.deleteOnExit();
		newFile.createNewFile();
		newFile.setWritable(true);

		File readerFile = new File(localTempFolder + destFileName);
		readerFile.setReadable(true);
		List<String> lines = Files.readAllLines(readerFile.toPath(), StandardCharsets.UTF_8);

		String convertedLine;
		List<String> convertedLines = new ArrayList<>();
		for (String line : lines) {
			convertedLine = replaceParameterKeyWords(line);
            convertedLines.add(convertedLine);
		}
		Files.write(newFile.toPath(), convertedLines);
	}
}

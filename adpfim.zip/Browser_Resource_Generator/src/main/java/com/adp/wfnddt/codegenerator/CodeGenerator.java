package com.adp.wfnddt.codegenerator;

import java.io.BufferedReader;
import java.io.FileReader;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.adp.wfnddt.objectmanager.DefaultMethod;
import com.adp.wfnddt.objectmanager.DefaultMethod.TypeOfMethod;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class CodeGenerator {

	public static void main(String[] args) {
		String pageName = "ECC_UPLOAD_YOUR_RESUME_POPUP";
		BufferedReader br;
		try {
			br = new BufferedReader(new FileReader("C:\\GIT_V21\\Component_ExternalApplications\\src\\main\\resources\\Objects\\EXTERNAL_CAREER_CENTER_NEW.json"));
			JsonParser parser = new JsonParser();
			JsonObject objectsJSON = parser.parse(br).getAsJsonObject();

			// Get the pages
			JsonArray pageArray = objectsJSON.get("Pages").getAsJsonArray();
			int iPageCount = pageArray.size();
			List<String> actionCode = new ArrayList<String>();
			//List<String> verifyCode = new ArrayList<String>();
			List<String> verifyValueCodeForPage = new ArrayList<String>();
			List<String> verifyObjectCodeForPage = new ArrayList<String>();
			List<String> verifyListBoxCodeForPage = new ArrayList<String>();
			List<String> actionCodeForCard = new ArrayList<String>();
			List<String> verifyValueCodeForCard = new ArrayList<String>();
			List<String> verifyObjecDataCodeForCard = new ArrayList<String>();
			List<String> verifyObjectPropertiesCodeForCard = new ArrayList<String>();
			List<String> verifyListBoxContentsCodeForCard = new ArrayList<String>();
			List<String> ClickLinkActionCodeForWebTable = new ArrayList<String>();
			List<String> EnterDataActionCodeForWebTable = new ArrayList<String>();
			List<String> verifyValueCodeForWebTable = new ArrayList<String>();
			List<String> verifyObjectPropertiesCodeForWebTable = new ArrayList<String>();
			List<String> verifyListBoxContentsCodeForWebTable = new ArrayList<String>();

			for (int i = 0; i < iPageCount; i++) {
				if (pageArray.get(i).getAsJsonObject().get("Page Name").getAsString().trim().equalsIgnoreCase(pageName.trim())) {
					System.out.println("//" + pageName.trim());

					JsonArray pageObjectsJSON = pageArray.get(i).getAsJsonObject().get("Data").getAsJsonArray();

					// Find all the frames
					HashMap<String, List<JsonObject>> groupedObjects = new HashMap<>();
					groupedObjects.put("#", new ArrayList<JsonObject>());
					for (int j = 0; j < pageObjectsJSON.size(); j++) {
						String objectID = pageObjectsJSON.get(j).getAsJsonObject().get("ID").getAsString().trim();
						String objectType = pageObjectsJSON.get(j).getAsJsonObject().get("Object Type").getAsString().trim();
						if (objectType.contentEquals("Frame")) {
							groupedObjects.put(objectID, new ArrayList<JsonObject>());
							groupedObjects.get(objectID).add(pageObjectsJSON.get(j).getAsJsonObject());
						}
					}

					// Group the objects according to the frames
					for (int j = 0; j < pageObjectsJSON.size(); j++) {
						String parentID = pageObjectsJSON.get(j).getAsJsonObject().get("Frame ID").getAsString().trim();
						String objectType = pageObjectsJSON.get(j).getAsJsonObject().get("Object Type").getAsString().trim();
						if (!objectType.contentEquals("Frame")) {
							if (groupedObjects.containsKey(parentID)) {
								groupedObjects.get(parentID).add(pageObjectsJSON.get(j).getAsJsonObject());
							} else {
								groupedObjects.get("#").add(pageObjectsJSON.get(j).getAsJsonObject());
							}
						}
					}

					// Process the objects according to the frames
					for (int k = 0; k < groupedObjects.size(); k++) {
						String frameID = groupedObjects.keySet().toArray()[k].toString();

						for (int j = 0; j < groupedObjects.get(frameID).size(); j++) {

							String objName = groupedObjects.get(frameID).get(j).get("Object Name").getAsString().trim();
							String objType = groupedObjects.get(frameID).get(j).get("Object Type").getAsString().trim();

							// Find the default methods and generate the code
							Class<?> objectClass = Class.forName("com.adp.wfnddt.objectmanager." + objType);
							for (Method method : objectClass.getDeclaredMethods()) {

								String command = "";

								if (objType.equalsIgnoreCase("WebButton") || objType.equalsIgnoreCase("WebLink") || objType.equalsIgnoreCase("WebImage") || objType.equalsIgnoreCase("Frame")) {
									command = "\tPage." + objType + "(\"" + objName + "\")." + method.getName() + "(pm.Parameter(\"Button_To_Click\"));";
								} else if (objType.equalsIgnoreCase("WebRadioButton")) {
									command = "\tPage." + objType + "(\"" + objName + "\")." + method.getName() + "(pm.Parameter(\"PARAMTER NAME\"),\"MAPPED VALUE\");";
								} else if (objType.equalsIgnoreCase("WebTable")) {
									command = "\tPage." + objType + "(\"" + objName + "\")." + method.getName() + "(pm, tableObjectMap());";
								} else if (objType.equalsIgnoreCase("WebCard")) {
									command = "\tPage." + objType + "(\"" + objName + "\")." + method.getName() + "(pm, cardSelector, cardObjectMap());";
								} else {
									command = "\tPage." + objType + "(\"" + objName + "\")." + method.getName() + "(pm.Parameter(\"" + objName + "\"));";
								}

								if (method.isAnnotationPresent(DefaultMethod.class) && method.getAnnotation(DefaultMethod.class).MethodType() == TypeOfMethod.Action && !(method.getName().contains("enterData")) && !(method.getName().contains("clickLink"))) {
									actionCode.add(command);
								} else if (method.isAnnotationPresent(DefaultMethod.class) && method.getAnnotation(DefaultMethod.class).MethodType() == TypeOfMethod.Verification && method.getName() == "verifyValue") {
									command = "\tPage." + objType + "(\"" + objName + "\")." + method.getName() + "(pm.Parameter(\"" + objName + "\"));";
									verifyValueCodeForPage.add(command);
								} else if (method.getName() == "verifyObjectProperties") {
									command = "\tPage." + objType + "(\"" + objName + "\")." + method.getName() + "(pm.Parameter(\"" + objName + "\"));";
									verifyObjectCodeForPage.add(command);
								} else if (method.getName() == "verifyContents") {
									command = "\tPage." + objType + "(\"" + objName + "\")." + method.getName() + "(pm.Parameter(\"" + objName + "\"), pm.Parameter(\"TypeOfTest\"));";
									verifyListBoxCodeForPage.add(command);
								} else if (method.getName() == "clickLinkInTable") {
									ClickLinkActionCodeForWebTable.add(command);
								} else if (method.getName() == "enterDataInTable") {
									EnterDataActionCodeForWebTable.add(command);
								} else if (method.getName() == "verifyRowInstancesInTable") {
									command = "\tPage." + objType + "(\"" + objName + "\")." + method.getName() + "(pm);";
									verifyValueCodeForWebTable.add(command);
								} else if (method.getName() == "verifyTableCellObjectProperties") {
									verifyObjectPropertiesCodeForWebTable.add(command);
								} else if (method.getName() == "verifyRowDataListBoxContentsInTable") {
									verifyListBoxContentsCodeForWebTable.add(command);
								} else if (method.getName() == "enterDataInCard" && method.isAnnotationPresent(DefaultMethod.class)) {
									actionCodeForCard.add(command);
								} else if (method.getName() == "verifyCardInstances") {
									verifyValueCodeForCard.add(command);
								} else if (method.getName() == "verifyObjectDataInCard") {
									verifyObjecDataCodeForCard.add(command);
								} else if (method.getName() == "verifyObjectPropertiesInCard") {
									verifyObjectPropertiesCodeForCard.add(command);
								} else if (method.getName() == "verifyListBoxContentsInCard") {
									verifyListBoxContentsCodeForCard.add(command);
								}
							}
						}
					}

					// Print the code
					System.out.println("//---------------------------------------------------------------------------------------------");
					System.out.println("//Page -[" + pageName + "] *** ENTER DATA ON PAGE ***");
					System.out.println("//---------------------------------------------------------------------------------------------");
					System.out.println("@Component(Name = \"Enter Data on " + pageName + " Page\", Params = { \"\" })");
					System.out.println("public void enterDataon" + pageName.replaceAll("[^a-zA-Z]+", "") + "Page(ParamManager pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException, InterruptedException {");
					System.out.println("\tObjectTypes Page = Browser.Page(\"" + pageName + "\");\n");
					for (String command : actionCode)
						System.out.println(command);
					System.out.println("}\n");

					System.out.println("//---------------------------------------------------------------------------------------------");
					System.out.println("//Page -[" + pageName + "] *** VERIFY DATA ON PAGE ***");
					System.out.println("//---------------------------------------------------------------------------------------------");
					System.out.println("@Component(Name = \"Verify Data on " + pageName + " Page\", Params = { \"\" })");
					System.out.println("public void verifyDataon" + pageName.replaceAll("[^a-zA-Z]+", "") + "Page(ParamManager pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException, InterruptedException {");
					System.out.println("\tObjectTypes Page = Browser.Page(\"" + pageName + "\");\n");
					System.out.println("\tresults.startVerificationLogStep();");
					for (String command : verifyValueCodeForPage)
						System.out.println(command);
					System.out.println("\tresults.endVerificationLogStep();");
					System.out.println("}\n");

					System.out.println("//---------------------------------------------------------------------------------------------");
					System.out.println("//Page -[" + pageName + "] *** VERIFY OBJECT PROPERTIES ON PAGE ***");
					System.out.println("//---------------------------------------------------------------------------------------------");
					System.out.println("@Component(Name = \"Verify Object Properties on " + pageName + " Page\", Params = { \"\" })");
					System.out.println("public void verifyObjectPropertieson" + pageName.replaceAll("[^a-zA-Z]+", "") + "Page(ParamManager pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException, InterruptedException {");
					System.out.println("\tObjectTypes Page = Browser.Page(\"" + pageName + "\");\n");
					System.out.println("\tresults.startVerificationLogStep();");
					for (String command : verifyObjectCodeForPage)
						System.out.println(command);
					System.out.println("\tresults.endVerificationLogStep();");
					System.out.println("}\n");

					System.out.println("//---------------------------------------------------------------------------------------------");
					System.out.println("//Page -[" + pageName + "] *** VERIFY LIST BOX CONTENTS ON PAGE ***");
					System.out.println("//---------------------------------------------------------------------------------------------");
					System.out.println("@Component(Name = \"Verify List Box Contents on " + pageName + " Page\", Params = { \"\" })");
					System.out.println("public void verifyListBoxContentsOn" + pageName.replaceAll("[^a-zA-Z]+", "") + "Page(ParamManager pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException, InterruptedException {");
					System.out.println("\tObjectTypes Page = Browser.Page(\"" + pageName + "\");\n");
					System.out.println("\tresults.startVerificationLogStep();");
					for (String command : verifyListBoxCodeForPage)
						System.out.println(command);
					System.out.println("\tresults.endVerificationLogStep();");
					System.out.println("}\n");

					for (String command : ClickLinkActionCodeForWebTable) {
						System.out.println("//---------------------------------------------------------------------------------------------");
						System.out.println("//Page -[" + pageName + "] *** CLICK LINK IN TABLE ***");
						System.out.println("//---------------------------------------------------------------------------------------------");
						System.out.println("@Component(Name = \"Click Table Link on " + pageName + " Page\", Params = { \"RowToFind_Column 1\", \"RowToFind_Column n\", \"Col_Name\", \"Row_Instance\" })");
						System.out.println("public void clickTableLinkon" + pageName.replaceAll("[^a-zA-Z]+", "") + "Page(ParamManager pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException, InterruptedException {");
						System.out.println("\tObjectTypes Page = Browser.Page(\"" + pageName + "\");");
						System.out.println(command);
						System.out.println("}\n");
					}

					for (String command : EnterDataActionCodeForWebTable) {
						System.out.println("//---------------------------------------------------------------------------------------------");
						System.out.println("//Page -[" + pageName + "] *** ENTER TABLE ROW DATA ***");
						System.out.println("//---------------------------------------------------------------------------------------------");
						System.out.println("@Component(Name = \"Enter Table Row Data on Found Row on " + pageName + " Page\", Params = { \"RowToFind_Column 1\", \"RowToFind_Column n\", \"Row_Instance\", \"RowData_Column 1\", \"RowData_Column n\", \"Row_Number\" })");
						System.out.println("public void enterTableRowDataon" + pageName.replaceAll("[^a-zA-Z]+", "") + "Page(ParamManager pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException, InterruptedException {");
						System.out.println("\tObjectTypes Page = Browser.Page(\"" + pageName + "\");");
						System.out.println(command);
						System.out.println("}\n");
					}

					for (String command : verifyValueCodeForWebTable) {
						System.out.println("//---------------------------------------------------------------------------------------------");
						System.out.println("//Page -[" + pageName + "] *** VERIFY TABLE ROW INSTANCE ***");
						System.out.println("//---------------------------------------------------------------------------------------------");
						System.out.println("@Component(Name = \"Verify Table Row Instance on " + pageName + " Page\", Params = { \"RowToFind_Column 1\", \"RowToFind_Column n\", \"Number_Of_Instances_To_Find\", \"Row_Number\" })");
						System.out.println("public void verifyTableRowInstanceon" + pageName.replaceAll("[^a-zA-Z]+", "") + "Page(ParamManager pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException, InterruptedException {");
						System.out.println("\tObjectTypes Page = Browser.Page(\"" + pageName + "\");\n");
						System.out.println("\tresults.startVerificationLogStep();");
						System.out.println(command);
						System.out.println("\tresults.endVerificationLogStep();");
						System.out.println("}\n");
					}

					for (String command : verifyObjectPropertiesCodeForWebTable) {
						System.out.println("//---------------------------------------------------------------------------------------------");
						System.out.println("//Page -[" + pageName + "] *** VERIFY TABLE CELL OBJECT PROPERTIES ***");
						System.out.println("//---------------------------------------------------------------------------------------------");
						System.out.println("@Component(Name = \"Verify Table Cell Object Properties on " + pageName + " Page\", Params = { \"RowToFind_Column 1\", \"RowToFind_Column n\", \"Row_Instance\", \"Column_Column 1\", \"Column_Column n\" })");
						System.out.println("public void verifyTableCellObjectPropertieson" + pageName.replaceAll("[^a-zA-Z]+", "") + "Page(ParamManager pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException, InterruptedException {");
						System.out.println("\tObjectTypes Page = Browser.Page(\"" + pageName + "\");\n");
						System.out.println("\tresults.startVerificationLogStep();");
						System.out.println(command);
						System.out.println("\tresults.endVerificationLogStep();");
						System.out.println("}\n");
					}

					for (String command : verifyListBoxContentsCodeForWebTable) {
						System.out.println("//---------------------------------------------------------------------------------------------");
						System.out.println("//Page -[" + pageName + "] *** VERIFY TABLE LISTBOX CONTENTS ***");
						System.out.println("//---------------------------------------------------------------------------------------------");
						System.out.println("@Component(Name = \"Verify Table List Box Contents on " + pageName + " Page\", Params = { \"RowToFind_Column 1\", \"RowToFind_Column n\", \"Row_Instance\", \"Col_Name\", \"Type_Of_Test\", \"LB_Contents\", \"Row_Number\" })");
						System.out.println("public void verifyTableListBoxContentson" + pageName.replaceAll("[^a-zA-Z]+", "") + "Page(ParamManager pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException, InterruptedException {");
						System.out.println("\tObjectTypes Page = Browser.Page(\"" + pageName + "\");\n");
						System.out.println("\tresults.startVerificationLogStep();");
						System.out.println(command);
						System.out.println("\tresults.endVerificationLogStep();");
						System.out.println("}\n");
					}

					for (String command : actionCodeForCard) {
						System.out.println("//---------------------------------------------------------------------------------------------");
						System.out.println("//Page -[" + pageName + "] *** ENTER CARD DATA ***");
						System.out.println("//---------------------------------------------------------------------------------------------");
						System.out.println("@Component(Name = \"Enter Card Data on " + pageName + " Page\", Params = { \"CardToFind_Field 1\", \"CardToFind_Field n\", \"Card_Instance\", \"CardData_Field 1\", \"CardData_Field n\", \"Button_To_Click\", \"Actions\" })");
						System.out.println("public void enterCardDataon" + pageName.replaceAll("[^a-zA-Z]+", "") + "Page(ParamManager pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException, InterruptedException {");
						System.out.println("\tObjectTypes Page = Browser.Page(\"" + pageName + "\");\n");
						System.out.println("\tString cardSelector = \"XPATH:.[Define xpath for identifying individual card selector]\";");
						System.out.println(command);
						System.out.println("}\n");
					}

					for (String command : verifyValueCodeForCard) {
						System.out.println("//---------------------------------------------------------------------------------------------");
						System.out.println("//Page -[" + pageName + "] *** VERIFY CARD INSTANCES ***");
						System.out.println("//---------------------------------------------------------------------------------------------");
						System.out.println("@Component(Name = \"Verify Card Instances on " + pageName + " Page\", Params = { \"CardToFind_Field 1\", \"CardToFind_Field n\", \"Card_Instance\" })");
						System.out.println("public void verifyCardInstancesOn" + pageName.replaceAll("[^a-zA-Z]+", "") + "Page(ParamManager pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException, InterruptedException {");
						System.out.println("\tObjectTypes Page = Browser.Page(\"" + pageName + "\");\n");
						System.out.println("\tString cardSelector = \"XPATH:.[Define xpath for identifying individual card selector]\";");
						System.out.println("\tresults.startVerificationLogStep();");
						System.out.println(command);
						System.out.println("\tresults.endVerificationLogStep();");
						System.out.println("}\n");
					}

					for (String command : verifyObjecDataCodeForCard) {
						System.out.println("//---------------------------------------------------------------------------------------------");
						System.out.println("//Page -[" + pageName + "] *** VERIFY CARD OBJECT DATA ***");
						System.out.println("//---------------------------------------------------------------------------------------------");
						System.out.println("@Component(Name = \"Verify Card Object Data on " + pageName + " Page\", Params = { \"CardToFind_Field 1\", \"CardToFind_Field n\", \"Card_Instance\", \"CardData_Field 1\", \"CardData_Field n\", \"Card_Number\" })");
						System.out.println("public void verifyCardObjectDataOn" + pageName.replaceAll("[^a-zA-Z]+", "") + "Page(ParamManager pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException, InterruptedException {");
						System.out.println("\tObjectTypes Page = Browser.Page(\"" + pageName + "\");\n");
						System.out.println("\tString cardSelector = \"XPATH:.[Define xpath for identifying individual card selector]\";");
						System.out.println("\tresults.startVerificationLogStep();");
						System.out.println(command);
						System.out.println("\tresults.endVerificationLogStep();");
						System.out.println("}\n");
					}

					for (String command : verifyObjectPropertiesCodeForCard) {
						System.out.println("//---------------------------------------------------------------------------------------------");
						System.out.println("//Page -[" + pageName + "] *** VERIFY CARD OBJECT PROPERTIES ***");
						System.out.println("//---------------------------------------------------------------------------------------------");
						System.out.println("@Component(Name = \"Verify Card Object Properties on " + pageName + " Page\", Params = { \"CardToFind_Field 1\", \"CardToFind_Field n\", \"Card_Instance\", \"CardObject_Field 1\", \"CardObject_Field n\" })");
						System.out.println("public void verifyCardObjectPropertiesOn" + pageName.replaceAll("[^a-zA-Z]+", "") + "Page(ParamManager pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException, InterruptedException {");
						System.out.println("\tObjectTypes Page = Browser.Page(\"" + pageName + "\");\n");
						System.out.println("\tString cardSelector = \"XPATH:.[Define xpath for identifying individual card selector]\";");
						System.out.println("\tresults.startVerificationLogStep();");
						System.out.println(command);
						System.out.println("\tresults.endVerificationLogStep();");
						System.out.println("}\n");
					}

					for (String command : verifyListBoxContentsCodeForCard) {
						System.out.println("//---------------------------------------------------------------------------------------------");
						System.out.println("//Page -[" + pageName + "] *** VERIFY CARD LISTBOX CONTENTS ***");
						System.out.println("//---------------------------------------------------------------------------------------------");
						System.out.println("@Component(Name = \"Verify Card List Box Contents on " + pageName + " Page\", Params = { \"CardToFind_Field 1\", \"CardToFind_Field n\", \"Card_Instance\", \"CardObject_Field\", \"Type_Of_Test\", \"LB_Contents\" })");
						System.out.println("public void verifyCardListBoxContentsOn" + pageName.replaceAll("[^a-zA-Z]+", "") + "Page(ParamManager pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException, InterruptedException {");
						System.out.println("\tObjectTypes Page = Browser.Page(\"" + pageName + "\");\n");
						System.out.println("\tString cardSelector = \"XPATH:.[Define xpath for identifying individual card selector]\";");
						System.out.println("\tresults.startVerificationLogStep();");
						System.out.println(command);
						System.out.println("\tresults.endVerificationLogStep();");
						System.out.println("}\n");
					}
					br.close();
					return;
				}

			}

			System.out.println("*** Page [" + pageName + "] not found. Please check the JSON !! ***");
			return;

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}

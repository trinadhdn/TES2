package com.adp.wfnddt.loadvariables;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class LoadVariables {

	public static String loadSyncCompVar(String p_JSON_Path, String p_Attribute) {
		BufferedReader br;
		JsonObject object = null;
		JsonArray jsonSyncComp = null;
		String jsonPrimitiveValue = null;

		try {
			InputStream in = LoadVariables.class.getResourceAsStream(p_JSON_Path);
			br = new BufferedReader(new InputStreamReader(in));
			JsonParser parser = new JsonParser();
			object = parser.parse(br).getAsJsonObject();
			jsonSyncComp = object.getAsJsonArray("SyncComponent");
			jsonPrimitiveValue = jsonSyncComp.get(0).getAsJsonObject().getAsJsonPrimitive(p_Attribute).getAsString();			

			br.close();
			in.close();
		} catch (Exception e) {
			System.out.println("Unable to process JSON object file: " + p_JSON_Path);
			System.out.println(e.getMessage());
			System.out.println(e.getStackTrace());
		}
		return jsonPrimitiveValue;
	}
}

package com.adp.wfnddt.stepdbupdate;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.lang.reflect.Method;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collection;
import java.util.List;
import static cucumber.runtime.io.MultiLoader.packageName;
import com.adp.wfnddt.aspects.Component;
import com.adp.wfnddt.dbconn.DBConn;
import com.adp.wfnddt.loadvariables.LoadVariables;

import cucumber.runtime.ClassFinder;
import cucumber.runtime.Utils;
import cucumber.runtime.io.MultiLoader;
import cucumber.runtime.io.ResourceLoader;
import cucumber.runtime.io.ResourceLoaderClassFinder;

/*
 * 1) Go to Windows->Preferences->Java->Installed JREs->Select JRE and click Edit then add the jar file as external resource (\\cdlisilon01-cifs.cdl.rose.us.adp\wfn\DDTFramework\developer\sqljdbc42.jar)
 */
public class StepDBUpdateMain 
{
	private static String m_ComponentLogfilePath = "ComponentSync.log";
	private static boolean m_SyncUpAddComp = false; //Set to true to sync up Step DB with new components from eclipse and parameter mismatches
	private static boolean m_SyncUpParams = false; //Set to true to sync up Step DB with parameter mismatches
	private static String m_Tags = "@WFNMegaMenu"; //Enter the tags you want added on creating a new component i.e. @WFNMegaMenu @People @PersonalInformation
	private static boolean m_SyncUpDeleteComp = false; //Set to true to remove a component from the step DB
	private static boolean m_SyncUpMarkImpl = false; //Set to true to set the Step DB component to implemented or not implemented
	private static boolean m_MarkImpl = false; //Set to true to set the implementation flag ot ON OR false to set the flag OFF
	private static String m_UserName = "";
	private static String m_Password = "";
	private static String m_ComponentName = "";
	private static String m_Release = "release/WFN21GANewDev";
	private static String m_ImplementedBy = "SyncComponent";
	private static List<ComponentType> m_lstrSQLDB = new ArrayList<ComponentType>();
	private static List<ComponentType> m_lstrEclipse = retrieveComponentsFromEclipse();
	private static String m_JSONPath = "/MySyncComponent.json";
	
    public static void main(String[] args)
    {
    	//Retrieve components from Step DB
    	System.out.println("Starting...");
    	m_UserName = args[0].trim();
    	m_Password = args[1].trim();
    	m_SyncUpAddComp = Boolean.parseBoolean(LoadVariables.loadSyncCompVar(m_JSONPath, "Add New Component to Step DB"));
    	m_SyncUpParams = Boolean.parseBoolean(LoadVariables.loadSyncCompVar(m_JSONPath, "Sync Up Parameters"));
    	m_Tags = LoadVariables.loadSyncCompVar(m_JSONPath, "Tags");
    	if (m_Tags.contentEquals("@WFNMegaMenu")) {
    		System.out.println("Please enter some data for the Tags field in your copy of the SyncComponent JSON file");
    		return;
		}
    	m_SyncUpDeleteComp = Boolean.parseBoolean(LoadVariables.loadSyncCompVar(m_JSONPath, "Delete Component"));
    	m_SyncUpMarkImpl = Boolean.parseBoolean(LoadVariables.loadSyncCompVar(m_JSONPath, "Run Lock Component"));
    	m_MarkImpl = Boolean.parseBoolean(LoadVariables.loadSyncCompVar(m_JSONPath, "Lock Component"));
    	m_ImplementedBy = LoadVariables.loadSyncCompVar(m_JSONPath, "Implemented By");
    	if (m_ImplementedBy.contentEquals("SyncComponent")) {
    		System.out.println("Please change the Implemented By field to your ES ID in your copy of the SyncComponent JSON file");
    		return;
		}
    	m_ComponentLogfilePath = args[2].trim() + "\\" + m_ComponentLogfilePath;
    	m_ComponentName = args[3].trim();
    	m_lstrSQLDB = getCompList ();
    	
    	updateComponent();
    	System.out.println("Done! Please check the log file");
    }
    
    private static List<ComponentType> getCompList () {
    	List<ComponentType> lstrSQLDB = new ArrayList<ComponentType>();
    	DBConn sqlDBConn = new DBConn(new String(Base64.getDecoder().decode(m_UserName)),new String(Base64.getDecoder().decode(m_Password)));
    	ResultSet resSet1 = sqlDBConn.runQuery("SELECT A.STEP_COMP_ID,A.STEP_COMP_NAME,B.STEP_COMP_PARAM_NAME + '|*^*|' + B.STEP_COMP_PARAM_DESCRIPTION AS STEP_PARAM FROM [DDTToolOwner].DDT_STEP_COMPONENT_INFO A LEFT JOIN [DDTToolOwner].DDT_STEP_COMP_PARAMETER B ON A.STEP_COMP_ID = B.STEP_COMP_ID WHERE STEP_COMP_NAME = '" + m_ComponentName + "' AND SCC_VERSION_TAG = '" + m_Release + "' ORDER BY A.STEP_COMP_ID");
    	lstrSQLDB = getSQLComponents(resSet1);
    	sqlDBConn.closeDBConn();
		return lstrSQLDB;    	
    }
    
    private static List<ComponentType> getSQLComponents (ResultSet p_resSet1) {
    	List<ComponentType> strResult = new ArrayList<ComponentType>();
    	String strName = "";
		ComponentType compType = new ComponentType();
   		try {
   			//No row check
   			if (p_resSet1.next() == false) return strResult; //just return the blank strResult
			while(p_resSet1.isAfterLast() == false){
				compType = new ComponentType();
				compType.setName(p_resSet1.getString("STEP_COMP_NAME"));
				compType.addParam(p_resSet1.getString("STEP_PARAM"));
				strName = p_resSet1.getString("STEP_COMP_NAME");
				while(p_resSet1.next()){
					if (strName.equalsIgnoreCase(p_resSet1.getString("STEP_COMP_NAME"))) {
						//Add Additional Parameters
						compType.addParam(p_resSet1.getString("STEP_PARAM"));
					} else {
						//break on new component name
						break;
					}					
				}
				strResult.add(compType);
			}
			return strResult;    	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
   		return null;
    }
    
    private static int countComponents (List<ComponentType> p_List, String p_Name) {
    	int iCount = 0;
    	for (ComponentType componentType : p_List) {
    		if (componentType.getName().equals(p_Name)) iCount++;			
		}
		return iCount;
    	
    }

    private static void markLocked (Writer p_Write) throws IOException {
    	DBConn sqlDBConn = new DBConn(new String(Base64.getDecoder().decode(m_UserName)), new String(Base64.getDecoder().decode(m_Password)));
    	String implFlag = m_MarkImpl ? "1":"0";
    	if (sqlDBConn.runSQL("UPDATE [DDTToolOwner].DDT_STEP_COMPONENT_INFO SET STEP_COMP_LOCKED = "+implFlag+", MODIFIED_BY = 'SyncComponent', LAST_MODIFIED_DT = SYSDATETIME() WHERE UPPER(STEP_COMP_NAME) = '" + m_ComponentName.toUpperCase() + "' AND SCC_VERSION_TAG = '"+m_Release+"'") < 1) {
    		p_Write.write("ERROR:\t Mark locked failed on Comp Name: "+ m_ComponentName +"\n");
    	}			
    	sqlDBConn.closeDBConn();    	
    }

    private static void deleteComponent (Writer p_Write) throws IOException {
    	DBConn sqlDBConn = new DBConn(new String(Base64.getDecoder().decode(m_UserName)), new String(Base64.getDecoder().decode(m_Password)));
    	Boolean boolDeleted = true;
    	if (sqlDBConn.runSQL("DELETE FROM [DDTToolOwner].DDT_STEP_COMP_PARAMETER WHERE STEP_COMP_ID IN (SELECT STEP_COMP_ID FROM [DDTToolOwner].DDT_STEP_COMPONENT_INFO WHERE UPPER(STEP_COMP_NAME) = '" + m_ComponentName.toUpperCase() + "' AND SCC_VERSION_TAG = '"+m_Release+"')") < 1) {
    		boolDeleted = false;
    	}			
    	if (sqlDBConn.runSQL("DELETE FROM [DDTToolOwner].DDT_STEP_COMPONENT_INFO WHERE UPPER(STEP_COMP_NAME) = '" + m_ComponentName.toUpperCase() + "' AND SCC_VERSION_TAG = '"+m_Release+"'") < 1) {
    		boolDeleted = false;
    	}
    	if (boolDeleted) { //Deletion was successful
    		p_Write.write(m_ComponentName+" deleted.\n");
    	} else {
    		p_Write.write("ERROR:\t Delete failed on Comp Name: "+ m_ComponentName +"\n");    		
    	}
    	sqlDBConn.closeDBConn();    	
    }
    
    private static void updateParameters (Writer p_Write, ComponentType p_CompType) throws IOException, SQLException {
    	//Delete records then add
		String strParamName = "";
		String strParamDesc = "";
		String strCompID = "";
    	int iCtr = 1;
    	if (p_CompType.getParams().size() < 1) {
    		return; //this means there are no parameters to upload! So just return
    	}
    	if (p_CompType.getParams().get(0).isEmpty()) {
    		return; //this means there is no parameter name to upload! So just return
    	}
    	DBConn sqlDBConnAdd = new DBConn(new String(Base64.getDecoder().decode(m_UserName)), new String(Base64.getDecoder().decode(m_Password)));
    	ResultSet resSet2 = sqlDBConnAdd.runQuery("SELECT STEP_COMP_ID FROM [DDTToolOwner].DDT_STEP_COMPONENT_INFO WHERE STEP_COMP_NAME = '" + p_CompType.getName() + "' AND SCC_VERSION_TAG = '"+m_Release+"'");
    	resSet2.next();
    	strCompID = resSet2.getString("STEP_COMP_ID");
    	resSet2.close();
    	
    	if (sqlDBConnAdd.runSQL("DELETE FROM [DDTToolOwner].DDT_STEP_COMP_PARAMETER WHERE STEP_COMP_ID = '" + strCompID + "'") < 1) {
    		//p_Write.write("WARNING:\t Param Delete failed on Comp ID: "+ strCompID +"\n");
    		//Do Nothing!    		
    	}
    	for (String paramRecord : p_CompType.getParams()) {
    		if (paramRecord == null || paramRecord.equals("|*^*|")) { //check for null here and continue if so. Do not create new blank Parameter records
    			continue;
    		}
    		strParamName = paramRecord.split("\\|\\*\\^\\*\\|")[0];
    		if (strParamName == "") {
    			continue;
    		}
			if (paramRecord.split("\\|\\*\\^\\*\\|").length > 1) {
    			strParamDesc = paramRecord.split("\\|\\*\\^\\*\\|")[1];
    		} else {
    			strParamDesc = ""; //In case of no description or null reference    			
    		}
    		strParamDesc = strParamDesc.replaceAll("'", "''");
        	if (sqlDBConnAdd.runSQL("INSERT INTO DDT_STEP_COMP_PARAMETER (STEP_COMP_ID, STEP_COMP_PARAM_NAME, STEP_COMP_PARAM_ORDER, STEP_COMP_PARAM_DESCRIPTION) VALUES ("
        							+strCompID+",'"+strParamName+"',"+iCtr+",'"+strParamDesc+"')") < 1) {
        		p_Write.write("ERROR:\t Param Add failed on Comp Name: "+ p_CompType.getName() +" with parameter name: "+strParamName+"\n");
        	}		
        	iCtr++;
		}
    	sqlDBConnAdd.closeDBConn();
    }
    
    private static void addComponentToStepDB (Writer p_Write, ComponentType p_CompType) throws IOException, SQLException {
    	DBConn sqlDBConnAdd = new DBConn(new String(Base64.getDecoder().decode(m_UserName)), new String(Base64.getDecoder().decode(m_Password)));
    	if (sqlDBConnAdd.runSQL("INSERT INTO DDT_STEP_COMPONENT_INFO (STEP_COMP_NAME, SCC_VERSION_TAG, STEP_COMP_TAGS, STEP_COMP_LOCKED,MODIFIED_BY,LAST_MODIFIED_DT,IMPLEMENTED_BY,STEP_COMP_STATE) VALUES ("
    							+ "'" + p_CompType.getName() + "','"+m_Release+"','"+m_Tags+"',"+"'0',"+"'SyncComponent',SYSDATETIME(),'"+m_ImplementedBy+"','Complete')") < 1) {
    		p_Write.write("ERROR:\t New Component Add failed on Comp Name: " + p_CompType.getName() + "\n");
    	}    		
    	sqlDBConnAdd.closeDBConn();
    	updateParameters(p_Write,p_CompType);    	
    }
    
    private static void updateComponent () {
    	Writer writer = null;
    	try {
    	    writer = new BufferedWriter(new OutputStreamWriter(
    	          new FileOutputStream(m_ComponentLogfilePath), "utf-8"));
	    	if (m_SyncUpAddComp) { //Run process only if option is set to true. Otherwise ignore
        	    writer.write("******ADD COMPONENT TO STEP DB:\n\n");
        	    if (countComponents(m_lstrSQLDB,m_ComponentName) != 0) { //if component already exists post error in log and quit
        	    	writer.write("ERROR: Component "+m_ComponentName+" found in Step DB - can not Add!"+"\n");
        	    } else {
        	    	boolean bDone = false;
		    	    for (ComponentType strEclipse : m_lstrEclipse) { //Find the component in Eclipse
		    	    	if (strEclipse.getName().equalsIgnoreCase(m_ComponentName)) {
		    	    		addComponentToStepDB (writer,strEclipse); //only run if sync up is true
							writer.write(strEclipse.getName()+" added.\n");
							bDone = true;
							break;
						}				
					}
		    	    if (!bDone) {
		    	    	writer.write(m_ComponentName+" not found in Eclipse! Check case sensitivity\n");
		    	    } else {
		    	    	m_lstrSQLDB = getCompList ();
		    	    }
        	    }
	    	}
	    	if (m_SyncUpParams) { //Run process only if option is set to true. Otherwise ignore
        	    writer.write("\n******UPDATE PARAMETERS IN STEP DB:\n\n");
        	    if (countComponents(m_lstrSQLDB,m_ComponentName) != 1) { //if component does not exist or has duplicates post error in log and quit
        	    	writer.write("ERROR: Component "+m_ComponentName+" not found in Step DB or has duplicates in Eclipse - can not Update!"+"\n");
        	    } else {
        	    	boolean bDone = false;
		    	    for (ComponentType strEclipse : m_lstrEclipse) { //Find the component in Eclipse
		    	    	if (strEclipse.getName().equalsIgnoreCase(m_ComponentName)) {
		    	    		updateParameters(writer,strEclipse);
							writer.write(strEclipse.getName()+" updated.\n");
							bDone = true;
							break;
						}				
					}
		    	    if (!bDone) writer.write(m_ComponentName+" not found in Eclipse! Check case sensitivity\n");
        	    }
	    	}
	    	if (m_SyncUpMarkImpl) { //Run process only if option is set to true. Otherwise ignore
	    		writer.write("\n******MARK COMPONENTS AS LOCKED IN STEP DB\n\n");
        	    if (countComponents(m_lstrSQLDB,m_ComponentName) != 1) { //if component does not exist or has duplicates post error in log and quit
        	    	writer.write("ERROR: Component "+m_ComponentName+" not found in Step DB or has duplicates in Eclipse - can not lock until resolved!"+"\n");
        	    } else {
    	    		markLocked(writer);
					writer.write(m_ComponentName+" locked.\n");
        	    }
	    	}
	    	if (m_SyncUpDeleteComp) { //Run process only if option is set to true. Otherwise ignore
	    		writer.write("\n******DELETE COMPONENT FROM STEP DB\n\n");
        	    if (countComponents(m_lstrSQLDB,m_ComponentName) == 0) { //if component does not exist or has duplicates post error in log and quit
        	    	writer.write("ERROR: Component "+m_ComponentName+" not found in Step DB!"+"\n");
        	    } else {
    	    		deleteComponent(writer);
        	    }
	    	}
    	} catch (IOException ex) {
    		ex.printStackTrace();
    	} catch (SQLException e) {
    		e.printStackTrace();
    	} finally {
    	   try {
    		   writer.close();
    	   } catch (Exception ex) {
    		   ex.printStackTrace();
    	   }
    	}    	
    }

    private static List<ComponentType> retrieveComponentsFromEclipse () {
        // TODO Auto-generated method stub
        ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
        ResourceLoader resourceLoader = new MultiLoader(classLoader);
        ClassFinder classFinder = new ResourceLoaderClassFinder(resourceLoader, classLoader);
        Collection<Class<?>> componentClasses = classFinder.getDescendants(Object.class, packageName("com.adp.wfnddt.components"));
        List<ComponentType> lstrComponents = new ArrayList<ComponentType>();
        ComponentType compType = new ComponentType();

        // Find the components
        for (Class<?> componentClass : componentClasses) {
               while (componentClass != null && componentClass != Object.class && !Utils.isInstantiable(componentClass)) {
                     componentClass = componentClass.getSuperclass();
               }
               if (componentClass != null) {
                     for (Method method : componentClass.getMethods()) {
                            // Find the method and invoke
                            if (method.isAnnotationPresent(Component.class)) {
                            	compType = new ComponentType();
                            	compType.setName(method.getAnnotation(Component.class).Name().toString());
                            	for (String paramItem : method.getAnnotation(Component.class).Params()) {
                            		if (paramItem.contains("|*^*|") == false) {
                            			paramItem += "|*^*|";
                            		}
									compType.addParam(paramItem);
								}
                            	lstrComponents.add(compType);
                            }
                     }
               }
        }
		return lstrComponents;    	
    }
}

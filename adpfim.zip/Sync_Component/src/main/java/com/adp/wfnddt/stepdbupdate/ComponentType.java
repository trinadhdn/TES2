package com.adp.wfnddt.stepdbupdate;

import java.util.ArrayList;
import java.util.List;

public class ComponentType {
	private String m_Name = "";
	private List<String> m_Params = new ArrayList<String>();
	
	public ComponentType () {
		m_Params.clear();
	}
	
	public void setValues (String p_Name, List<String> p_Params) {
		m_Name = p_Name;
		m_Params = p_Params;		
	}

	public void setName (String p_Name) {
		m_Name = p_Name;
	}

	public void addParam (String p_Param) {
		m_Params.add(p_Param);
	}

	public String getName () {
		return m_Name;		
	}

	public List<String> getParams () {
		return m_Params;		
	}
}

package com.adp.wfnddt.dbconn;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DBConn {
	private static Connection m_DbConn = null;
	private String m_UserName = "";
	private String m_Password = "";
	private static ResultSet m_ResSet = null;
	private static Statement m_Statement = null;
	
	public DBConn (String p_UserName, String p_Password) {
		m_UserName = p_UserName;
		m_Password = p_Password;
		msSqlDBConn ();
	}
	
	public DBConn (String p_UserName, String p_Password, String p_DBName) {
		m_UserName = p_UserName;
		m_Password = p_Password;
		msSqlDBConn (p_DBName);
	}

	public void msSqlDBConn () {
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			m_DbConn = DriverManager.getConnection("jdbc:sqlserver://CDLWFNRESMGRSRV;databaseName=DDTPod1ToolsDB;user=" + m_UserName + ";password=" + m_Password + ";");
			return;
		} catch (SQLException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void msSqlDBConn (String p_DBName) {
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			m_DbConn = DriverManager.getConnection("jdbc:sqlserver://CDLWFNRESMGRSRV;databaseName="+p_DBName+";user=" + m_UserName + ";password=" + m_Password + ";");
			return;
		} catch (SQLException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public Connection getDBConn () {
		return m_DbConn;
	}
	
	public ResultSet runQuery (String p_Stmt) {
		m_ResSet = null;
		try {
			m_Statement = m_DbConn.createStatement();
			m_ResSet = m_Statement.executeQuery(p_Stmt);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return m_ResSet;
	}

	public int runSQL (String p_Stmt) {
		m_ResSet = null;
		try {
			m_Statement = m_DbConn.createStatement();
			m_Statement.execute(p_Stmt);
			return m_Statement.getUpdateCount();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return -1;
	}

	public ResultSet getResultSet () {
		return m_ResSet;		
	}
	
	public void closeDBConn () {
		try {
			m_Statement.close();
			m_DbConn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
